# Changelog

## v2.6.0
- Renamed final folder to `Project D-Link/`
- Added `scripts/export_all.sh` one-command Tesla export runner
- Added `scripts/export_report.py` to summarize results into runs/EXPORT_REPORT.md
- Added philosophical robustness section to Dimensional Computing note

## v2.5.0
- Added FINAL/ folder collecting key docs, commands, and demo entry points
- Added DS-ready pseudocode document covering DS-A primitives and pulse loop
- Added philosophy note on Dimensional Computing vs classical vs quantum
- Added signed CSV statement (Bc. Jiří Burda FAI UTB) describing DS architecture, accomplishments, and implementation plan

## v2.4.0
- UTB primitives: added conv2D baseline (global memory) vs shared-memory tile implementation
- UTB primitives: added 'benchmark suite' one-command script + auto report (CSV + plots + markdown)
- UTB primitives: added real PNG workflow using Python (Pillow) converters PNG<->DSRAW
- Added D-Link scaling benchmark (insight/topk) for 10k..1M dimensions CPU vs CUDA
- Docs: docs/26_utb_benchmark_suite.md, docs/27_dlink_scaling_benchmark.md

## v2.3.0
- Added CUDA primitives demo pack (UTB-style tasks) under apps/cuda_primitives_dlink/
  * Vector add
  * Matrix multiply (global memory baseline)
  * 2D RGB convolution (shared memory tile)
- Added DS-style 'pulse autotune' for choosing launch params (block/tile sizes) by timing objective
- Added sample PNG and scripts for building/running on Tesla
- Docs: docs/25_cuda_primitives_dlink.md

## v2.2.0
- Added dynamic 10D parameter optimizer demo (DS-lite) with polygon/radar graphs
- Added DS vs baselines comparison (fixed, random topK, full-sort topK)
- Added CPU vs CUDA benchmarking for DS-lite evaluation
- New app folder: apps/ds_dynamic_optimizer/
- New demo: examples/demo_ds_dynamic_10d_gpu_vs_baselines.py
- Docs: docs/24_dynamic_10d_optimizer.md

## v2.1.0
- Added default input dataset CSV: data/voltage_default.csv
- Added default results CSVs: runs/demo_results_error_vs_lanes.csv, runs/demo_results_topk.csv, runs/demo_results_benchmark.csv
- Added generator script: examples/generate_default_csv_results.py (rebuilds CSVs + plots + PDF)
- Docs: docs/23_csv_datasets_and_results.md

## v2.0.0
- Presentation Mode: single command runs teacher demo and exports a PDF report
- PDF generator: runs/teacher_demo_report.pdf (plots + definitions + benchmark table)
- Talk-track printed to terminal (what to say while presenting)
- Docs: docs/22_presentation_mode.md

## v1.9.0
- Teacher demo: Dimensional Expansion (DE) vs Dimensional Reduction (DR) visualizations
- CUDA vs CPU benchmark for D-Link roles (insight/topk/gateopt)
- New demo script outputs plots + a short report: runs/teacher_demo_*.png/md
- Docs: docs/21_teacher_demo_cuda.md

## v1.8.0
- D-Link Platform Selector: unified interface to choose CPU/CUDA/QPU backends
- New dlink_hub package inside dlink_cuda_app with CLI: dlinkctl
- Supports platforms: cpu, cuda, qpu-sim, qpu-cirq, qpu-engine (ready for future hardware)
- Added guided docs: docs/20_dlink_platform_selector.md
- New examples: examples/run_dlink_platform_selector.py

## v1.7.0
- Added D-Link CUDA/GPU app folder: dlink_cuda_app/
- GPU sampler backend (CuPy/Numba optional) implementing Dimensional Shift roles on GPU
- Backend selection extended: DSHIFT_ACCEL_BACKEND=cpu|cuda
- New demos: examples/run_dlink_cuda_app.py and examples/run_dimensional_shift_live_gpu.py
- Docs: docs/19_dlink_cuda_backend.md

## v1.6.0
- Live QPU job packets emitted in real time (qpu_job_submitted / qpu_job_result)
- QPUPolicyColony: consumes QPU job results and emits cfg/insight actions with explicit trace
- Job packet helpers + unified trace format
- New demo: examples/run_dimensional_shift_live_qpu_traced.py
- New docs: docs/18_qpu_policy_traces.md

## v1.5.0
- QPU job schema (problem_descriptor + circuit_hash + backend + shots + seed)
- QPU job bus packets: qpu_job_submitted / qpu_job_result
- Always-on QPU job logging (JSONL) + replay tool
- EngineSampler now emits job packets + writes standardized job logs
- New demos: examples/run_qpu_joblog_and_replay.py
- New docs: docs/17_qpu_job_schema_and_replay.md

## v1.4.0
- Added Google Quantum Engine backend skeleton (optional; requires cirq-google + access)
- EngineSampler: env-driven configuration, simulator fallback, circuit/job metadata logging
- Backend selection expanded: DSHIFT_QPU_BACKEND=sim|cirq|engine
- New demo: examples/run_dlink_quantum_bridge_engine.py
- New docs: docs/16_google_engine_backend.md

## v1.3.0
- Cirq simulator backend for D-Link (optional dependency)
- Problem→circuit mapping for all three roles using state-preparation sampling (simulator)
- Backend selection via env var DSHIFT_QPU_BACKEND = sim|cirq
- New demos: examples/run_dlink_quantum_bridge_cirq_sim.py
- Bridge hardening: consistent seeding + payload logging helpers

## v1.2.0
- D-Link Quantum Bridge (simulator-first) with three roles:
  1) Top-K selector (subset sampling)
  2) Gate schedule / breath optimizer
  3) Insight evaluator (stochastic scoring)
- Unified QPU adapter interface with fallback simulator (no external deps)
- Optional Cirq/Google Quantum Engine hooks (if available in environment)
- New demos: examples/run_dlink_quantum_bridge_sim.py and examples/run_dimensional_shift_live_qpu.py

## v1.1.0
- Live Dimensional Shift loop: breath updates applied in-flight with cfg_id rollover
- ConfigManager: applies cfg intents (SET_BREATH, BIRTH_DIM, KILL_DIM) and regenerates bundles
- Streaming encoder: per-sample gated 1-bit emission using active config
- Meta colony emits dim birth/kill intents (concept policy)
- New demo: examples/run_dimensional_shift_live.py

## v1.0.0
- Dimension Bus + packet schemas (time + cfg_id + phase invariants)
- Config bundles (kernels + gates + thresholds) with cfg_id replayability
- Router (pub/sub) with collision summarization + Top-K filtering
- Insight score bridge (summary -> insight packets) and filter policy wiring
- Transport abstraction + conceptual link adapters (PCIe/TSN/CAN-FD)
- PST-ADC / Dimensional-ADC reference pipeline (encode bits -> decode waveform)
- Colony hierarchy: ADC -> Detection -> Control -> Meta (cfg intent + PQ apply hooks)
- PQ signed bundle apply wiring (interfaces only; no crypto implementation)
