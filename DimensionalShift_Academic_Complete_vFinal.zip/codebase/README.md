## Dimensional Shift (PST) Prototype

# PST Product Package

Modular reference architecture + prototype for:
1) waveform reconstruction
2) grid/state detection
3) control
4) organism hierarchy + dimension evolution
5) quantum + post-quantum conceptual backend

## Quick run
```bash
python -m pst.sim_harness
python examples/run_replay.py
```

## Docs
- docs/01_architecture_overview.md
- docs/02_dimension_bus_spec.md
- docs/03_hardware_partition.md
- docs/04_software_services.md
- docs/05_quantum_pq_backend.md

## More examples
```bash
python examples/generate_cfg_bundle.py
python examples/run_router_demo.py
```

## PST-ADC example
```bash
python examples/run_pst_adc_pipeline.py
```

## Config-driven PST-ADC + Insight→TopK
```bash
python examples/run_pst_adc_pipeline_cfg.py
```

## Colony stack demo
```bash
python examples/run_colony_stack.py
```

## Dimensional Shift live demo (breath apply + dim birth/kill + cfg rollover)
```bash
python examples/run_dimensional_shift_live.py
```

## D-Link Quantum Bridge demos (simulator-first)
```bash
python examples/run_dlink_quantum_bridge_sim.py
python examples/run_dimensional_shift_live_qpu.py
```

## Cirq simulator backend (optional)
```bash
export DSHIFT_QPU_BACKEND=cirq
python examples/run_dlink_quantum_bridge_cirq_sim.py
```

## Google Quantum Engine backend (optional skeleton)
```bash
export DSHIFT_QPU_BACKEND=engine
python examples/run_dlink_quantum_bridge_engine.py
```

## QPU job logging + replay
```bash
python examples/run_qpu_joblog_and_replay.py
```

### QPU job log
Set optional log path:
```bash
export DSHIFT_QPU_LOG_PATH=runs/qpu_jobs.log
```

## Live QPU job packets + traced policy actions
```bash
python examples/run_dimensional_shift_live_qpu_traced.py
```

## D-Link CUDA / GPU demos (optional)
```bash
export DSHIFT_ACCEL_BACKEND=cuda
python examples/run_dlink_cuda_app.py
python examples/run_dimensional_shift_live_gpu.py
```

## D-Link platform selector (CPU/CUDA/QPU)
```bash
export DLINK_PLATFORM=cuda
python examples/run_dlink_platform_selector.py
```
See docs/20_dlink_platform_selector.md

## Teacher demo: DS as DE/DR (CUDA optional)
```bash
export DLINK_PLATFORM=cuda
python examples/demo_teacher_ds_cuda.py
```
See docs/21_teacher_demo_cuda.md

## Presentation Mode (one command + PDF)
```bash
export DLINK_PLATFORM=cuda
python examples/presentation_mode_teacher_demo.py
```
See docs/22_presentation_mode.md

## CSV datasets + results
Default input CSV: `data/voltage_default.csv`

Regenerate results:
```bash
python examples/generate_default_csv_results.py
```
See docs/23_csv_datasets_and_results.md

## Dynamic 10D DS optimizer demo (polygon/radar)
```bash
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda
python examples/demo_ds_dynamic_10d_gpu_vs_baselines.py
```
See docs/24_dynamic_10d_optimizer.md

## CUDA primitives (UTB tasks) — D-Link ready
```bash
cd apps/cuda_primitives_dlink
bash scripts/build.sh
bash scripts/run_examples.sh
```
See docs/25_cuda_primitives_dlink.md

## UTB benchmark suite (one command)
```bash
cd apps/cuda_primitives_dlink
bash scripts/benchmark_suite.sh
```
See docs/26_utb_benchmark_suite.md

## D-Link scaling benchmark (dimensions)
```bash
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda
python examples/benchmark_dlink_scaling.py
```
See docs/27_dlink_scaling_benchmark.md

## Final pack
See `Project D-Link/00_INDEX.md`.
