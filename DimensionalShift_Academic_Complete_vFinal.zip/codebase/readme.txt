DIMENSIONAL SHIFT — QUICK GUIDE (v1.0.0)

What this is
------------
This folder contains a modular prototype architecture + reference codebase for a "Dimensional Shift" system:
- Analog/body signal (voltage 0–230V) becomes multi-dimensional pulse/bit streams ("dimensions")
- An expand/collision rhythm (like heartbeat) alternates exploration vs compression
- A chained organism-of-organisms (colonies) decodes, detects, controls, and adapts configurations

Naming (PST-ADC vs Dimensional ADC vs Dimensional Shift)
-------------------------------------------------------
Internally, early files use the name "PST" = Pulse-Space Transduction.
- "PST-ADC" means: using PST pulse-space measurements to perform ADC-like reconstruction.
If you prefer a clearer product name, you can call it:
- "Dimensional ADC" (DADC): because conversion happens through multiple evolving dimensions.
- "Dimensional Shift": the overall architecture/model emphasizing expand↔collapse (dim-expansion vs dim-implosion).
Recommended: keep the code namespace 'pst' for now (stable), and brand the system as "Dimensional Shift".

Core idea (heartbeat analogy)
-----------------------------
Expand phase (Yang / "exhale"):
- allow many dimensions to stream (more basis choices, more kernels, more exploration)

Collision phase (Yin / "inhale"):
- compress: summarize, select Top-K dimensions, prune weak lanes (dimensional reduction / "dim-plosion")

This is a control rhythm:
- not only measuring, but choosing how measurement happens over time.

Where the "system is" in the code
---------------------------------
1) Dimension Bus (packets)
   - pst/dimension_bus.py
   - docs/02_dimension_bus_spec.md
   Invariants: every packet has time_ns + cfg_id + phase.

2) Config bundles (cfg_id = decoder truth)
   - schemas/config_bundle_example.json
   - runs/cfg_bundle.json (generated)
   - pst/config.py, pst/config_loader.py

3) Router + compression + Top-K
   - pst/router.py
   - pst/router_policies.py (TopKFilter)
   - pst/scoring.py (InsightScoreBridge)

4) Colonies (organisms-of-organisms)
   - pst/colonies/adc_colony.py       (bits -> waveform estimate + insight)
   - pst/colonies/detect_colony.py    (estimate -> anomaly)
   - pst/colonies/control_colony.py   (anomaly -> control intent)
   - pst/colonies/meta_colony.py      (control -> cfg intent; PQ apply hooks)
   - docs/11_colony_hierarchy.md

5) Post-quantum config apply wiring (concept)
   - pst/pq_apply.py
   - docs/12_pq_bundle_flow.md

Fast demos (recommended order)
------------------------------
A) Config-driven Dimensional-ADC pipeline:
   python examples/run_pst_adc_pipeline_cfg.py
   Output:
   - runs/cfg_bundle.json
   - runs/pst_adc_bits.log

B) Colony stack demo (ADC -> Detect -> Control -> Meta):
   python examples/run_colony_stack.py

Optional: Router demo reading the bits log:
   python examples/run_router_demo.py

Folder layout
-------------
docs/       architecture documents
schemas/    JSON schemas and example bundle
pst/        python reference implementation (bus, router, colonies, backends)
examples/   runnable demos
runs/       generated logs/bundles (created when you run examples)

Safety note
-----------
This prototype is architectural/software. Real 0–230V hardware requires isolation and certified design.


New in v1.1.0 (Dimensional Shift live control)
---------------------------------------------
- Live cfg application: Meta colony emits cfg intents, ConfigManager applies them, cfg_id rolls over.
- Breath control: SET_BREATH changes expand↔collision ratio at runtime.
- Dimensional birth/death: BIRTH_DIM adds a new lane; KILL_DIM removes a lane (Dim-plosion).
- Live demo:
   python examples/run_dimensional_shift_live.py

See: docs/13_dimensional_shift_control.md


Quantum Bridge (D-Link) in v1.2.0
---------------------------------
This version adds a simulator-first "Quantum Bridge" (QPU co-processor adapter) with three roles:
1) Top-K dimension selector (subset sampling)
2) Gate/Breath optimizer (Te/Tc tuning)
3) Insight evaluator (stochastic scoring per dimension)

Run demos:
- python examples/run_dlink_quantum_bridge_sim.py
- python examples/run_dimensional_shift_live_qpu.py

Docs:
- docs/14_dlink_quantum_bridge.md


QPU backend selection (v1.3.0)
------------------------------
Default: simulator-first backend (no dependencies)
- DSHIFT_QPU_BACKEND=sim

Optional: Cirq simulator backend (requires cirq installed)
- DSHIFT_QPU_BACKEND=cirq

Demo:
- python examples/run_dlink_quantum_bridge_cirq_sim.py


Google Quantum Engine backend (v1.4.0)
--------------------------------------
This version adds an OPTIONAL Engine backend skeleton. It is simulator-first and safe:
- export DSHIFT_QPU_BACKEND=engine
- python examples/run_dlink_quantum_bridge_engine.py

If you have cirq + cirq-google and Engine access, you can set:
- export DSHIFT_GOOGLE_USE_ENGINE=1
- export DSHIFT_GOOGLE_PROJECT_ID=...
- export DSHIFT_GOOGLE_PROCESSOR_ID=...
and extend the skeleton to actually submit jobs.

Docs:
- docs/16_google_engine_backend.md


QPU job logging + replay (v1.5.0)
---------------------------------
The bridge can log every QPU call in a standardized JSONL schema and replay it back into the bus.

Demo:
- python examples/run_qpu_joblog_and_replay.py

Log file:
- runs/qpu_jobs.log

Bus packet kinds produced by replay:
- qpu_job_submitted
- qpu_job_result

Docs:
- docs/17_qpu_job_schema_and_replay.md

Note: QPU job logging is always-on because the selected backend is wrapped by LoggingSampler.

New in v1.6.0: live QPU job packets + QPUPolicyColony actions with trace.
Run: python examples/run_dimensional_shift_live_qpu_traced.py

D-Link CUDA / GPU (v1.7.0)
--------------------------
This version adds a GPU co-processor app folder and project integration.
Folder:
- dlink_cuda_app/

Env:
- DSHIFT_ACCEL_BACKEND=cpu|cuda

Run:
- python examples/run_dlink_cuda_app.py
- python examples/run_dimensional_shift_live_gpu.py

Docs:
- docs/19_dlink_cuda_backend.md

D-Link platform selector (v1.8.0)
---------------------------------
You can now choose the D-Link platform (CPU/CUDA/QPU) from one interface.

Env:
- DLINK_PLATFORM=cpu|cuda|qpu-sim|qpu-cirq|qpu-engine
- DSHIFT_ACCEL_BACKEND=cpu|cuda   (used when platform is cpu/cuda)
- DSHIFT_QPU_BACKEND=sim|cirq|engine (used when platform is qpu-*)

Example:
- python examples/run_dlink_platform_selector.py

Docs:
- docs/20_dlink_platform_selector.md

Teacher demo (v1.9.0)
---------------------
Use this to demonstrate Dimensional Shift as:
- DE (Dimensional Expansion): more lanes => lower error (often)
- DR (Dimensional Reduction / Dim-plosion): Top-K selection

Run:
- export DLINK_PLATFORM=cuda  (or cpu)
- python examples/demo_teacher_ds_cuda.py

Outputs:
- runs/teacher_demo_error_vs_lanes.png
- runs/teacher_demo_dr_topk.png
- runs/teacher_demo_benchmark.png
- runs/teacher_demo_report.md

Docs:
- docs/21_teacher_demo_cuda.md

Presentation Mode (v2.0.0)
---------------------------
Single command runs teacher demo + exports a PDF report + prints a talk-track.

Run:
- export DLINK_PLATFORM=cuda  (or cpu)
- python examples/presentation_mode_teacher_demo.py

Outputs:
- runs/teacher_demo_report.pdf
Docs:
- docs/22_presentation_mode.md

CSV datasets + results (v2.1.0)
------------------------------
Input:
- data/voltage_default.csv

Precomputed results:
- runs/demo_results_error_vs_lanes.csv
- runs/demo_results_topk.csv
- runs/demo_results_benchmark.csv

Regenerate:
- python examples/generate_default_csv_results.py

Docs:
- docs/23_csv_datasets_and_results.md

Dynamic 10D DS optimizer demo (v2.2.0)
-------------------------------------
New app: apps/ds_dynamic_optimizer/
Demonstrates dynamic DE/DR and 10D parameter evolution with polygon/radar graphs.

Run:
- export DLINK_PLATFORM=cuda
- export DSHIFT_ACCEL_BACKEND=cuda
- python examples/demo_ds_dynamic_10d_gpu_vs_baselines.py

Outputs in runs/:
- ds_dynamic_polygon.png
- ds_dynamic_params.csv
- ds_dynamic_report.md

Docs:
- docs/24_dynamic_10d_optimizer.md

CUDA primitives (UTB tasks) — D-Link ready (v2.3.0)
---------------------------------------------------
New C/C++ CUDA app:
- apps/cuda_primitives_dlink/

Build:
- cd apps/cuda_primitives_dlink
- bash scripts/build.sh

Run:
- bash scripts/run_examples.sh

Docs:
- docs/25_cuda_primitives_dlink.md

UTB Benchmark Suite (v2.4.0)
----------------------------
- apps/cuda_primitives_dlink/scripts/benchmark_suite.sh

D-Link scaling benchmark (v2.4.0)
---------------------------------
- python examples/benchmark_dlink_scaling.py

Final pack (v2.5.0): see Project D-Link/00_INDEX.md
