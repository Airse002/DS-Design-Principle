# D-Link scaling benchmark (Dimensional Shift roles)

This benchmark runs DS/D-Link role computations as dimension count increases:
- `insight_eval` (score all dimensions)
- `topk_subset` (Dim-plosion / DR selection)

Outputs:
- `runs/dlink_scaling.csv`
- `runs/dlink_scaling_insight_s.png`
- `runs/dlink_scaling_topk_s.png`

Run on Tesla:
```bash
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda
python examples/benchmark_dlink_scaling.py
```
