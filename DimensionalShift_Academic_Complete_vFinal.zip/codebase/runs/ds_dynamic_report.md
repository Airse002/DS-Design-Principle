# Dynamic 10D DS Optimizer Demo (DS-lite)

Platform selected: **cpu**

## What this demonstrates
- **DE (Dimensional Expansion):** lanes increase/decrease over cycles.
- **DR (Dimensional Reduction / Dim-plosion):** Top-K keep changes over cycles.
- **Dynamic parameters:** 10D parameter vector adapts each cycle to reduce objective.
- **GPU readiness:** evaluation can run on CUDA via CuPy when installed.

## Outputs
- runs/ds_dynamic_objective.png
- runs/ds_dynamic_rmse.png
- runs/ds_dynamic_de_dr.png
- runs/ds_dynamic_polygon.png  (polygon/radar snapshots)
- runs/ds_vs_baselines_rmse.png
- runs/ds_vs_baselines_time.png
- runs/ds_cpu_vs_platform.png
- CSV: runs/ds_dynamic_params.csv
- Benchmark CSV: runs/ds_dynamic_benchmark_cpu_vs_platform.csv

## Final best parameters
{'lanes': 251, 'k_keep': 142, 'kernel_L': 15, 'threshold': 9.428745846350713, 'noise_std': 0.04975902150326522, 'stride': 5, 'calib_frac': 0.262866944037794, 'te': 589, 'tc': 572, 'alpha_time': 0.27822877003225677}

## DS vs baselines (rmse/sec)
- fixed_ds: rmse=19.9007, sec=0.0055
- randomish_topk: rmse=22.9238, sec=0.0063
- fullsort_topk: rmse=22.4243, sec=0.0063
- best_ds: rmse=20.8127, sec=0.0039

## CPU vs cpu
- rmse cpu=19.7133 vs platform=19.7133
- sec  cpu=0.0029 vs platform=0.0254

