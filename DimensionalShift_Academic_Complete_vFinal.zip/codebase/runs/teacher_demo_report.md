# Dimensional Shift (DS) — Teacher Demo

Platform selected: **cpu**

## What DS shows
- **DE (Dimensional Expansion):** add lanes (dimensions) → more projections → typically lower reconstruction error.
- **DR (Dimensional Reduction / Dim-plosion):** select Top-K lanes based on insight → drop the rest (policy-driven compression).
- **Heartbeat / breath:** Te/Tc controls expand vs collision phases (not shown in plots, but part of DS loop).

## Outputs
- runs/teacher_demo_error_vs_lanes.png  (DE: error vs lanes)
- runs/teacher_demo_dr_topk.png  (DR: Top-K selection)
- runs/teacher_demo_benchmark.png  (Compute benchmark)

## Numbers
DE lanes list: [4, 6, 8, 10, 12, 16, 20]
DE RMSE: [157.98094134128212, 157.98094134128212, 157.98094134128212, 157.98094134128212, 157.98094134128212, 157.98094134128212, 157.98094134128212]

Benchmark CPU (s): [7.603499989272677e-05, 0.00010477899991201411, 0.0002679630001694022]
Benchmark cpu (s): [7.603499989272677e-05, 0.00010477899991201411, 0.0002679630001694022]

Top-K kept: 8 / 16

