# Project D-Link — EXPORT REPORT

Generated: 2026-01-24T04:45:15

## Environment
- DLINK_PLATFORM=cpu
- DSHIFT_ACCEL_BACKEND=cpu

## Artifacts found in runs/
- ⛔ `utb_bench.csv` (missing)
- ⛔ `utb_bench_report.md` (missing)
- ⛔ `utb_bench_plot_ms.png` (missing)
- ⛔ `utb_conv_speedup.png` (missing)
- ⛔ `out_blur_shared.png` (missing)
- ⛔ `out_blur_global.png` (missing)
- ✅ `ds_dynamic_polygon.png` (183283 bytes)
- ✅ `ds_vs_baselines_rmse.png` (51217 bytes)
- ✅ `ds_vs_baselines_time.png` (70870 bytes)
- ✅ `ds_cpu_vs_platform.png` (52624 bytes)
- ✅ `dlink_scaling.csv` (214 bytes)
- ✅ `dlink_scaling_insight_s.png` (72232 bytes)
- ✅ `dlink_scaling_topk_s.png` (65489 bytes)

## Interpretation guide
- `utb_conv_speedup.png`: compare conv2d global vs shared; shared should typically be faster.
- `utb_bench_report.md`: explains DS pulse (expand/collapse) and why shared memory helps.
- `ds_dynamic_polygon.png`: shows 10D parameter state evolving across cycles (DS as organism).
- `dlink_scaling_*`: shows role scaling with dimensions; CUDA should help if CuPy is active.

## Notes on 'DS is faster'
- DS is an architecture: it can be faster *by selecting faster configurations* and pruning dimensions.
- EXPAND adds overhead, but COLLAPSE uses the best policy/config afterward.
- For conv2d specifically, shared-memory tiling is a known performance improvement over global baseline.
