# Binding Insight → Collision Top-K

Collision compresses dimensionality. Rule:
- Expand: allow new dims
- Collision: keep only highest insight dims

Reference binding:
1) Router collision summarizers emit `*_summary` packets
2) InsightScoreBridge converts summaries to `kind='insight'` packets
3) TopKFilter keeps only top-k dims in collision

Files:
- pst/router.py
- pst/router_policies.py
- pst/scoring.py
