# PST Dimension Bus Spec (PDB v0.1)

The **Dimension Bus** is a substrate-agnostic protocol that can run over PCIe, TSN/EtherCAT, CAN-FD, SPI/UART, LVDS/JESD, etc.
It makes dimensions modular and hot-pluggable across software, hardware, and links.

## Dimension Module registration
A dimension module registers:
- `dim_id` (uint64), `kind`, `rate_hz`, `latency_us`, `clock_domain`, `calibration`, `cfg_id`

## Packet families

### DATA packet (time-stamped)
Required:
- `time_ns`, `clock_domain`, `dim_id`, `kind`, `phase` (+1/-1), `cfg_id`, `payload`

Optional:
- `seq`, `quality`, `routing` tags

### CONTROL packet (reconfiguration)
Required:
- `time_ns`, `clock_domain`, `target` (dim_id or broadcast), `cmd`, `cfg_id`, `body`

## Replayability requirement
For reconstruction, every DATA packet must be decodable later:
- must include `cfg_id`, and host must fetch the corresponding config bundle.
