# D-Link Quantum Bridge (QPU ↔ Linux) — Simulator-first

You asked for a bridge between a Linux PC and a Google quantum chip.
Practically, the QPU is a *co-processor* controlled by the Linux host via a job API.
So the "OS layer" lives on Linux, and the QPU is accessed through a bridge adapter.

This repo implements a **D-Link Quantum Bridge** in a simulator-first way:
- Runs with **no external dependencies** (pure Python + numpy)
- Provides optional hooks for **Cirq** and **Google Quantum Engine** if present

## Three QPU roles implemented
1) **Top-K selector** (subset sampler)
   - Input: candidate dimension ids + (optional) scores/priors
   - Output: selected subset ids (size K)
   - Use: collision phase dimensional reduction; choose which lanes survive

2) **Gate schedule / breath optimizer**
   - Input: current breath (Te/Tc) + constraints + objective proxy
   - Output: new breath parameters and/or per-dim gate tweaks
   - Use: adjust Yin/Yang ratio to trade stability vs exploration

3) **Insight evaluator**
   - Input: feature summaries, reconstruction errors, anomaly signals
   - Output: stochastic insight scores per dimension (BusPackets kind='insight')
   - Use: drive Top-K filter and birth/kill decisions

## Key design rule
The bridge always returns **Dimension Bus packets** with:
- time_ns, cfg_id, phase
so results are replayable and auditable.

See:
- pst/qpu/dlink_qpu.py (interfaces)
- pst/qpu/sim_backend.py (fallback sampler)
- pst/qpu/roles/*.py (the three roles)
- examples/run_dlink_quantum_bridge_sim.py
- examples/run_dimensional_shift_live_qpu.py
