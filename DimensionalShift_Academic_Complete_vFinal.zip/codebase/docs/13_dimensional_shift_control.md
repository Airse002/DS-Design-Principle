# Dimensional Shift Control (Live Heartbeat + Dim Birth/Death)

This version adds end-to-end **live application** of breath + dimensions.

## Control primitives (cfg intents)
These are BusPackets with kind `cfg` and payload `cmd`:

- `SET_BREATH {Te, Tc}`
  - changes expand/collision rhythm (the "heart rate" / yin-yang ratio)

- `BIRTH_DIM {optional dim_id, seed, P, d, delta, threshold}`
  - adds a new projection dimension (new lane)

- `KILL_DIM {optional dim_id}`
  - removes a dimension; if none specified, removes lowest-score dim

Applying any of these triggers:
- cfg bundle regeneration
- **cfg_id rollover**
- a `cfg_applied` packet is emitted

## Live demo
Run:
- `python examples/run_dimensional_shift_live.py`

It streams a voltage signal, emits pulse/bits, reconstructs windows, detects anomalies,
and uses Control→Meta policy to generate cfg intents that actually modify the running system.
