# Pulse-Space Transduction Platform (PST) — Architectonic Design

This package is an end-to-end *product architecture* for your idea:

- **0–230V voltage** is the machine's body sense (interoception).
- A **Pulse-Space Transduction (PST)** front-end converts signals into a multi-dimensional pulse/bit field.
- A **chained organism-of-organisms** runtime learns, compresses, and evolves dimensions.
- Supports **(1) waveform reconstruction**, **(2) grid/state detection**, **(3) control**, **(4) hierarchy growth**, plus **(5) quantum + post-quantum conceptual backend**.
- Every layer is **dimensionally expandable**: software dims, hardware dims, and link dims.

## Default operating point
- Default sampling rate: **10 kHz** (good compromise for waveform + events + learning).
- Dimension count grows from **≥ 9** base voltage senses.

## Two invariants (to keep it decodable)
**Invariant A: each dimension is a module**
- Every dimension has an identity (`dim_id`), type, rate, calibration, and config version.

**Invariant B: the link carries time + config**
- Every measurement references: `timestamp`, `phase`, and `cfg_id` (kernel/gate/threshold version).

See:
- `docs/02_dimension_bus_spec.md`
- `schemas/dimension_bus.schema.json`
