# D-Link Platform Selector (CPU / CUDA / QPU)

You wanted the D-Link app to choose between platforms, and to be ready for a future quantum chip.
This version introduces a **unified selector** that routes the same role problems to:

- **CPU** (NumPy fallback)
- **CUDA** (Tesla/NVIDIA via CuPy when installed)
- **QPU backends** (sim / cirq / engine skeleton)

## Where it lives
- `dlink_cuda_app/dlink_hub/platform_select.py`
- `dlink_cuda_app/dlink_hub/cli.py` (CLI: `dlinkctl`)

## Platforms
Set one of:
- `DLINK_PLATFORM=cpu`
- `DLINK_PLATFORM=cuda`
- `DLINK_PLATFORM=qpu-sim`
- `DLINK_PLATFORM=qpu-cirq`
- `DLINK_PLATFORM=qpu-engine`

## Roles (what you can run)
1) `insight_eval`  — scores dimensions (supports Dimensional Shift Top-K + birth/kill)
2) `topk_subset`   — selects which dimensions to keep (Dim-plosion decision)
3) `gate_opt`      — proposes new breath parameters (Te/Tc)

## Quick CLI tests
From project root:

CPU:
```bash
python -m dlink_hub.cli --platform cpu --kind insight_eval
```

CUDA (will use GPU if CuPy is installed and CUDA works):
```bash
export DSHIFT_ACCEL_BACKEND=cuda
python -m dlink_hub.cli --platform cuda --kind topk_subset
```

QPU simulator:
```bash
export DSHIFT_QPU_BACKEND=sim
python -m dlink_hub.cli --platform qpu-sim --kind gate_opt
```

## Ready for future quantum
`qpu-engine` uses the existing Engine skeleton in `pst/qpu/google_engine_backend.py`.
It is simulator-first and logs job records; when you later have access, you can set:
- `DSHIFT_GOOGLE_USE_ENGINE=1`
- `DSHIFT_GOOGLE_PROJECT_ID=...`
- `DSHIFT_GOOGLE_PROCESSOR_ID=...`

## Recommended workflow for you now (no QPU yet)
1) Validate the architecture using `qpu-sim` (replayable job logs)
2) Accelerate roles using `cuda` on Tesla
3) Keep QPU path ready by preserving the same problem descriptors and traces.
