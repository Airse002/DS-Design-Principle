# Transport Layer Options (How SW ↔ HW Links Scale Dimensionally)

The **Dimension Bus** is transport-agnostic. This package provides *interfaces* for multiple physical links.

## Transport classes
- **Tight coupled**: PCIe DMA rings (best for reconstruction + low latency control)
- **Deterministic distributed**: Ethernet TSN / EtherCAT (best for multi-node colonies)
- **Embedded**: CAN-FD / SPI / UART (best for config + low-rate senses)
- **Converter lanes**: JESD204B/C (ADC-to-FPGA high-rate)

## What must be preserved over any transport
- `time_ns` + `clock_domain`
- `cfg_id`
- `phase`
- ordering per-dimension (optional `seq` field)

## Interfaces included
- `pst/transport.py`: abstract transport + in-process transport
- `pst/link_adapters/*.py`: conceptual adapters for PCIe/TSN/CAN
