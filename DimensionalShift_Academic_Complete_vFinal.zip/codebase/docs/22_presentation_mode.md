# Presentation Mode (one command)

Goal: demonstrate Dimensional Shift (DS) to a teacher in a clean, reproducible way.

## What it does
Running a single command will:
1) Generate DE + DR plots and a markdown report (same as teacher demo)
2) Export a PDF report containing:
   - DS definitions (DE/DR/breath)
   - Plots (error vs lanes, top-k DR, cpu vs platform timing)
   - Key numeric results
3) Print a talk-track script in the terminal.

## Run
From repo root:

```bash
# CPU presentation
export DLINK_PLATFORM=cpu
python examples/presentation_mode_teacher_demo.py
```

For Tesla/CUDA:

```bash
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda
python examples/presentation_mode_teacher_demo.py
```

Outputs in `runs/`:
- `teacher_demo_error_vs_lanes.png`
- `teacher_demo_dr_topk.png`
- `teacher_demo_benchmark.png`
- `teacher_demo_report.md`
- `teacher_demo_report.pdf`
