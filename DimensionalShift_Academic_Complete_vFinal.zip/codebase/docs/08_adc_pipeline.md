# PST-ADC Pipeline (Waveform Reconstruction) — Reference Flow

This package now includes a full **software reference pipeline** for goal (1):

1. **Signal source**: a voltage waveform `x[t]` (0..230V or normalized).
2. **Transduction**: create *dimension lanes* (projection kernels + gates + thresholds).
3. **Bitstream emission**: for each lane, emit **1-bit measurements** over time (optionally gated).
4. **Logging**: write all packets with `time_ns`, `dim_id`, `phase`, `cfg_id`.
5. **Decode**: reconstruct waveform via sign-consistency optimization.
6. **Detect**: run power-quality features + anomaly scoring.
7. **Control**: compute reflex SAFE_MODE and optionally adjust breath/gates.

Files:
- `pst/backends/digital_backend.py`: reference gated 1-bit projection encoder.
- `pst/decoder_waveform.py`: reference decoder (logistic loss).
- `examples/run_pst_adc_pipeline.py`: end-to-end simulation + reconstruction report.

Replayability rule:
- Every DATA packet references `cfg_id`.
- Config bundle must be available during decode to know kernels/gates/thresholds.
