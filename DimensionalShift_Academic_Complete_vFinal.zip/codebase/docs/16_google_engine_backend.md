# Google Quantum Engine Backend (Skeleton)

This repo includes an **optional** backend that shows how to wire Dimensional Shift's D-Link bridge to
Google's Quantum Engine ecosystem, while remaining safe and runnable without access.

File:
- `pst/qpu/google_engine_backend.py`

## What it does today
- Accepts the same `problem` descriptors as the D-Link roles
- Builds a placeholder Cirq circuit and runs it on **Cirq Simulator**
- Logs circuit/job metadata to: `runs/qpu_jobs.log`
- If `DSHIFT_GOOGLE_USE_ENGINE=1`, attempts to import `cirq_google` and logs a submission attempt

## What you need for real QPU runs
- Install `cirq` and `cirq-google`
- Have Quantum Engine access (project + processor id)
- Implement hardware-compatible role circuits (instead of state-prep prototyping)

## Env vars
- `DSHIFT_QPU_BACKEND=engine`
- `DSHIFT_GOOGLE_PROJECT_ID=...`
- `DSHIFT_GOOGLE_PROCESSOR_ID=...`
- `DSHIFT_GOOGLE_USE_ENGINE=1` (optional)
- `DSHIFT_QPU_LOG_PATH=runs/qpu_jobs.log` (optional)

## Demo
- `python examples/run_dlink_quantum_bridge_engine.py`
