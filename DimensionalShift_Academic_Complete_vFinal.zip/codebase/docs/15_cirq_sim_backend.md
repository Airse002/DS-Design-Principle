# Cirq Simulator Backend

This backend enables the D-Link bridge to run the three roles using Cirq's simulator.

Enable:
- export DSHIFT_QPU_BACKEND=cirq
- install cirq (e.g., `pip install cirq`)

Notes:
- The current mapping uses **state preparation** to sample from a desired distribution.
- This is ideal for prototyping and reproducibility.
- Hardware execution would require different circuit constructions for amplitude prep.
