# Dynamic 10D Optimizer Demo (DS-lite) + Polygon Graphs

This app is a **GPU-friendly demonstration** of Dimensional Shift as a living system:
- DE (Dimensional Expansion): changing number of lanes (dimensions)
- DR (Dimensional Reduction / Dim-plosion): Top-K survival
- A 10D parameter vector that adapts over time
- Optional CUDA acceleration via Tesla (CuPy)

## Folder
- `apps/ds_dynamic_optimizer/`

Key files:
- `ds_lite.py` — DS-lite evaluation (vectorized; CUDA-ready)
- `runner.py` — dynamic optimization loop + plots/CSVs
- `baselines.py` — fixed/random/fullsort comparison

## Run
CPU:
```bash
export DLINK_PLATFORM=cpu
export DSHIFT_ACCEL_BACKEND=cpu
python examples/demo_ds_dynamic_10d_gpu_vs_baselines.py
```

Tesla/CUDA:
```bash
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda
python examples/demo_ds_dynamic_10d_gpu_vs_baselines.py
```

## Output artifacts (runs/)
- `ds_dynamic_params.csv`  (per-cycle 10D params + objective)
- `ds_dynamic_polygon.png` (polygon/radar snapshots)
- `ds_dynamic_de_dr.png`   (lanes and k_keep over cycles)
- `ds_vs_baselines_rmse.png` / `ds_vs_baselines_time.png`
- `ds_cpu_vs_platform.png`
- `ds_dynamic_report.md`

## Baselines
- `fixed_ds` — no adaptation beyond current params
- `randomish_topk` — degraded lane selection (approx random)
- `fullsort_topk` — slower Top-K selection method
- `best_ds` — adaptive DS after optimization cycles
