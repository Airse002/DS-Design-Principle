# Signed Bundle Flow (Concept)

- Envelope: (cfg_id, bundle_json, signature, signer_id)
- Verify signature (PQ/hybrid) before applying
- Apply updates active cfg_id and future packet emission

Code: `pst/pq_apply.py`, `pst/colonies/meta_colony.py`
