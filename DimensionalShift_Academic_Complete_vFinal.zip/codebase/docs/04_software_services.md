# Software Services (Reference Modules)

- Dimension Registry: dim discovery + cfg bundle mapping
- Logger + Replay: append-only bus log; deterministic replay
- Decoder services: waveform reconstruction + event extraction
- Detector services: grid/state detection (ripple, sag/swell, anomalies)
- Organism runtime: chained organisms + colonies + super-organisms
- Controller: reflex override + higher-level policies

Dimensional expansion: add new producer/consumer modules without changing others.
