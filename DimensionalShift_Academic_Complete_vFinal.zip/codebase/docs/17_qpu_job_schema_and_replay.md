# QPU Job Schema + Replay

Dimensional Shift requires that QPU calls are **replayable** and **auditable** like pulse logs.
This version adds:

- A standardized QPU job record (JSONL): **QPUJobRecord**
- Always-on logging via a sampler wrapper: **LoggingSampler**
- A replayer that converts logs back into Dimension Bus packets

## QPUJobRecord (JSONL)
File: `pst/qpu/job_schema.py`

Fields include:
- job_id, ts_utc
- backend (sim|cirq|engine), mode (call|result|error)
- cfg_id, phase, time_ns, clock_domain
- problem descriptor (JSON)
- shots, seed
- circuit_text + circuit_hash (optional)
- result or error

Default log path:
- `runs/qpu_jobs.log`

## Always-on logging
File: `pst/qpu/logging_sampler.py`

Backend selection always returns a logging wrapper. See:
- `pst/qpu/backend_select.py`

## Replay → Bus Packets
File: `pst/qpu/job_replay.py`

Converts job records into bus packets:
- `qpu_job_submitted`
- `qpu_job_result`

## Demo
- `python examples/run_qpu_joblog_and_replay.py`
