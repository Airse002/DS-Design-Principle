# Dimension Bus Router (Pub/Sub + Bandwidth Shaping)

This repo includes a lightweight in-process router in `pst/router.py`.

## What it does
- **Pub/Sub**: subscribers can filter by `kind`, `dim_id`, or a custom predicate
- **Bandwidth shaping**: in collision phase, apply summarizers (downsample, aggregate, top-k)
- **Backpressure-friendly**: if a subscriber is slow, you can drop or coalesce messages

## Default shaping policies
- Expand phase: forward packets as-is
- Collision phase:
  - `feature` packets: aggregate over a window (mean/std/min/max + n)
  - `bit`/`spike`/`projection_1bit`: count packets and ones per window
