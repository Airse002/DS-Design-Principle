# UTB Benchmark Suite (D-Link / Dimensional Shift pulse)

Folder:
- `apps/cuda_primitives_dlink/`

## What you can demonstrate
- Vector add
- Matrix multiply (global memory baseline)
- Conv2D RGB: **global baseline vs shared-memory tile**

## DS is used in all UTB benchmarking
Every op is wrapped in a DS pulse:
- `--mode expand`  = **DE** (explore candidates)
- `--mode collapse`= **DR** (choose best and run)

## Build
```bash
cd apps/cuda_primitives_dlink
bash scripts/build.sh
```

## "Benchmark button" (one command)
```bash
bash scripts/benchmark_suite.sh
```

Outputs in `runs/`:
- `utb_bench.csv`
- `utb_bench_report.md`
- `utb_bench_plot_ms.png`
- `utb_conv_speedup.png`
- `out_blur_shared.png`, `out_blur_global.png`

## Real PNG workflow
CUDA binary reads/writes DSRAW RGBA. Convert using Pillow scripts:
```bash
python scripts/png_to_dsraw.py --in in.png --out runs/in.dsraw
python scripts/dsraw_to_png.py --in runs/out.dsraw --out out.png
```
