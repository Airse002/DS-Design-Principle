# QPU Policy Actions with Trace

This version adds an explicit "why" chain from QPU decisions to Dimensional Shift actions.

## Live job packets
When the QPU bridge runs, it emits:
- `qpu_job_submitted`
- `qpu_job_result`

These packets include job_id, problem descriptor, shots/seed, and results/errors.

## QPUPolicyColony
File: `pst/colonies/qpu_policy_colony.py`

Consumes `qpu_job_result` and emits:
- `insight` packets (from insight_eval results)
- `cfg` intents:
  - `SET_BREATH` from gate_opt results
  - `KILL_DIM` (Dim-plosion) from topk subset results

Every emitted packet carries:
- `payload.trace = { job_id, source: 'qpu_policy', action: ... }`

## Demo
- `python examples/run_dimensional_shift_live_qpu_traced.py`

Try switching backends:
- `export DSHIFT_QPU_BACKEND=sim`
- `export DSHIFT_QPU_BACKEND=cirq`
- `export DSHIFT_QPU_BACKEND=engine` (skeleton, simulator-first)
