# Quantum + Post-Quantum Conceptual Backend

## Quantum backend mapping (concept)
- dimension = measurement setting/operator (POVM)
- breath = basis switching (expand explores, collision refines)
- output = shot-based classical bits
- decode = parameter estimation (MLE/Bayes)

See `pst/backends/quantum_backend_interface.py`.

## Post-quantum control plane (concept)
- signed config bundles (prevents malicious dimension changes)
- PQ/hybrid key exchange for control channels
- versioned attestation for modules

See `pst/backends/pq_control_plane.py`.
