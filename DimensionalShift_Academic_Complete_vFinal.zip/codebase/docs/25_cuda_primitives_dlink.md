# D-Link ready CUDA primitives (UTB tasks)

You provided UTB tasks screenshots:
- vector addition
- matrix multiplication in global memory
- 2D convolution over RGB image with shared memory optimization, PNG I/O

This repo now includes a **C/C++ CUDA** demonstration app aligned with those tasks:
`apps/cuda_primitives_dlink/`

## Why this is "D-Link" + "DS"
The primitives are wrapped in a DS-like "pulse" loop:

- `--mode expand`: explore candidate kernel launch configurations (block sizes), measure time (objective)
- `--mode collapse`: keep the best configuration and execute

This is analogous to:
- **DE**: expand candidates / explore
- **DR**: reduce to best choice (Dim-plosion)

## Build / run on Tesla K40
```bash
cd apps/cuda_primitives_dlink
bash scripts/build.sh
bash scripts/run_examples.sh
```

## Tips for your course tooling
- Use Nsight for profiling:
  - run the binary and capture kernel times
- Use `runs/primitives_timing.csv` for reporting

## Notes about PNG I/O
For simplicity, the repo includes a compact codec wrapper. If your course requires `libpng++` explicitly,
swap `include/lodepng.*` with your school's provided `libpng++` utilities and keep kernel code unchanged.
