# D-Link scaling benchmark (CPU vs CUDA)

File:
- `examples/benchmark_dlink_scaling.py`

Measures DS/D-Link role computations as number of dimensions increases:
- `insight_eval`
- `topk_subset`

Outputs:
- `runs/dlink_scaling.csv`
- `runs/dlink_scaling_insight_s.png`
- `runs/dlink_scaling_topk_s.png`

Run on Tesla:
```bash
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda
python examples/benchmark_dlink_scaling.py
```
