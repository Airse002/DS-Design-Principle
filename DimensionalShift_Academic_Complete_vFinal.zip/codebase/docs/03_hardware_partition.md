# Hardware Partition (Reference Design)

## Safety note
0–230V systems require isolation/protection/compliance. This is architectural.

## Partition
### A) HV Front End
- isolated voltage acquisition, protection, optional current/temp/EMI add-ons

### B) FPGA/SoC Transduction Engine
- timestamping, breath generator, gate fabric
- projection lanes (FIR/integrate-and-dump/random demodulators)
- comparators (1-bit, sigma-delta, time encoding)
- collision edge-compression

Each lane is a *dimension bank*. Add lanes = dimensional expansion.

### C) MCU Reflex + Boot
- safe-mode reflex, config guardrails, attestation hooks
- side-band link to FPGA and/or host

### D) Host Link choices
- PCIe DMA (tight, best for reconstruction)
- TSN/EtherCAT (distributed deterministic colonies)
- JESD204B/C (ADC-to-FPGA)
- CAN-FD/SPI/UART (config + low-rate telemetry)
