# Teacher Demo (Tesla/CUDA): Dimensional Shift as DE/DR

This demo is designed to show a teacher what **Dimensional Shift (DS)** does in practical terms:
- **DE (Dimensional Expansion):** increase number of projection dimensions (lanes)
- **DR (Dimensional Reduction / Dim-plosion):** select a Top-K subset of lanes and drop the rest
- **Heartbeat / breath:** Te/Tc controls exploration vs compression phases

The demo also benchmarks **CUDA vs CPU** role execution using the D-Link platform selector.

## What you will show
1) A plot of reconstruction error vs number of lanes (DE)
2) A plot showing error after Top-K selection (DR)
3) Timing comparison of role math on CPU vs CUDA (if CuPy installed and GPU available)

## Run (from repo root)
```bash
# optional: use GPU
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda

python examples/demo_teacher_ds_cuda.py
```

Outputs in `runs/`:
- `teacher_demo_error_vs_lanes.png`
- `teacher_demo_dr_topk.png`
- `teacher_demo_benchmark.png`
- `teacher_demo_report.md`

## Notes for presenting
- "DE" is not claiming extra physical dimensions; it is representational expansion.
- "DR" is information-preserving selection (policy-driven) plus optional compression.
- The role computations are co-processor-friendly (GPU/QPU/CPU) while the bus protocol stays stable.
