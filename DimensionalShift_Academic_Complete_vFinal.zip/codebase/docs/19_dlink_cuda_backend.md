# D-Link CUDA / GPU Backend

This folder adds a GPU co-processor option for Dimensional Shift called **D-Link CUDA**.
It targets NVIDIA GPUs (e.g., Tesla) using **CuPy** when available, and falls back to NumPy if not.

## Folder
- `dlink_cuda_app/` — standalone GPU role app
- `pst/gpu/dlink_cuda_bridge.py` — project integration producing bus packets

## Env
- `DSHIFT_ACCEL_BACKEND=cpu` (default)
- `DSHIFT_ACCEL_BACKEND=cuda` (try CuPy; fallback to CPU)

## What it accelerates (prototype)
- insight evaluator
- top-k selection
- breath optimization

## Demos
- `python examples/run_dlink_cuda_app.py`
- `python examples/run_dimensional_shift_live_gpu.py`
