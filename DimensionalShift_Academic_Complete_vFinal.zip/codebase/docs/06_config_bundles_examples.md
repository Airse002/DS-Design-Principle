# Config Bundles — Examples (cfg_id)

A **config bundle** is the single source of truth for decoding/replay.
It contains:
- breath schedule (Te/Tc)
- dimension definitions (kernels, gates, thresholds)
- optional safety constraints and calibration metadata

Every DATA packet references `cfg_id`, and the host must be able to fetch the bundle by `cfg_id`.

## Minimal example
See `schemas/config_bundle_example.json`.

## Notes
- `kernel_plus` and `kernel_minus` are basis-switching kernels for expand/collision.
- `gate` defines PWM gating parameters for that dimension lane.
- Hardware can implement kernels as FIR / integrate-and-dump; software can emulate or decode.
