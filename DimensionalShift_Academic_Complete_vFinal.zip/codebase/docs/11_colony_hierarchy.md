# Colony Hierarchy

- ADC Colony: bits → estimate_waveform_chunk + insight
- Detection Colony: estimate → anomaly
- Control Colony: anomaly → control intent
- Meta Colony: control intent → cfg intent (+ PQ bundle apply hook)

Run: `python examples/run_colony_stack.py`
