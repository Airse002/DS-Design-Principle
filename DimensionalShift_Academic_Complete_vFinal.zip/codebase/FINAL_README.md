# Project D-Link — Final Release (v2.6.0)

Open `Project D-Link/00_INDEX.md` for the curated demo pack.

Key files:
- `Project D-Link/DS_PSEUDOCODE.md`
- `Project D-Link/DIMENSIONAL_COMPUTING_PHILOSOPHY.md`
- `Project D-Link/BC_JIRI_BURDA_STATEMENT.csv`
