import numpy as np
from pathlib import Path

from pst.config_loader import ensure_example_bundle, bundle_cfg_id, bundle_breath, bundle_projection_dims
from pst.backends.digital_backend import DigitalPSTEncoder
from pst.dimension_bus import BusPacket
from pst.router import Router, Subscription
from pst.router_policies import TopKFilter

from pst.colonies.adc_colony import ADCColony
from pst.colonies.detect_colony import DetectionColony
from pst.colonies.control_colony import ControlColony
from pst.colonies.meta_colony import MetaColony

def simulate_voltage(fs_hz: float, seconds: float, mains_hz: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t) + rng.normal(0.0, 1.5, size=N)
    for _ in range(4):
        idx = int(rng.integers(0, max(1, N-200)))
        if rng.random() < 0.5:
            x[idx:idx+80] -= rng.uniform(30, 80)
        else:
            x[idx:idx+40] += rng.uniform(20, 60)
    return np.clip(x, 0.0, 230.0)

def main():
    fs_hz = 10_000.0
    seconds = 0.2
    x = simulate_voltage(fs_hz, seconds, seed=2).astype(float)
    N = x.size

    bundle_path = Path("runs/cfg_bundle.json")
    bundle = ensure_example_bundle(bundle_path, fs_hz=fs_hz, lanes=8, L=16)
    cfg_id = bundle_cfg_id(bundle)
    breath = bundle_breath(bundle)
    dims = bundle_projection_dims(bundle)

    enc = DigitalPSTEncoder(fs_hz=fs_hz, dims=dims, breath=breath, seed=0)
    B, _ = enc.encode(x)

    topk = TopKFilter(k=8)
    router = Router(window_ns=5_000_000, filter_policy=topk)

    adc = ADCColony(fs_hz=fs_hz, win_N=128, decode_steps=60)
    adc.configure_from_bundle(bundle)
    det = DetectionColony()
    ctrl = ControlColony(anomaly_hi=0.6)
    meta = MetaColony(active_cfg_id=cfg_id)

    def on_bit(pkt): adc.ingest(pkt)
    def on_est(pkt):
        for out in det.ingest(pkt): router.publish(out)
    def on_anom(pkt):
        for out in ctrl.ingest(pkt): router.publish(out)
    def on_ctrl(pkt):
        for out in meta.ingest(pkt): router.publish(out)

    def printer(pkt):
        if pkt.kind in ("estimate_waveform_chunk","anomaly","control","cfg"):
            print(pkt.kind, pkt.payload)

    router.subscribe(Subscription(name="bits_to_adc", predicate=lambda p: p.kind=="projection_1bit", handler=on_bit))
    router.subscribe(Subscription(name="est_to_det", predicate=lambda p: p.kind=="estimate_waveform_chunk", handler=on_est))
    router.subscribe(Subscription(name="anom_to_ctrl", predicate=lambda p: p.kind=="anomaly", handler=on_anom))
    router.subscribe(Subscription(name="ctrl_to_meta", predicate=lambda p: p.kind=="control", handler=on_ctrl))
    router.subscribe(Subscription(name="print", predicate=lambda p: p.kind in ("estimate_waveform_chunk","anomaly","control","cfg"), handler=printer, max_rate_hz=50.0))

    dt_ns = int(1e9 / fs_hz)
    for n in range(N):
        phase = 1 if breath.phase(n) == 1 else -1
        time_ns = n * dt_ns
        for i, dim in enumerate(dims):
            b = int(B[n, i])
            if b != 0 or (n % 10 == 0):
                router.publish(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=int(dim.dim_id),
                                        kind="projection_1bit", phase=phase, cfg_id=cfg_id, payload=b))
        for out in adc.maybe_emit(now_n=n):
            router.publish(out)

    router.flush()
    print("cfg_id:", cfg_id, "bundle:", bundle_path.as_posix())

if __name__ == "__main__":
    main()
