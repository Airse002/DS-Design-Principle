import numpy as np
from pathlib import Path

from pst.backends.digital_backend import DigitalPSTEncoder
from pst.decoder_waveform import decode_logistic
from pst.detector import power_quality_features, anomaly_score
from pst.logger import PacketLogger
from pst.dimension_bus import BusPacket
from pst.router import Router, Subscription
from pst.router_policies import TopKFilter
from pst.scoring import InsightScoreBridge
from pst.config_loader import ensure_example_bundle, bundle_breath, bundle_projection_dims, bundle_cfg_id

def simulate_voltage(fs_hz: float, seconds: float, mains_hz: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t) + rng.normal(0.0, 1.5, size=N)
    for _ in range(5):
        idx = int(rng.integers(0, max(1, N-200)))
        if rng.random() < 0.5:
            x[idx:idx+80] -= rng.uniform(30, 80)
        else:
            x[idx:idx+40] += rng.uniform(20, 60)
    return np.clip(x, 0.0, 230.0)

def main():
    fs_hz = 10_000.0
    seconds = 0.2
    x = simulate_voltage(fs_hz, seconds, seed=2).astype(float)
    N = x.size

    bundle_path = Path("runs/cfg_bundle.json")
    bundle = ensure_example_bundle(bundle_path, fs_hz=fs_hz, lanes=8, L=16)
    cfg_id = bundle_cfg_id(bundle)
    breath = bundle_breath(bundle)
    dims = bundle_projection_dims(bundle)

    enc = DigitalPSTEncoder(fs_hz=fs_hz, dims=dims, breath=breath, seed=0)
    B, logm = enc.encode(x)

    A, s, th = logm["A"], logm["s"], logm["th"]
    xhat = decode_logistic(A, s, th, lam=1e-3, steps=150, lr=0.06)
    mse = float(np.mean((x - xhat)**2))

    feat = power_quality_features(xhat, fs_hz=fs_hz)
    base = power_quality_features(x, fs_hz=fs_hz)
    score = anomaly_score(feat, base)

    print("cfg_id:", cfg_id)
    print("Reconstruction MSE:", mse)
    print("Anomaly score:", score)

    logpath = Path("runs/pst_adc_bits.log")
    logpath.parent.mkdir(parents=True, exist_ok=True)
    logger = PacketLogger(logpath)

    dt_ns = int(1e9 / fs_hz)
    for n in range(N):
        phase = 1 if breath.phase(n) == 1 else -1
        time_ns = n * dt_ns
        for i, dim in enumerate(dims):
            b = int(B[n, i])
            if b != 0 or (n % 20 == 0):
                logger.append(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=int(dim.dim_id),
                                       kind="projection_1bit", phase=phase, cfg_id=cfg_id, payload=b))

    topk = TopKFilter(k=8)
    r = Router(window_ns=5_000_000, filter_policy=topk)
    bridge = InsightScoreBridge()

    def score_ingest(pkt):
        out = bridge.ingest(pkt)
        if out is not None:
            r.publish(out)

    r.subscribe(Subscription(name="score_ingest", predicate=lambda p: p.kind.endswith("summary"), handler=score_ingest))

    for pkt in PacketLogger(logpath).replay():
        r.publish(pkt)
    r.flush()
    print("Wrote:", logpath.as_posix(), "and bundle:", bundle_path.as_posix())

if __name__ == "__main__":
    main()
