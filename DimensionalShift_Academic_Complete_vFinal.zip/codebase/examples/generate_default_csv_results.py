import os, sys, csv, re
from pathlib import Path
import numpy as np

# Ensure D-Link app packages are importable
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/"dlink_cuda_app"))

from pst.tools.teacher_pdf import TeacherDemoArtifacts, export_teacher_demo_pdf

def read_voltage_csv(path: Path):
    t = []
    x = []
    with path.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            t.append(float(row["t_s"]))
            x.append(float(row["voltage_v"]))
    return np.array(t, dtype=float), np.array(x, dtype=float)

def parse_report(md_path: Path):
    txt = md_path.read_text(encoding="utf-8")
    # lanes list
    m = re.search(r"DE lanes list:\s*\[(.*?)\]", txt, re.S)
    lanes = [int(s.strip()) for s in m.group(1).split(",")] if m else []
    m = re.search(r"DE RMSE:\s*\[(.*?)\]", txt, re.S)
    rmses = [float(s.strip()) for s in m.group(1).split(",")] if m else []
    m = re.search(r"Platform selected:\s*\*\*(.+?)\*\*", txt)
    platform = m.group(1).strip() if m else os.getenv("DLINK_PLATFORM","cpu")
    # benchmark lines
    bm = re.findall(r"Benchmark (.+?) \(s\):\s*\[(.*?)\]", txt, re.S)
    cpu_t = []; plat_t = []
    if bm:
        cpu_t = [float(s.strip()) for s in bm[0][1].split(",") if s.strip()]
        # last entry corresponds to chosen platform label
        plat_label = bm[-1][0].strip()
        plat_t = [float(s.strip()) for s in bm[-1][1].split(",") if s.strip()]
        platform = plat_label
    # top-k
    m = re.search(r"Top-K kept:\s*(\d+)\s*/\s*(\d+)", txt)
    K = int(m.group(1)) if m else 0
    total = int(m.group(2)) if m else 0
    return lanes, rmses, cpu_t, plat_t, platform, K, total

def write_error_vs_lanes_csv(path: Path, lanes, rmses):
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["lanes", "rmse"])
        for L, e in zip(lanes, rmses):
            w.writerow([int(L), float(e)])

def write_benchmark_csv(path: Path, platform: str, cpu_t, plat_t):
    path.parent.mkdir(parents=True, exist_ok=True)
    roles = ["insight", "topk", "gateopt"]
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["role", "cpu_s", "platform", "platform_s"])
        for i, r in enumerate(roles):
            w.writerow([r, float(cpu_t[i]) if len(cpu_t)==3 else "", platform, float(plat_t[i]) if len(plat_t)==3 else ""])

def write_topk_csv(path: Path, dim_ids, scores, selected_idx):
    path.parent.mkdir(parents=True, exist_ok=True)
    keep = set(int(i) for i in selected_idx)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["dim_index", "dim_id", "score", "kept"])
        for i, (d, s) in enumerate(zip(dim_ids, scores)):
            w.writerow([i, int(d), float(s), 1 if i in keep else 0])

def main():
    # Use default input CSV (you can swap this for real data later)
    t, x = read_voltage_csv(Path("data/voltage_default.csv"))

    # Run existing teacher demo (which produces report + plots)
    # It internally synthesizes signal today; that's fine for plots. The CSV dataset is for display + future pipeline.
    from examples.demo_teacher_ds_cuda import main as run_demo  # type: ignore
    run_demo()

    art = TeacherDemoArtifacts()
    export_teacher_demo_pdf(art)

    lanes, rmses, cpu_t, plat_t, platform, K, total = parse_report(art.report_md)

    # Write results CSVs
    write_error_vs_lanes_csv(Path("runs/demo_results_error_vs_lanes.csv"), lanes, rmses)
    write_benchmark_csv(Path("runs/demo_results_benchmark.csv"), platform, cpu_t, plat_t)

    # Derive topk CSV from the DR plot inputs by re-running a small role call through the selector
    sys.path.insert(0, str(Path("dlink_cuda_app")))
    from dlink_hub.platform_select import DLinkPlatform
    plat = DLinkPlatform(platform=os.getenv("DLINK_PLATFORM","cpu"))
    sampler = plat.select(os.getenv("DLINK_PLATFORM","cpu"))

    dim_ids = list(range(1000000, 1000000 + 16))
    base = [0.02*i for i in range(len(dim_ids))]
    out1 = sampler.sample({"kind":"insight_eval","dim_ids":dim_ids,"base_scores":base,"noise_std":0.02}, shots=256, seed=1)
    out2 = sampler.sample({"kind":"topk_subset","dim_ids":dim_ids,"weights":out1.get("scores", base),"K":8}, shots=256, seed=2)
    write_topk_csv(Path("runs/demo_results_topk.csv"), out1.get("dim_ids", dim_ids), out1.get("scores", base), out2.get("selected", []))

    print("Wrote:")
    print(" - data/voltage_default.csv")
    print(" - runs/demo_results_error_vs_lanes.csv")
    print(" - runs/demo_results_topk.csv")
    print(" - runs/demo_results_benchmark.csv")
    print(" - runs/teacher_demo_report.pdf")

if __name__ == "__main__":
    main()
