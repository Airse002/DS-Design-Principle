import numpy as np
from pathlib import Path

from pst.config_loader import ensure_example_bundle, bundle_cfg_id
from pst.backends.digital_backend import StreamingPSTEncoder
from pst.dimension_bus import BusPacket
from pst.router import Router, Subscription
from pst.router_policies import TopKFilter

from pst.colonies.adc_colony import ADCColony
from pst.colonies.detect_colony import DetectionColony
from pst.colonies.control_colony import ControlColony
from pst.colonies.meta_colony import MetaColony
from pst.config_manager import ConfigManager
from pst.kinds import K_INSIGHT, K_CFG
from pst.qpu.dlink_bridge import DLinkQuantumBridge
from pst.qpu.dlink_qpu import QPUContext

def simulate_voltage_stream(fs_hz: float, seconds: float, mains_hz: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t) + rng.normal(0.0, 1.5, size=N)
    for _ in range(6):
        idx = int(rng.integers(0, max(1, N-200)))
        if rng.random() < 0.5:
            x[idx:idx+80] -= rng.uniform(30, 80)
        else:
            x[idx:idx+40] += rng.uniform(20, 60)
    return np.clip(x, 0.0, 230.0)

def main():
    fs_hz = 10_000.0
    seconds = 0.6
    x = simulate_voltage_stream(fs_hz, seconds, seed=4).astype(float)
    N = x.size

    bundle_path = Path("runs/cfg_bundle.json")
    bundle = ensure_example_bundle(bundle_path, fs_hz=fs_hz, lanes=10, L=16)

    cm = ConfigManager(fs_hz=fs_hz, bundle_path=Path("runs/active_cfg_bundle.json"), min_lanes=4, max_lanes=24, kernel_L=16)
    cm.load_or_init(bundle)

    enc = StreamingPSTEncoder(fs_hz=fs_hz, dims=cm.dims(), breath=cm.breath(), seed=0)

    topk = TopKFilter(k=8)
    router = Router(window_ns=5_000_000, filter_policy=topk)

    adc = ADCColony(fs_hz=fs_hz, win_N=128, decode_steps=60)
    adc.configure_from_bundle(cm.bundle)
    det = DetectionColony()
    ctrl = ControlColony(anomaly_hi=0.6)
    meta = MetaColony(active_cfg_id=cm.active_cfg_id())

    # Quantum bridge (sim backend)
    qbridge = DLinkQuantumBridge()

    # Wiring
    def on_bit(pkt): adc.ingest(pkt)
    def on_est(pkt):
        for out in det.ingest(pkt): router.publish(out)
    def on_anom(pkt):
        for out in ctrl.ingest(pkt): router.publish(out)
    def on_ctrl(pkt):
        # Meta suggests coarse intents; QPU refines breath + selects dims in collision.
        for out in meta.ingest(pkt):
            router.publish(out)

    def on_cfg_intent(pkt):
        applied = cm.apply_intent(pkt)
        if applied is None:
            return
        enc.set_config(cm.dims(), cm.breath())
        adc.configure_from_bundle(cm.bundle)
        router.publish(applied)

    def on_insight(pkt):
        cm.ingest_score(pkt)

    # Print
    def printer(pkt):
        if pkt.kind in ("cfg", "cfg_applied", "control", "anomaly"):
            print(pkt.kind, pkt.payload)

    router.subscribe(Subscription(name="bits_to_adc", predicate=lambda p: p.kind=="projection_1bit", handler=on_bit))
    router.subscribe(Subscription(name="est_to_det", predicate=lambda p: p.kind=="estimate_waveform_chunk", handler=on_est))
    router.subscribe(Subscription(name="anom_to_ctrl", predicate=lambda p: p.kind=="anomaly", handler=on_anom))
    router.subscribe(Subscription(name="ctrl_to_meta", predicate=lambda p: p.kind=="control", handler=on_ctrl))
    router.subscribe(Subscription(name="cfg_intents", predicate=lambda p: p.kind=="cfg", handler=on_cfg_intent))
    router.subscribe(Subscription(name="insight_scores", predicate=lambda p: p.kind=="insight", handler=on_insight))
    router.subscribe(Subscription(name="print", predicate=lambda p: p.kind in ("cfg","cfg_applied","control","anomaly"), handler=printer, max_rate_hz=100.0))

    dt_ns = int(1e9 / fs_hz)
    L = 16
    hist = np.zeros(L, dtype=float)

    # Every so often, ask QPU for insight + topk + breath optimize (simulated)
    query_period = 2000  # samples

    for n in range(N):
        hist = np.roll(hist, -1)
        hist[-1] = x[n]

        phase = 1 if enc.breath.phase(n) == 1 else -1
        time_ns = n * dt_ns

        bits = enc.encode_step(hist, n)
        for dim_id, b in bits.items():
            if b != 0 or (n % 20 == 0):
                router.publish(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=int(dim_id),
                                        kind="projection_1bit", phase=phase, cfg_id=cm.active_cfg_id(), payload=int(b)))

        # ADC colony emits estimate + insight proxy
        for out in adc.maybe_emit(now_n=n):
            router.publish(out)

        # QPU step (sim) periodically during collision
        if n % query_period == 0 and n > 0:
            dims = [int(d.dim_id) for d in cm.dims()]
            # base_scores from ConfigManager's stored insight (if any)
            base = [cm.scores.get(i, 0.0) for i in dims]
            ctx = QPUContext(time_ns=time_ns, clock_domain="host0", cfg_id=cm.active_cfg_id(), phase=phase, seed=7)

            # Role 3 -> publish insight packets (noise + exploration)
            for pkt in qbridge.run_insight(ctx, dims, base_scores=base):
                router.publish(pkt)

            # Role 1 -> choose Top-K and kill others (dim-plosion)
            selected = qbridge.run_topk(ctx, dims, weights=base)
            for pkt in qbridge.run_topk_as_cfg(ctx, selected, dims):
                router.publish(pkt)

            # Role 2 -> breath optimize based on proxy progress/pain
            # We proxy: progress=mean(base), pain=anomaly trend unknown here -> 0.1
            progress = float(np.mean(base)) if base else 0.0
            pain = 0.1
            breath_intent = qbridge.run_gateopt(ctx, Te=cm.bundle["breath"]["Te"], Tc=cm.bundle["breath"]["Tc"], progress=progress, pain=pain)
            router.publish(breath_intent)

    router.flush()
    print("Final cfg_id:", cm.active_cfg_id(), "active bundle:", cm.bundle_path.as_posix())

if __name__ == "__main__":
    main()
