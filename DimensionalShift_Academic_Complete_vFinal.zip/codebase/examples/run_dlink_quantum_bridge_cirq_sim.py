import os
os.environ["DSHIFT_QPU_BACKEND"] = "cirq"

from pst.qpu.dlink_bridge import DLinkQuantumBridge
from pst.qpu.dlink_qpu import QPUContext

def main():
    bridge = DLinkQuantumBridge()
    dim_ids = [1000000+i for i in range(12)]
    base_scores = [0.1*i for i in range(len(dim_ids))]
    ctx = QPUContext(time_ns=123456789, clock_domain="host0", cfg_id="cfg-demo", phase=-1, seed=7)

    insight = bridge.run_insight(ctx, dim_ids, base_scores=base_scores)
    weights = [float(p.payload) for p in insight]
    selected = bridge.run_topk(ctx, dim_ids, weights=weights)
    breath_intent = bridge.run_gateopt(ctx, Te=600, Tc=400, progress=0.2, pain=0.1)

    print("Backend:", os.getenv("DSHIFT_QPU_BACKEND"))
    print("INSIGHT (first 3):", [(p.dim_id, p.payload) for p in insight[:3]])
    print("TOPK selected:", selected)
    print("BREATH intent:", breath_intent.payload)

if __name__ == "__main__":
    main()
