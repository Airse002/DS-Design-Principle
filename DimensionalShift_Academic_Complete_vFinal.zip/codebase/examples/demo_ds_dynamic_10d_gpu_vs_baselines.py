import os, sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))  # project
sys.path.insert(0, str(root/"dlink_cuda_app"))  # optional, for consistent env vars

from apps.ds_dynamic_optimizer.runner import main

if __name__ == "__main__":
    # Choose platform via env:
    #   DLINK_PLATFORM=cpu|cuda
    # For Tesla CUDA:
    #   export DLINK_PLATFORM=cuda
    #   export DSHIFT_ACCEL_BACKEND=cuda
    main()
