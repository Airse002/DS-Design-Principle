import os, sys, json
from pathlib import Path

# Ensure D-Link app packages are importable
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/"dlink_cuda_app"))  # provides dlink_cuda + dlink_hub

from dlink_hub.platform_select import DLinkPlatform

def main():
    platform = os.getenv("DLINK_PLATFORM", "cpu")
    plat = DLinkPlatform(platform=platform)
    sampler = plat.select(platform)

    dim_ids = [1000000+i for i in range(8)]
    base = [0.05*i for i in range(len(dim_ids))]

    out1 = sampler.sample({"kind":"insight_eval","dim_ids":dim_ids,"base_scores":base,"noise_std":0.02}, shots=256, seed=1)
    out2 = sampler.sample({"kind":"topk_subset","dim_ids":dim_ids,"weights":out1.get("scores", base),"K":4}, shots=256, seed=2)
    out3 = sampler.sample({"kind":"gate_opt","Te":600,"Tc":400,"progress":0.2,"pain":0.1,"alpha":1.0,"candidates":256}, shots=256, seed=3)

    print("DLINK_PLATFORM:", platform)
    print("insight_eval keys:", list(out1.keys()))
    print("topk_subset:", out2)
    print("gate_opt:", out3)

if __name__ == "__main__":
    main()
