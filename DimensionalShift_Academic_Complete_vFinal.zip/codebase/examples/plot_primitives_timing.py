import csv
from pathlib import Path
import matplotlib.pyplot as plt

def main():
    path = Path("runs/primitives_timing.csv")
    if not path.exists():
        print("Missing runs/primitives_timing.csv (run apps/cuda_primitives_dlink/scripts/run_examples.sh first)")
        return
    rows = []
    with path.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)

    # group by op and mode
    ops = sorted(set(r["op"] for r in rows))
    plt.figure()
    # simple: plot ms per row, labeled
    xs = list(range(len(rows)))
    ys = [float(r["ms"]) for r in rows]
    labels = [f"{r['op']}/{r['mode']}" for r in rows]
    plt.plot(xs, ys, marker="o")
    plt.xticks(xs, labels, rotation=60, ha="right")
    plt.ylabel("ms")
    plt.title("D-Link CUDA primitives timings (EXPAND explores, COLLAPSE uses chosen cfg)")
    out = Path("runs/primitives_timing_plot.png")
    plt.savefig(out, dpi=160, bbox_inches="tight")
    plt.close()
    print("Wrote", out)

if __name__ == "__main__":
    main()
