import os, sys
import numpy as np
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/"dlink_cuda_app"))

os.environ.setdefault("DSHIFT_ACCEL_BACKEND", "cuda")

from pst.config_loader import ensure_example_bundle
from pst.backends.digital_backend import StreamingPSTEncoder
from pst.dimension_bus import BusPacket
from pst.router import Router, Subscription
from pst.router_policies import TopKFilter

from pst.colonies.adc_colony import ADCColony
from pst.config_manager import ConfigManager
from pst.qpu.dlink_qpu import QPUContext

from pst.gpu.dlink_cuda_bridge import DLinkCudaBridge

def simulate_voltage_stream(fs_hz: float, seconds: float, mains_hz: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t) + rng.normal(0.0, 1.5, size=N)
    return np.clip(x, 0.0, 230.0)

def main():
    fs_hz = 2_000.0
    seconds = 0.08
    x = simulate_voltage_stream(fs_hz, seconds, seed=7).astype(float)
    N = x.size

    bundle = ensure_example_bundle(Path("runs/cfg_bundle.json"), fs_hz=fs_hz, lanes=6, L=16)
    cm = ConfigManager(fs_hz=fs_hz, bundle_path=Path("runs/active_cfg_bundle.json"), min_lanes=4, max_lanes=24, kernel_L=16)
    cm.load_or_init(bundle)

    enc = StreamingPSTEncoder(fs_hz=fs_hz, dims=cm.dims(), breath=cm.breath(), seed=0)
    adc = ADCColony(fs_hz=fs_hz, win_N=64, decode_steps=12)
    adc.configure_from_bundle(cm.bundle)

    router = Router(window_ns=5_000_000, filter_policy=TopKFilter(k=8))
    router.subscribe(Subscription("bits_to_adc", lambda p: p.kind=="projection_1bit", lambda p: adc.ingest(p)))

    def apply_cfg(pkt):
        applied = cm.apply_intent(pkt)
        if applied is None:
            return
        enc.set_config(cm.dims(), cm.breath())
        adc.configure_from_bundle(cm.bundle)
        router.publish(applied)

    router.subscribe(Subscription("cfg_apply", lambda p: p.kind=="cfg", apply_cfg))
    router.subscribe(Subscription("print", lambda p: p.kind in ("cfg","cfg_applied"), lambda p: print(p.kind, p.payload), max_rate_hz=50.0))

    gbridge = DLinkCudaBridge(K=8)

    dt_ns = int(1e9 / fs_hz)
    L = 16
    hist = np.zeros(L, dtype=float)

    query_at = int(0.7 * N)

    for n in range(N):
        hist = np.roll(hist, -1)
        hist[-1] = x[n]
        phase = 1 if enc.breath.phase(n) == 1 else -1
        time_ns = n * dt_ns

        bits = enc.encode_step(hist, n)
        for dim_id, b in bits.items():
            if b != 0 or (n % 20 == 0):
                router.publish(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=int(dim_id),
                                         kind="projection_1bit", phase=phase, cfg_id=cm.active_cfg_id(), payload=int(b)))

        for out in adc.maybe_emit(now_n=n):
            router.publish(out)

        # one GPU decision point (demo): produce insight, then kill dims not top-k, then set breath
        if n == query_at:
            dims = [int(d.dim_id) for d in cm.dims()]
            base = [cm.scores.get(i, 0.0) for i in dims]
            ctx = QPUContext(time_ns=time_ns, clock_domain="host0", cfg_id=cm.active_cfg_id(), phase=phase, seed=7)

            insight = gbridge.insight_packets(ctx, dims, base_scores=base)
            weights = [float(p.payload) for p in insight]
            for pkt in gbridge.topk_kill_cfg(ctx, dims, weights):
                router.publish(pkt)
            router.publish(gbridge.breath_cfg(ctx, Te=cm.bundle["breath"]["Te"], Tc=cm.bundle["breath"]["Tc"],
                                             progress=float(np.mean(weights)) if weights else 0.0, pain=0.1))

    router.flush()
    print("Done. DSHIFT_ACCEL_BACKEND:", os.getenv("DSHIFT_ACCEL_BACKEND"))

if __name__ == "__main__":
    main()
