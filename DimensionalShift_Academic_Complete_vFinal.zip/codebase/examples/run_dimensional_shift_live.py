import numpy as np
from pathlib import Path

from pst.config_loader import ensure_example_bundle, bundle_cfg_id, bundle_breath, bundle_projection_dims
from pst.backends.digital_backend import StreamingPSTEncoder
from pst.dimension_bus import BusPacket
from pst.router import Router, Subscription
from pst.router_policies import TopKFilter

from pst.colonies.adc_colony import ADCColony
from pst.colonies.detect_colony import DetectionColony
from pst.colonies.control_colony import ControlColony
from pst.colonies.meta_colony import MetaColony
from pst.config_manager import ConfigManager
from pst.kinds import K_CFG, K_CFG_APPLIED, K_INSIGHT

def simulate_voltage_stream(fs_hz: float, seconds: float, mains_hz: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t) + rng.normal(0.0, 1.5, size=N)
    for _ in range(5):
        idx = int(rng.integers(0, max(1, N-200)))
        if rng.random() < 0.5:
            x[idx:idx+80] -= rng.uniform(30, 80)
        else:
            x[idx:idx+40] += rng.uniform(20, 60)
    return np.clip(x, 0.0, 230.0)

def main():
    fs_hz = 10_000.0
    seconds = 0.6  # fast live demo
    x = simulate_voltage_stream(fs_hz, seconds, seed=3).astype(float)
    N = x.size

    # Initial cfg
    bundle_path = Path("runs/cfg_bundle.json")
    bundle = ensure_example_bundle(bundle_path, fs_hz=fs_hz, lanes=8, L=16)
    cfg_id = bundle_cfg_id(bundle)

    # ConfigManager owns active config and rolls cfg_id when it changes
    cm = ConfigManager(fs_hz=fs_hz, bundle_path=Path("runs/active_cfg_bundle.json"), min_lanes=4, max_lanes=24, kernel_L=16)
    cm.load_or_init(bundle)

    breath = cm.breath()
    dims = cm.dims()

    # Streaming encoder uses active config
    enc = StreamingPSTEncoder(fs_hz=fs_hz, dims=dims, breath=breath, seed=0)

    # Router with TopK compression in collision (optional)
    topk = TopKFilter(k=8)
    router = Router(window_ns=5_000_000, filter_policy=topk)

    # Colonies
    adc = ADCColony(fs_hz=fs_hz, win_N=128, decode_steps=60)
    adc.configure_from_bundle(cm.bundle)
    det = DetectionColony()
    ctrl = ControlColony(anomaly_hi=0.6)
    meta = MetaColony(active_cfg_id=cm.active_cfg_id())

    # Wiring: bits->adc, est->det->ctrl->meta->cfg intents->config manager->apply->update encoder/adc
    def on_bit(pkt): adc.ingest(pkt)
    def on_est(pkt):
        for out in det.ingest(pkt): router.publish(out)
    def on_anom(pkt):
        for out in ctrl.ingest(pkt): router.publish(out)
    def on_ctrl(pkt):
        for out in meta.ingest(pkt): router.publish(out)

    def on_cfg_intent(pkt):
        applied = cm.apply_intent(pkt)
        if applied is None:
            return
        # Apply to live components
        enc.set_config(cm.dims(), cm.breath())
        adc.configure_from_bundle(cm.bundle)
        # announce applied
        router.publish(applied)

    def on_insight(pkt):
        cm.ingest_score(pkt)

    def printer(pkt):
        if pkt.kind in ("cfg", "cfg_applied", "control", "anomaly"):
            print(pkt.kind, pkt.payload)

    router.subscribe(Subscription(name="bits_to_adc", predicate=lambda p: p.kind=="projection_1bit", handler=on_bit))
    router.subscribe(Subscription(name="est_to_det", predicate=lambda p: p.kind=="estimate_waveform_chunk", handler=on_est))
    router.subscribe(Subscription(name="anom_to_ctrl", predicate=lambda p: p.kind=="anomaly", handler=on_anom))
    router.subscribe(Subscription(name="ctrl_to_meta", predicate=lambda p: p.kind=="control", handler=on_ctrl))
    router.subscribe(Subscription(name="cfg_intents", predicate=lambda p: p.kind=="cfg", handler=on_cfg_intent))
    router.subscribe(Subscription(name="insight_scores", predicate=lambda p: p.kind=="insight", handler=on_insight))
    router.subscribe(Subscription(name="print", predicate=lambda p: p.kind in ("cfg","cfg_applied","control","anomaly"), handler=printer, max_rate_hz=100.0))

    dt_ns = int(1e9 / fs_hz)
    # maintain a small history buffer for encoder kernels
    L = 16
    hist = np.zeros(L, dtype=float)

    for n in range(N):
        hist = np.roll(hist, -1)
        hist[-1] = x[n]

        phase = 1 if enc.breath.phase(n) == 1 else -1
        time_ns = n * dt_ns

        bits = enc.encode_step(hist, n)
        for dim_id, b in bits.items():
            # sparse emission: always send ones; also send periodic zeros to keep replayable structure
            if b != 0 or (n % 20 == 0):
                router.publish(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=int(dim_id),
                                        kind="projection_1bit", phase=phase, cfg_id=cm.active_cfg_id(), payload=int(b)))

        for out in adc.maybe_emit(now_n=n):
            router.publish(out)

    router.flush()
    print("Final active cfg_id:", cm.active_cfg_id(), "bundle:", cm.bundle_path.as_posix())

if __name__ == "__main__":
    main()
