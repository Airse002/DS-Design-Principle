import os, sys
from pathlib import Path

# Ensure app package import works when running from project root
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/"dlink_cuda_app"))

os.environ.setdefault("DSHIFT_ACCEL_BACKEND", "cuda")

from dlink_cuda.cuda_sampler import CudaRoleSampler

def main():
    s = CudaRoleSampler()
    dim_ids = [1000000+i for i in range(12)]
    base_scores = [0.05*i for i in range(len(dim_ids))]

    out1 = s.sample({"kind":"insight_eval","dim_ids":dim_ids,"base_scores":base_scores,"noise_std":0.01}, shots=256, seed=1)
    out2 = s.sample({"kind":"topk_subset","dim_ids":dim_ids,"weights":out1["scores"],"K":8}, shots=256, seed=2)
    out3 = s.sample({"kind":"gate_opt","Te":600,"Tc":400,"progress":0.2,"pain":0.1,"alpha":1.0,"candidates":256}, shots=256, seed=3)

    print("DSHIFT_ACCEL_BACKEND:", os.getenv("DSHIFT_ACCEL_BACKEND"))
    print("insight (first 3):", list(zip(out1["dim_ids"][:3], out1["scores"][:3])))
    print("topk indices:", out2["selected"])
    print("breath:", out3)

if __name__ == "__main__":
    main()
