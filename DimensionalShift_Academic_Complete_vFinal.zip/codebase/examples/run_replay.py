from pst.logger import PacketLogger
if __name__ == "__main__":
    log = PacketLogger("runs/pst_bus.log")
    n = 0
    for pkt in log.replay():
        if n < 5:
            print(pkt)
        n += 1
    print("Total packets:", n)
