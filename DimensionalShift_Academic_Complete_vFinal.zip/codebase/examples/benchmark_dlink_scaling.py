import os, sys, time, csv
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/"dlink_cuda_app"))

from dlink_hub.platform_select import DLinkPlatform

def run(platform: str, n_dims: int, seed: int = 0):
    plat = DLinkPlatform(platform=platform)
    sampler = plat.select(platform)
    dim_ids = list(range(1_000_000, 1_000_000 + n_dims))
    base = np.linspace(0.0, 1.0, n_dims).astype(float).tolist()

    t0 = time.perf_counter()
    out1 = sampler.sample({"kind":"insight_eval","dim_ids":dim_ids,"base_scores":base,"noise_std":0.05}, shots=256, seed=seed)
    t1 = time.perf_counter()
    out2 = sampler.sample({"kind":"topk_subset","dim_ids":dim_ids,"weights":out1.get("scores", base),"K":max(8, n_dims//16)}, shots=256, seed=seed+1)
    t2 = time.perf_counter()
    return (t1-t0), (t2-t1), len(out2.get("selected", []))

def main():
    Path("runs").mkdir(parents=True, exist_ok=True)

    dims_list = [10_000, 100_000, 1_000_000]
    platforms = ["cpu"]
    want_cuda = os.getenv("DLINK_PLATFORM","").strip().lower() == "cuda" or os.getenv("DSHIFT_ACCEL_BACKEND","").strip().lower() == "cuda"
    if want_cuda:
        platforms.append("cuda")

    rows = []
    for p in platforms:
        for n in dims_list:
            ins_s, topk_s, kept = run(p, n, seed=0)
            rows.append({"platform": p, "n_dims": n, "insight_s": ins_s, "topk_s": topk_s, "kept": kept})

    csv_path = Path("runs/dlink_scaling.csv")
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["platform","n_dims","insight_s","topk_s","kept"])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    for metric in ["insight_s","topk_s"]:
        plt.figure()
        for p in platforms:
            xs = [r["n_dims"] for r in rows if r["platform"]==p]
            ys = [r[metric] for r in rows if r["platform"]==p]
            plt.plot(xs, ys, marker="o", label=p)
        plt.xscale("log")
        plt.xlabel("n_dims (log)")
        plt.ylabel("seconds")
        plt.title(f"D-Link scaling: {metric} vs n_dims")
        plt.legend()
        out = Path(f"runs/dlink_scaling_{metric}.png")
        plt.savefig(out, dpi=160, bbox_inches="tight")
        plt.close()

    md = Path("runs/dlink_scaling_report.md")
    md.write_text(
        "# D-Link scaling benchmark (Dimensional Shift roles)\n\n"
        "This benchmark runs DS/D-Link role computations as dimension count increases:\n"
        "- `insight_eval` (score all dimensions)\n"
        "- `topk_subset` (Dim-plosion / DR selection)\n\n"
        "Outputs:\n"
        "- `runs/dlink_scaling.csv`\n"
        "- `runs/dlink_scaling_insight_s.png`\n"
        "- `runs/dlink_scaling_topk_s.png`\n\n"
        "Run on Tesla:\n"
        "```bash\n"
        "export DLINK_PLATFORM=cuda\n"
        "export DSHIFT_ACCEL_BACKEND=cuda\n"
        "python examples/benchmark_dlink_scaling.py\n"
        "```\n",
        encoding="utf-8"
    )
    print("Wrote runs/dlink_scaling.csv and plots.")

if __name__ == "__main__":
    main()
