import os
from pathlib import Path

# Use engine backend (skeleton) so it writes job logs
os.environ["DSHIFT_QPU_BACKEND"] = "engine"
os.environ.setdefault("DSHIFT_QPU_LOG_PATH", "runs/qpu_jobs.log")

from pst.qpu.dlink_bridge import DLinkQuantumBridge
from pst.qpu.dlink_qpu import QPUContext
from pst.qpu.job_replay import QPUJobReplayer
from pst.router import Router, Subscription
from pst.kinds import K_QPU_JOB_SUB, K_QPU_JOB_RES

def main():
    bridge = DLinkQuantumBridge()
    ctx = QPUContext(time_ns=111222333, clock_domain="host0", cfg_id="cfg-demo", phase=-1, seed=42)
    dim_ids = [1000000+i for i in range(10)]
    base_scores = [0.05*i for i in range(len(dim_ids))]

    # Run all three roles (will log jobs)
    insight = bridge.run_insight(ctx, dim_ids, base_scores=base_scores)
    weights = [float(p.payload) for p in insight]
    _sel = bridge.run_topk(ctx, dim_ids, weights=weights)
    _breath = bridge.run_gateopt(ctx, Te=600, Tc=400, progress=0.2, pain=0.1)

    project_root = Path(__file__).resolve().parents[1]
    log_path = project_root / os.environ["DSHIFT_QPU_LOG_PATH"]
    print("Wrote job log:", log_path.as_posix())

    # Replay as bus packets through Router
    r = Router(window_ns=5_000_000)
    def printer(pkt):
        print(pkt.kind, pkt.payload)

    r.subscribe(Subscription(name="print_sub", predicate=lambda p: p.kind in (K_QPU_JOB_SUB, K_QPU_JOB_RES), handler=printer, max_rate_hz=1000.0))

    rep = QPUJobReplayer(log_path=log_path)
    for pkt in rep.packets():
        r.publish(pkt)
    r.flush()

if __name__ == "__main__":
    main()
