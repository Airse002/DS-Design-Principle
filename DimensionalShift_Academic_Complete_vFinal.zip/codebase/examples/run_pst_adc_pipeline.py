import numpy as np
from pst.backends.digital_backend import DigitalPSTEncoder, Dimension, Breath
from pst.decoder_waveform import decode_logistic
from pst.detector import power_quality_features, anomaly_score
from pst.logger import PacketLogger
from pst.dimension_bus import BusPacket
from pst.router import Router, Subscription
from pst.router_policies import TopKFilter
import uuid, time
from pathlib import Path

def simulate_voltage(fs_hz: float, seconds: float, mains_hz: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t) + rng.normal(0.0, 1.5, size=N)
    # add events
    for _ in range(8):
        idx = int(rng.integers(0, max(1, N-200)))
        if rng.random() < 0.5:
            x[idx:idx+80] -= rng.uniform(30, 80)
        else:
            x[idx:idx+40] += rng.uniform(20, 60)
    return np.clip(x, 0.0, 230.0)

def rand_kernel(L: int, seed: int):
    rng = np.random.default_rng(seed)
    k = rng.normal(size=L)
    k = k / (np.linalg.norm(k) + 1e-9)
    return k

def main():
    fs_hz = 10_000.0
    seconds = 1.5
    x = simulate_voltage(fs_hz, seconds, seed=2)
    N = x.size

    # Build dimension lanes (projection kernels)
    L = 32
    dims = []
    for i in range(24):  # start with 24 lanes; can scale to hundreds
        dims.append(Dimension(
            dim_id=1_000_000 + i,
            kind="projection_1bit",
            k_plus=rand_kernel(L, seed=100+i),
            k_minus=rand_kernel(L, seed=200+i),
            P=25+(i%5),
            d=0.20+0.02*(i%3),
            delta=i,
            theta=0.0,
            dither_std=0.02
        ))
    breath = Breath(Te=600, Tc=400)  # in samples; ~60/40 breathing at 10kHz
    enc = DigitalPSTEncoder(fs_hz=fs_hz, dims=dims, breath=breath, seed=0)

    # Encode to 1-bit streams + get linearized log matrices for decode
    B, logm = enc.encode(x.astype(float))
    A, s, th = logm["A"], logm["s"], logm["th"]

    # Decode waveform from 1-bit projections
    xhat = decode_logistic(A, s, th, lam=1e-3, steps=1200, lr=0.06)
    mse = float(np.mean((x - xhat)**2))

    # Detection on reconstructed waveform
    feat = power_quality_features(xhat, fs_hz=fs_hz)
    base = power_quality_features(x, fs_hz=fs_hz)
    score = anomaly_score(feat, base)

    print("Reconstruction MSE:", mse)
    print("Detection features (xhat):", feat)
    print("Anomaly score vs baseline:", score)

    # Write a bus log with bit packets (demonstrates transportability)
    cfg_id = str(uuid.uuid4())
    logpath = Path("runs/pst_adc_bits.log")
    logpath.parent.mkdir(parents=True, exist_ok=True)
    logger = PacketLogger(logpath)

    dt_ns = int(1e9 / fs_hz)
    for n in range(N):
        phase = 1 if breath.phase(n) == 1 else -1
        time_ns = n * dt_ns
        # emit a few lane bits per time (sparse in real HW due to gating)
        for i, dim in enumerate(dims):
            b = int(B[n, i])
            if b != 0 or (n % 50 == 0):  # keep log small; still replayable
                logger.append(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=dim.dim_id,
                                       kind="projection_1bit", phase=phase, cfg_id=cfg_id, payload=b))

    # Router demo with TopK filter: pretend we score dims by activity
    topk = TopKFilter(k=8)
    r = Router(window_ns=5_000_000, filter_policy=topk)

    def score_update(pkt):
        # update scores: simple heuristic => lanes with more ones get higher score
        # (in a real system, scores come from organism "insight")
        if pkt.kind.endswith("summary") and isinstance(pkt.payload, dict):
            topk.update_score(pkt.dim_id, float(pkt.payload.get("ones", 0)))

    def printer(pkt):
        print("ROUTED:", pkt.kind, pkt.dim_id, pkt.phase, pkt.payload)

    r.subscribe(Subscription(name="score", predicate=lambda p: p.kind.endswith("summary"), handler=score_update))
    r.subscribe(Subscription(name="print", predicate=lambda p: p.kind.endswith("summary"), handler=printer, max_rate_hz=200.0))

    # Replay and route (collision summarization will output summaries)
    for pkt in PacketLogger(logpath).replay():
        r.publish(pkt)
    r.flush()

    print("Wrote bus log:", logpath.as_posix(), "cfg_id:", cfg_id)

if __name__ == "__main__":
    main()
