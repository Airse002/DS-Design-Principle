import os, sys, time
from pathlib import Path
import numpy as np
import matplotlib.pyplot as plt

# Ensure D-Link app packages are importable
root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/"dlink_cuda_app"))  # provides dlink_cuda + dlink_hub

from pst.config_loader import ensure_example_bundle
from pst.backends.digital_backend import StreamingPSTEncoder
from pst.colonies.adc_colony import ADCColony
from pst.config_manager import ConfigManager
from pst.qpu.dlink_qpu import QPUContext
from pst.dimension_bus import BusPacket

from dlink_hub.platform_select import DLinkPlatform

def simulate_voltage(fs_hz: float, seconds: float, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*60.0*t) + rng.normal(0.0, 2.0, size=N)
    # a few disturbances
    for _ in range(4):
        idx = int(rng.integers(0, max(1, N-200)))
        x[idx:idx+80] -= rng.uniform(20, 70)
    return np.clip(x, 0.0, 230.0)

def reconstruct_error_for_lanes(fs_hz: float, x: np.ndarray, lanes: int, L: int = 16):
    # Build config bundle with requested lanes
    bundle = ensure_example_bundle(Path("runs/cfg_bundle.json"), fs_hz=fs_hz, lanes=lanes, L=L)
    cm = ConfigManager(fs_hz=fs_hz, bundle_path=Path("runs/active_cfg_bundle.json"), min_lanes=4, max_lanes=64, kernel_L=L)
    cm.load_or_init(bundle)
    enc = StreamingPSTEncoder(fs_hz=fs_hz, dims=cm.dims(), breath=cm.breath(), seed=0)

    adc = ADCColony(fs_hz=fs_hz, win_N=64, decode_steps=12)
    adc.configure_from_bundle(cm.bundle)

    dt_ns = int(1e9 / fs_hz)
    hist = np.zeros(L, dtype=float)
    est = []
    truth = []

    for n in range(len(x)):
        hist = np.roll(hist, -1)
        hist[-1] = x[n]
        phase = 1 if enc.breath.phase(n) == 1 else -1
        time_ns = n * dt_ns

        bits = enc.encode_step(hist, n)
        for dim_id, b in bits.items():
            # sparse emission
            if b != 0 or (n % 20 == 0):
                adc.ingest(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=int(dim_id),
                                     kind="projection_1bit", phase=phase, cfg_id=cm.active_cfg_id(), payload=int(b)))

        for out in adc.maybe_emit(now_n=n):
            if out.kind == "estimate_waveform_chunk":
                # out.payload is a list/array chunk
                payload = out.payload if isinstance(out.payload, dict) else {"xhat": out.payload, "n0": None}
                xhat_list = payload.get("xhat", [])
                n0 = int(payload.get("n0", max(0, n - len(xhat_list) + 1)))
                chunk = np.array(xhat_list, dtype=float)
                est.append(chunk)
                # align truth using n0 from payload
                truth.append(x[n0:n0+len(chunk)])

    if not est:
        return float("inf"), cm, enc, adc

    est_cat = np.concatenate(est)
    tru_cat = np.concatenate(truth)
    m = min(est_cat.size, tru_cat.size)
    est_cat = est_cat[:m]
    tru_cat = tru_cat[:m]
    rmse = float(np.sqrt(np.mean((est_cat - tru_cat)**2)))
    return rmse, cm, enc, adc

def benchmark_roles(platform: str, dim_ids, base_scores):
    plat = DLinkPlatform(platform=platform)
    sampler = plat.select(platform)

    # Warmup
    sampler.sample({"kind":"insight_eval","dim_ids":dim_ids,"base_scores":base_scores,"noise_std":0.01}, shots=256, seed=1)

    t0 = time.perf_counter()
    out1 = sampler.sample({"kind":"insight_eval","dim_ids":dim_ids,"base_scores":base_scores,"noise_std":0.01}, shots=512, seed=2)
    t1 = time.perf_counter()
    out2 = sampler.sample({"kind":"topk_subset","dim_ids":dim_ids,"weights":out1.get("scores", base_scores),"K":max(2, len(dim_ids)//2)}, shots=512, seed=3)
    t2 = time.perf_counter()
    out3 = sampler.sample({"kind":"gate_opt","Te":600,"Tc":400,"progress":0.2,"pain":0.1,"alpha":1.0,"candidates":1024}, shots=512, seed=4)
    t3 = time.perf_counter()

    return {
        "platform": platform,
        "insight_s": t1 - t0,
        "topk_s": t2 - t1,
        "gateopt_s": t3 - t2,
        "outs": (out1, out2, out3),
    }

def main():
    Path("runs").mkdir(parents=True, exist_ok=True)
    fs_hz = 2000.0
    x = simulate_voltage(fs_hz, seconds=0.35, seed=0)

    # --- DE: error vs lanes ---
    lanes_list = [4, 6, 8, 10, 12, 16, 20]
    rmses = []
    for lanes in lanes_list:
        rmse, *_ = reconstruct_error_for_lanes(fs_hz, x, lanes=lanes, L=16)
        rmses.append(rmse)

    plt.figure()
    plt.plot(lanes_list, rmses, marker="o")
    plt.xlabel("Number of lanes (dimensions)  —  DE (expansion)")
    plt.ylabel("Reconstruction RMSE")
    plt.title("Dimensional Expansion: more lanes → lower error (typically)")
    p1 = Path("runs/teacher_demo_error_vs_lanes.png")
    plt.savefig(p1, dpi=160, bbox_inches="tight")
    plt.close()

    # --- DR: Top-K selection demonstration using role math on chosen platform ---
    # Choose platform from env: DLINK_PLATFORM=cpu|cuda|qpu-sim|...
    platform = os.getenv("DLINK_PLATFORM", "cpu").strip().lower()
    dim_ids = list(range(1000000, 1000000 + 16))
    base_scores = [0.02*i for i in range(len(dim_ids))]

    # benchmark CPU and chosen platform (if different)
    bench_cpu = benchmark_roles("cpu", dim_ids, base_scores)
    bench_plat = bench_cpu if platform == "cpu" else benchmark_roles(platform, dim_ids, base_scores)

    # Use selected platform to choose Top-K indices; then compare "kept dims" count
    out1, out2, out3 = bench_plat["outs"]
    selected = out2.get("selected", [])
    K = len(selected) if isinstance(selected, list) else 0

    # Visualize DR decision
    w = np.array(out1.get("scores", base_scores), dtype=float)
    keep_mask = np.zeros_like(w, dtype=float)
    for i in selected:
        if 0 <= int(i) < keep_mask.size:
            keep_mask[int(i)] = 1.0

    plt.figure()
    plt.plot(w, marker="o")
    plt.plot(keep_mask * w, marker="s")
    plt.xlabel("Dimension index")
    plt.ylabel("Insight score (proxy)")
    plt.title(f"Dimensional Reduction (DR): Top-K keep={K} on platform={platform}")
    p2 = Path("runs/teacher_demo_dr_topk.png")
    plt.savefig(p2, dpi=160, bbox_inches="tight")
    plt.close()

    # --- Benchmark plot ---
    labels = ["insight", "topk", "gateopt"]
    cpu_t = [bench_cpu["insight_s"], bench_cpu["topk_s"], bench_cpu["gateopt_s"]]
    plat_t = [bench_plat["insight_s"], bench_plat["topk_s"], bench_plat["gateopt_s"]]

    xidx = np.arange(len(labels))
    width = 0.35
    plt.figure()
    plt.bar(xidx - width/2, cpu_t, width, label="cpu")
    plt.bar(xidx + width/2, plat_t, width, label=platform)
    plt.xticks(xidx, labels)
    plt.ylabel("Seconds (lower is better)")
    plt.title("Role computation time: CPU vs selected platform")
    plt.legend()
    p3 = Path("runs/teacher_demo_benchmark.png")
    plt.savefig(p3, dpi=160, bbox_inches="tight")
    plt.close()

    # --- Short report ---
    report = Path("runs/teacher_demo_report.md")
    report.write_text(f"""# Dimensional Shift (DS) — Teacher Demo

Platform selected: **{platform}**

## What DS shows
- **DE (Dimensional Expansion):** add lanes (dimensions) → more projections → typically lower reconstruction error.
- **DR (Dimensional Reduction / Dim-plosion):** select Top-K lanes based on insight → drop the rest (policy-driven compression).
- **Heartbeat / breath:** Te/Tc controls expand vs collision phases (not shown in plots, but part of DS loop).

## Outputs
- {p1.as_posix()}  (DE: error vs lanes)
- {p2.as_posix()}  (DR: Top-K selection)
- {p3.as_posix()}  (Compute benchmark)

## Numbers
DE lanes list: {lanes_list}
DE RMSE: {rmses}

Benchmark CPU (s): {cpu_t}
Benchmark {platform} (s): {plat_t}

Top-K kept: {K} / {len(dim_ids)}

""", encoding="utf-8")

    print("Wrote:")
    print(" -", p1.as_posix())
    print(" -", p2.as_posix())
    print(" -", p3.as_posix())
    print(" -", report.as_posix())

if __name__ == "__main__":
    main()
