from pst.logger import PacketLogger
from pst.router import Router, Subscription

def want_features(pkt):
    return pkt.kind.endswith("summary") or pkt.kind in ("feature", "feature_voltage_sense")

def printer(pkt):
    print(pkt.kind, pkt.dim_id, pkt.phase, pkt.payload)

if __name__ == "__main__":
    r = Router(window_ns=5_000_000)  # 5ms collision summaries
    r.subscribe(Subscription(name="print_features", predicate=want_features, handler=printer, max_rate_hz=500.0))
    log = PacketLogger("runs/pst_bus.log")
    for pkt in log.replay():
        r.publish(pkt)
    r.flush()
