from pst.sim_harness import run_end_to_end
if __name__ == "__main__":
    print("Log:", run_end_to_end(out_log="runs/pst_bus.log", seconds=4.0, fs_hz=10_000.0))
