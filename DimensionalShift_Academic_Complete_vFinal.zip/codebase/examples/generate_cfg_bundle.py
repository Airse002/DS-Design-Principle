from pst.config import Gate, DimDef, make_bundle, dump_bundle, random_kernel

if __name__ == "__main__":
    L = 32
    dims = []
    for i in range(12):
        dims.append(DimDef(
            dim_id=1_000_000 + i,
            kind="projection_1bit",
            rate_hz=10_000.0,
            kernel_plus=random_kernel(L, seed=100+i),
            kernel_minus=random_kernel(L, seed=200+i),
            gate=Gate(P=25+(i%5), d=0.20+0.02*(i%3), delta=i),
            threshold=0.0,
            calibration={"unit":"arb","notes":"example lane"}
        ))
    bundle = make_bundle(Te=60, Tc=40, dims=dims)
    dump_bundle(bundle, "runs/cfg_bundle.json")
    print("Wrote runs/cfg_bundle.json cfg_id=", bundle["cfg_id"])
