import os, sys
from pathlib import Path

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root/"dlink_cuda_app"))

def talk_track(platform: str) -> str:
    return f"""PRESENTATION TALK-TRACK (Dimensional Shift / DE / DR)

Platform today: {platform}

1) Define:
   - Dimensional Shift (DS) is a heartbeat-like compute architecture:
     expand representation (DE), then compress/choose (DR), repeating in time.

2) DE plot:
   - Each lane is a projection dimension. More lanes => richer representation.
   - Typically, reconstruction error decreases as lanes increase.

3) DR plot:
   - In collision/implosion phase, we keep the best K lanes and drop the rest (Dim-plosion).
   - This is policy-driven dimensional reduction (not random).

4) Benchmark:
   - Role computations are parallel-friendly (GPU/Tesla speeds them up).
   - The interface stays compatible with future QPU backends already wired.

Close:
- DS = sensing + projections + decoding + instinct policy + self-updating dimensions.
"""

def main():
    platform = os.getenv("DLINK_PLATFORM", "cpu").strip().lower()

    from examples.demo_teacher_ds_cuda import main as run_demo  # type: ignore
    run_demo()

    from pst.tools.teacher_pdf import TeacherDemoArtifacts, export_teacher_demo_pdf
    art = TeacherDemoArtifacts()
    pdf = export_teacher_demo_pdf(art)

    print(talk_track(platform))
    print("Generated artifacts in runs/:")
    for p in [art.error_vs_lanes_png, art.dr_topk_png, art.benchmark_png, art.report_md, pdf]:
        print(" -", str(p))

if __name__ == "__main__":
    main()
