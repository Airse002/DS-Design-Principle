import os
import numpy as np
from pathlib import Path

# Choose backend: sim|cirq|engine (engine is safe skeleton)
os.environ.setdefault("DSHIFT_QPU_BACKEND", "sim")
os.environ.setdefault("DSHIFT_QPU_LOG_PATH", "runs/qpu_jobs.log")

from pst.config_loader import ensure_example_bundle
from pst.backends.digital_backend import StreamingPSTEncoder
from pst.dimension_bus import BusPacket
from pst.router import Router, Subscription
from pst.router_policies import TopKFilter

from pst.colonies.adc_colony import ADCColony
from pst.colonies.detect_colony import DetectionColony
from pst.colonies.control_colony import ControlColony
from pst.colonies.meta_colony import MetaColony
from pst.colonies.qpu_policy_colony import QPUPolicyColony
from pst.config_manager import ConfigManager

from pst.qpu.dlink_bridge import DLinkQuantumBridge
from pst.qpu.dlink_qpu import QPUContext
from pst.qpu.logging_sampler import LoggingSampler  # for bus emission

def simulate_voltage_stream(fs_hz: float, seconds: float, mains_hz: float = 60.0, seed: int = 0):
    rng = np.random.default_rng(seed)
    N = int(fs_hz * seconds)
    t = np.arange(N) / fs_hz
    x = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t) + rng.normal(0.0, 1.5, size=N)
    for _ in range(6):
        idx = int(rng.integers(0, max(1, N-200)))
        if rng.random() < 0.5:
            x[idx:idx+80] -= rng.uniform(30, 80)
        else:
            x[idx:idx+40] += rng.uniform(20, 60)
    return np.clip(x, 0.0, 230.0)

def main():
    fs_hz = 10_000.0
    seconds = 0.25
    x = simulate_voltage_stream(fs_hz, seconds, seed=5).astype(float)
    N = x.size

    # Initial config
    bundle = ensure_example_bundle(Path("runs/cfg_bundle.json"), fs_hz=fs_hz, lanes=10, L=16)
    cm = ConfigManager(fs_hz=fs_hz, bundle_path=Path("runs/active_cfg_bundle.json"), min_lanes=4, max_lanes=24, kernel_L=16)
    cm.load_or_init(bundle)

    enc = StreamingPSTEncoder(fs_hz=fs_hz, dims=cm.dims(), breath=cm.breath(), seed=0)

    router = Router(window_ns=5_000_000, filter_policy=TopKFilter(k=8))

    # Colonies
    adc = ADCColony(fs_hz=fs_hz, win_N=128, decode_steps=60)
    adc.configure_from_bundle(cm.bundle)
    det = DetectionColony()
    ctrl = ControlColony(anomaly_hi=0.6)
    meta = MetaColony(active_cfg_id=cm.active_cfg_id())
    qpolicy = QPUPolicyColony(min_lanes=cm.min_lanes)

    # QPU bridge; ensure backend sampler emits job packets onto the bus by wrapping with emit_fn
    qbridge = DLinkQuantumBridge()
    # qbridge.sampler is LoggingSampler via backend_select; attach emitter
    if isinstance(qbridge.sampler, LoggingSampler):
        qbridge.sampler.emit_fn = router.publish

    # Wiring: classical loop
    router.subscribe(Subscription("bits_to_adc", lambda p: p.kind=="projection_1bit", lambda p: adc.ingest(p)))
    router.subscribe(Subscription("est_to_det", lambda p: p.kind=="estimate_waveform_chunk", lambda p: [router.publish(o) for o in det.ingest(p)]))
    router.subscribe(Subscription("anom_to_ctrl", lambda p: p.kind=="anomaly", lambda p: [router.publish(o) for o in ctrl.ingest(p)]))
    router.subscribe(Subscription("ctrl_to_meta", lambda p: p.kind=="control", lambda p: [router.publish(o) for o in meta.ingest(p)]))
    router.subscribe(Subscription("cfg_apply", lambda p: p.kind=="cfg", lambda p: _apply_cfg(router, cm, enc, adc, p)))
    router.subscribe(Subscription("insight_cache", lambda p: p.kind=="insight", lambda p: cm.ingest_score(p)))

    # QPU job result -> policy actions (cfg/insight with trace)
    router.subscribe(Subscription("qpu_policy", lambda p: p.kind=="qpu_job_result", lambda p: [router.publish(o) for o in qpolicy.ingest(p)]))

    # Print key packets, including qpu job packets
    router.subscribe(Subscription("print", lambda p: p.kind in ("qpu_job_submitted","qpu_job_result","cfg_applied","cfg"),
                                  lambda p: print(p.kind, p.payload), max_rate_hz=200.0))

    dt_ns = int(1e9 / fs_hz)
    L = 16
    hist = np.zeros(L, dtype=float)
    query_period = 3000

    for n in range(N):
        hist = np.roll(hist, -1)
        hist[-1] = x[n]
        phase = 1 if enc.breath.phase(n) == 1 else -1
        time_ns = n * dt_ns

        bits = enc.encode_step(hist, n)
        for dim_id, b in bits.items():
            if b != 0 or (n % 20 == 0):
                router.publish(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=int(dim_id),
                                         kind="projection_1bit", phase=phase, cfg_id=cm.active_cfg_id(), payload=int(b)))

        for out in adc.maybe_emit(now_n=n):
            router.publish(out)

        # Periodic QPU calls (all three roles)
        if n % query_period == 0 and n > 0:
            dims = [int(d.dim_id) for d in cm.dims()]
            base = [cm.scores.get(i, 0.0) for i in dims]
            ctx = QPUContext(time_ns=time_ns, clock_domain="host0", cfg_id=cm.active_cfg_id(), phase=phase, seed=7)

            # Role 3: insight eval (emits qpu job packets + returns insight packets)
            insight_pkts = qbridge.run_insight(ctx, dims, base_scores=base)
            for pkt in insight_pkts:
                router.publish(pkt)

            # Role 1: topk subset (job packets emitted); selection result itself is just list,
            # but job result packet is emitted; policy colony will act on it.
            _sel = qbridge.run_topk(ctx, dims, weights=base)

            # Role 2: gateopt (job packets emitted); policy colony will translate result into SET_BREATH cfg.
            _breath = qbridge.run_gateopt(ctx, Te=cm.bundle["breath"]["Te"], Tc=cm.bundle["breath"]["Tc"],
                                          progress=float(np.mean(base)) if base else 0.0, pain=0.1)

    router.flush()
    print("Final cfg_id:", cm.active_cfg_id())

def _apply_cfg(router: Router, cm: ConfigManager, enc: StreamingPSTEncoder, adc: ADCColony, pkt: BusPacket):
    applied = cm.apply_intent(pkt)
    if applied is None:
        return
    enc.set_config(cm.dims(), cm.breath())
    adc.configure_from_bundle(cm.bundle)
    router.publish(applied)

if __name__ == "__main__":
    main()
