# D-Link CUDA App (Dimensional Shift on GPU)

This folder adds a GPU-accelerated co-processor path for Dimensional Shift ("D-Link CUDA").
It is **optional** and runs in CPU-fallback mode if CUDA libraries are not installed.

## What it accelerates (v1 prototype)
Implements the same three "role" computations on GPU when available:
1) Insight evaluator (vector ops)
2) Top-K selector (argpartition / sampling)
3) Gate/Breath optimizer (parallel candidate scoring)

## Dependencies (optional)
Pick one path:
- **CuPy** (recommended): GPU ndarray drop-in for NumPy
  - `pip install cupy-cuda12x` (choose matching CUDA version)
- **Numba CUDA** (optional): `pip install numba` and CUDA toolkit installed
- If neither is installed, it uses NumPy on CPU.

## Run demos
From project root:
```bash
python examples/run_dlink_cuda_app.py
python examples/run_dimensional_shift_live_gpu.py
```

## Backend toggle
- `export DSHIFT_ACCEL_BACKEND=cpu` (default)
- `export DSHIFT_ACCEL_BACKEND=cuda` (uses CuPy if available, else falls back)
