"""D-Link Hub: platform selector for CPU/CUDA/QPU role execution."""
