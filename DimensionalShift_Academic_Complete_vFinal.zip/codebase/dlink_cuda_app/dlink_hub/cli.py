from __future__ import annotations
import argparse, json, os, sys
from pathlib import Path

from .platform_select import DLinkPlatform

def _parse_problem(s: str):
    # Accept JSON string or @file.json
    s = s.strip()
    if s.startswith("@"):
        p = Path(s[1:])
        return json.loads(p.read_text(encoding="utf-8"))
    return json.loads(s)

def main(argv=None):
    ap = argparse.ArgumentParser(prog="dlinkctl", description="D-Link platform selector (CPU/CUDA/QPU) for Dimensional Shift roles.")
    ap.add_argument("--platform", default=os.getenv("DLINK_PLATFORM", "cpu"),
                    help="cpu|cuda|qpu-sim|qpu-cirq|qpu-engine (env: DLINK_PLATFORM)")
    ap.add_argument("--kind", required=True, choices=["insight_eval","topk_subset","gate_opt"],
                    help="Role problem kind")
    ap.add_argument("--shots", type=int, default=256)
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--problem", required=False, default=None,
                    help="JSON string or @file.json. If omitted, minimal defaults are used per kind.")
    args = ap.parse_args(argv)

    plat = DLinkPlatform(platform=args.platform)
    sampler = plat.select(args.platform)

    if args.problem:
        problem = _parse_problem(args.problem)
    else:
        # minimal defaults
        if args.kind == "insight_eval":
            problem = {"kind":"insight_eval","dim_ids":[1,2,3,4], "base_scores":[0.1,0.2,0.3,0.4], "noise_std":0.05}
        elif args.kind == "topk_subset":
            problem = {"kind":"topk_subset","dim_ids":[1,2,3,4], "weights":[0.1,0.8,0.2,0.6], "K":2}
        else:
            problem = {"kind":"gate_opt","Te":600,"Tc":400,"progress":0.2,"pain":0.1,"alpha":1.0,"candidates":256}

    out = sampler.sample(problem, shots=args.shots, seed=args.seed)
    print(json.dumps(out, indent=2))

if __name__ == "__main__":
    main()
