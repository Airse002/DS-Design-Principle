from __future__ import annotations
import os
from dataclasses import dataclass
from typing import Dict, Any, Optional, Protocol

# CPU/CUDA role sampler (from dlink_cuda_app)
from dlink_cuda.cuda_sampler import CudaRoleSampler

class Sampler(Protocol):
    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]: ...

@dataclass
class DLinkPlatform:
    """Unified platform selector for D-Link role execution.

    Platforms:
    - cpu: NumPy (force CPU)
    - cuda: CuPy if available (else CPU fallback)
    - qpu-sim: pst QPU simulator (stochastic sampler)
    - qpu-cirq: pst Cirq simulator backend (optional)
    - qpu-engine: pst Google Engine skeleton (simulator-first; ready for future QPU access)

    Selection precedence:
    - explicit `platform` arg
    - env DLINK_PLATFORM
    """
    platform: str = "cpu"

    def _norm(self, s: str) -> str:
        return (s or "").strip().lower().replace("_", "-")

    def select(self, platform: Optional[str] = None) -> Sampler:
        p = self._norm(platform or os.getenv("DLINK_PLATFORM", self.platform))
        if p in ("cpu", "cuda"):
            # set env so the cuda sampler chooses backend
            os.environ["DSHIFT_ACCEL_BACKEND"] = "cuda" if p == "cuda" else "cpu"
            return CudaRoleSampler()

        # QPU backends live in pst/qpu and expect problem descriptors; they are wrapped with LoggingSampler in pst.
        # We keep this hub runnable even if pst is not on PYTHONPATH; in that case fall back to CPU sampler.
        try:
            if p == "qpu-sim":
                os.environ["DSHIFT_QPU_BACKEND"] = "sim"
            elif p == "qpu-cirq":
                os.environ["DSHIFT_QPU_BACKEND"] = "cirq"
            elif p == "qpu-engine":
                os.environ["DSHIFT_QPU_BACKEND"] = "engine"
            else:
                # unknown -> cpu
                os.environ["DSHIFT_ACCEL_BACKEND"] = "cpu"
                return CudaRoleSampler()

            from pst.qpu.backend_select import select_sampler  # type: ignore
            return select_sampler()
        except Exception:
            os.environ["DSHIFT_ACCEL_BACKEND"] = "cpu"
            return CudaRoleSampler()
