from __future__ import annotations
import os

def xp_backend():
    """Return an array module-like backend: cupy or numpy.
    Env: DSHIFT_ACCEL_BACKEND=cpu|cuda
    """
    mode = os.getenv("DSHIFT_ACCEL_BACKEND", "cpu").strip().lower()
    if mode == "cuda":
        try:
            import cupy as cp  # type: ignore
            # sanity: ensure CUDA device exists
            _ = cp.cuda.runtime.getDeviceCount()
            return cp
        except Exception:
            import numpy as np
            return np
    import numpy as np
    return np
