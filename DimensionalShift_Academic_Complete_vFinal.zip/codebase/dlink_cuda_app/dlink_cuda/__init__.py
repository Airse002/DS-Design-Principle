"""D-Link CUDA/GPU acceleration package for Dimensional Shift.

This package is designed to be optional: it can run on CPU with NumPy fallback.
"""
from .backend_select import xp_backend
from .cuda_sampler import CudaRoleSampler
