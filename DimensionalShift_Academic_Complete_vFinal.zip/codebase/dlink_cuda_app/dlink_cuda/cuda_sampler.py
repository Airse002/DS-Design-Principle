from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional, List
import os
import numpy as _np

from .backend_select import xp_backend

@dataclass
class CudaRoleSampler:
    """GPU-accelerated role computations for Dimensional Shift (CUDA when available).

    This is NOT a QPU sampler. It is a GPU co-processor that accelerates the same *role math*
    used by the Dimensional Shift control loop.

    API matches the D-Link role problem descriptors used by pst/qpu/* for convenience:
    - kind: topk_subset | gate_opt | insight_eval
    """
    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]:
        xp = xp_backend()
        kind = problem.get("kind", "unknown")

        # consistent RNG: CPU rng drives any random decisions; for CuPy we pass seeds where possible
        rng = _np.random.default_rng(seed)

        if kind == "insight_eval":
            dim_ids = list(problem.get("dim_ids", []))
            base_scores = _np.array(problem.get("base_scores", [0.0]*len(dim_ids)), dtype=float)
            noise_std = float(problem.get("noise_std", 0.05))
            # GPU: vector add; noise created on CPU for determinism, then transferred if needed
            noise = rng.normal(0.0, noise_std, size=len(dim_ids)).astype(float)
            if xp.__name__ == "cupy":
                import cupy as cp  # type: ignore
                s = cp.asarray(base_scores) + cp.asarray(noise)
                scores = cp.asnumpy(s).tolist()
            else:
                scores = (base_scores + noise).tolist()
            return {"dim_ids": dim_ids, "scores": scores, "kind": "insight_eval"}

        if kind == "topk_subset":
            dim_ids = list(problem.get("dim_ids", []))
            weights = _np.array(problem.get("weights", [1.0]*len(dim_ids)), dtype=float)
            K = int(problem.get("K", 8))
            if len(dim_ids) == 0:
                return {"selected": [], "kind": "topk_subset"}
            K = max(1, min(K, len(dim_ids)))

            if xp.__name__ == "cupy":
                import cupy as cp  # type: ignore
                w = cp.asarray(weights)
                # top-k via argpartition
                idx = cp.argpartition(w, -K)[-K:]
                idx = idx[cp.argsort(w[idx])][::-1]
                selected = cp.asnumpy(idx).astype(int).tolist()
            else:
                idx = _np.argpartition(weights, -K)[-K:]
                idx = idx[_np.argsort(weights[idx])][::-1]
                selected = idx.astype(int).tolist()
            # NOTE: selection is indices into dim_ids (consistent with QPU sim backend)
            return {"selected": selected, "kind": "topk_subset"}

        if kind == "gate_opt":
            # Parallel candidate scoring on GPU (vectorized)
            Te0 = int(problem.get("Te", 600))
            Tc0 = int(problem.get("Tc", 400))
            Te_min, Te_max = int(problem.get("Te_min", 50)), int(problem.get("Te_max", 1200))
            Tc_min, Tc_max = int(problem.get("Tc_min", 50)), int(problem.get("Tc_max", 1200))
            progress = float(problem.get("progress", 0.0))
            pain = float(problem.get("pain", 0.0))
            alpha = float(problem.get("alpha", 1.0))
            C = int(problem.get("candidates", max(64, shots)))

            dTe = rng.integers(-120, 121, size=C).astype(int)
            dTc = rng.integers(-120, 121, size=C).astype(int)
            Te = _np.clip(Te0 + dTe, Te_min, Te_max).astype(float)
            Tc = _np.clip(Tc0 + dTc, Tc_min, Tc_max).astype(float)

            if xp.__name__ == "cupy":
                import cupy as cp  # type: ignore
                Te_g = cp.asarray(Te)
                Tc_g = cp.asarray(Tc)
                ratio = Te_g / (Te_g + Tc_g + 1e-12)
                J = progress * ratio - alpha * pain * (1.0 - ratio) - 0.02 * cp.abs(ratio - 0.6)
                j = cp.asnumpy(J)
            else:
                ratio = Te / (Te + Tc + 1e-12)
                j = progress * ratio - alpha * pain * (1.0 - ratio) - 0.02 * _np.abs(ratio - 0.6)

            best = int(_np.argmax(j)) if j.size else 0
            return {"Te": int(Te[best]), "Tc": int(Tc[best]), "objective": float(j[best]) if j.size else 0.0, "kind": "gate_opt"}

        return {"error": "unknown kind", "kind": kind}
