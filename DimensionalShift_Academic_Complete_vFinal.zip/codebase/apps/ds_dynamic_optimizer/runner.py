from __future__ import annotations
import os, csv, math, time
from dataclasses import dataclass
from pathlib import Path
from typing import List, Dict, Any, Tuple
import numpy as np
import matplotlib.pyplot as plt

from .ds_lite import DSLiteParams, evaluate_ds_lite, objective
from .baselines import run_baseline_fixed, run_baseline_random_topk, run_baseline_fullsort_topk

def read_voltage_csv(path: Path) -> np.ndarray:
    xs = []
    with path.open("r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            xs.append(float(row["voltage_v"]))
    return np.array(xs, dtype=np.float32)

def mutate_params(p: DSLiteParams, rng: np.random.Generator) -> DSLiteParams:
    d = p.as_dict()
    # Mutations (bounded)
    d["lanes"] = int(np.clip(d["lanes"] + int(rng.integers(-128, 129)), 32, 4096))
    d["k_keep"] = int(np.clip(d["k_keep"] + int(rng.integers(-64, 65)), 8, d["lanes"]))
    d["kernel_L"] = int(np.clip(d["kernel_L"] + int(rng.integers(-4, 5)), 8, 64))
    d["threshold"] = float(np.clip(d["threshold"] + float(rng.normal(0.0, 2.0)), -30.0, 30.0))
    d["noise_std"] = float(np.clip(d["noise_std"] + float(rng.normal(0.0, 0.2)), 0.0, 2.0))
    d["stride"] = int(np.clip(d["stride"] + int(rng.integers(-1, 2)), 1, 8))
    d["calib_frac"] = float(np.clip(d["calib_frac"] + float(rng.normal(0.0, 0.03)), 0.1, 0.5))
    # Breath (display knobs)
    d["te"] = int(np.clip(d["te"] + int(rng.integers(-60, 61)), 100, 1200))
    d["tc"] = int(np.clip(d["tc"] + int(rng.integers(-60, 61)), 100, 1200))
    d["alpha_time"] = float(np.clip(d["alpha_time"] + float(rng.normal(0.0, 0.03)), 0.0, 1.0))
    return DSLiteParams(**d)

def radar_polygon(ax, labels: List[str], values: List[float], title: str):
    # values assumed normalized 0..1
    N = len(labels)
    angles = np.linspace(0, 2*np.pi, N, endpoint=False).tolist()
    # close loop
    angles += angles[:1]
    vals = values + values[:1]

    ax.set_theta_offset(np.pi/2)
    ax.set_theta_direction(-1)
    ax.set_thetagrids(np.degrees(angles[:-1]), labels)
    ax.set_ylim(0.0, 1.0)
    ax.plot(angles, vals)
    ax.fill(angles, vals, alpha=0.15)
    ax.set_title(title)

def normalize_params(p: DSLiteParams) -> Tuple[List[str], List[float]]:
    # Normalize each dimension to 0..1 for polygon display
    d = p.as_dict()
    specs = [
        ("lanes", d["lanes"], 32, 4096),
        ("k_keep", d["k_keep"], 8, max(8, d["lanes"])),
        ("kernel_L", d["kernel_L"], 8, 64),
        ("threshold", d["threshold"], -30.0, 30.0),
        ("noise_std", d["noise_std"], 0.0, 2.0),
        ("stride", d["stride"], 1, 8),
        ("calib_frac", d["calib_frac"], 0.1, 0.5),
        ("Te", d["te"], 100, 1200),
        ("Tc", d["tc"], 100, 1200),
        ("alpha_time", d["alpha_time"], 0.0, 1.0),
    ]
    labels = [s[0] for s in specs]
    vals = []
    for _, v, lo, hi in specs:
        if hi == lo:
            vals.append(0.0)
        else:
            vals.append(float(np.clip((float(v) - float(lo)) / (float(hi) - float(lo)), 0.0, 1.0)))
    return labels, vals

def run_dynamic_optimizer(x: np.ndarray, platform: str, cycles: int = 12, candidates: int = 24, seed: int = 0):
    rng = np.random.default_rng(seed)
    base = DSLiteParams(lanes=512, k_keep=128, kernel_L=16, threshold=0.0, noise_std=0.1, stride=1, calib_frac=0.2, te=600, tc=400, alpha_time=0.2)

    # Set backend for DS-lite based on platform
    if platform == "cuda":
        os.environ["DSHIFT_ACCEL_BACKEND"] = "cuda"
    else:
        os.environ["DSHIFT_ACCEL_BACKEND"] = "cpu"

    rows = []
    best = base
    best_rmse, best_sec, best_det = evaluate_ds_lite(x, best, seed=seed, topk_mode="partial")
    best_obj = objective(best_rmse, best_sec, best.alpha_time)

    for c in range(cycles):
        # propose candidates around best
        cand = [best] + [mutate_params(best, rng) for _ in range(candidates)]
        scored = []
        for i, p in enumerate(cand):
            rmse, sec, det = evaluate_ds_lite(x, p, seed=seed + c*17 + i, topk_mode="partial")
            obj = objective(rmse, sec, p.alpha_time)
            scored.append((obj, rmse, sec, p, det))
        scored.sort(key=lambda t: t[0])
        obj, rmse, sec, p, det = scored[0]
        best = p; best_obj=obj; best_rmse=rmse; best_sec=sec; best_det=det

        d = p.as_dict()
        rows.append({
            "cycle": c,
            "objective": best_obj,
            "rmse": best_rmse,
            "sec": best_sec,
            **d,
        })

    return rows, best

def save_csv(rows: List[Dict[str, Any]], path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    keys = list(rows[0].keys()) if rows else []
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=keys)
        w.writeheader()
        for r in rows:
            w.writerow(r)

def main(out_dir: Path = Path("runs"), platform: str = None):
    out_dir.mkdir(parents=True, exist_ok=True)
    platform = (platform or os.getenv("DLINK_PLATFORM", "cpu")).strip().lower()
    x = read_voltage_csv(Path("data/voltage_default.csv"))

    # Dynamic optimization (10D polygon per cycle)
    rows, best = run_dynamic_optimizer(x, platform=platform, cycles=int(os.getenv('DSHIFT_DEMO_CYCLES','8')), candidates=int(os.getenv('DSHIFT_DEMO_CANDIDATES','12')), seed=0)
    save_csv(rows, out_dir/"ds_dynamic_params.csv")

    # Baselines at final best lanes/k
    b_fixed = run_baseline_fixed(x, best, seed=1)
    b_rand = run_baseline_random_topk(x, best, seed=2)
    b_full = run_baseline_fullsort_topk(x, best, seed=3)

    # CPU vs CUDA benchmark of DS-lite evaluation itself (same params)
    os.environ["DSHIFT_ACCEL_BACKEND"] = "cpu"
    rmse_cpu, sec_cpu, _ = evaluate_ds_lite(x, best, seed=10, topk_mode="partial")
    os.environ["DSHIFT_ACCEL_BACKEND"] = "cuda"
    rmse_gpu, sec_gpu, _ = evaluate_ds_lite(x, best, seed=10, topk_mode="partial")
    # If cupy not installed, sec_gpu ~= cpu and backend will be numpy anyway, but still ok.

    # Save benchmark CSV
    bench_path = out_dir/"ds_dynamic_benchmark_cpu_vs_platform.csv"
    with bench_path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["metric", "cpu", "platform", "platform_value"])
        w.writerow(["rmse", rmse_cpu, platform, rmse_gpu])
        w.writerow(["sec", sec_cpu, platform, sec_gpu])

    # Plot 1: objective and rmse over cycles
    cycles = [r["cycle"] for r in rows]
    obj = [r["objective"] for r in rows]
    rmse = [r["rmse"] for r in rows]
    lanes = [r["lanes"] for r in rows]
    kkeep = [r["k_keep"] for r in rows]

    plt.figure()
    plt.plot(cycles, obj, marker="o")
    plt.xlabel("cycle")
    plt.ylabel("objective (rmse + alpha_time*sec)")
    plt.title("Dynamic DS (10D) optimization: objective over cycles")
    p1 = out_dir/"ds_dynamic_objective.png"
    plt.savefig(p1, dpi=160, bbox_inches="tight")
    plt.close()

    plt.figure()
    plt.plot(cycles, rmse, marker="o")
    plt.xlabel("cycle")
    plt.ylabel("rmse")
    plt.title("Dynamic DS (10D): rmse over cycles")
    p2 = out_dir/"ds_dynamic_rmse.png"
    plt.savefig(p2, dpi=160, bbox_inches="tight")
    plt.close()

    plt.figure()
    plt.plot(cycles, lanes, marker="o", label="lanes")
    plt.plot(cycles, kkeep, marker="o", label="k_keep")
    plt.xlabel("cycle")
    plt.ylabel("value")
    plt.title("DE/DR dynamics: lanes (DE) and Top-K keep (DR)")
    plt.legend()
    p3 = out_dir/"ds_dynamic_de_dr.png"
    plt.savefig(p3, dpi=160, bbox_inches="tight")
    plt.close()

    # Plot 2: polygon/radar snapshots (first, mid, last)
    snap_idx = [0, len(rows)//2, len(rows)-1]
    plt.figure(figsize=(10, 3.6))
    for j, si in enumerate(snap_idx, start=1):
        ax = plt.subplot(1, 3, j, polar=True)
        p = DSLiteParams(**{k: rows[si][k] for k in best.as_dict().keys()})
        labels, vals = normalize_params(p)
        radar_polygon(ax, labels, vals, title=f"cycle {rows[si]['cycle']}")
    p4 = out_dir/"ds_dynamic_polygon.png"
    plt.savefig(p4, dpi=160, bbox_inches="tight")
    plt.close()

    # Plot 3: DS vs baselines (rmse & time)
    names = [b_fixed.name, b_rand.name, b_full.name, "best_ds"]
    rmses = [b_fixed.rmse, b_rand.rmse, b_full.rmse, rows[-1]["rmse"]]
    secs = [b_fixed.sec, b_rand.sec, b_full.sec, rows[-1]["sec"]]

    plt.figure()
    plt.bar(names, rmses)
    plt.ylabel("rmse (lower is better)")
    plt.title("DS vs baselines: quality")
    p5 = out_dir/"ds_vs_baselines_rmse.png"
    plt.savefig(p5, dpi=160, bbox_inches="tight")
    plt.close()

    plt.figure()
    plt.bar(names, secs)
    plt.ylabel("seconds (lower is better)")
    plt.title("DS vs baselines: compute time")
    p6 = out_dir/"ds_vs_baselines_time.png"
    plt.savefig(p6, dpi=160, bbox_inches="tight")
    plt.close()

    # Plot 4: CPU vs platform time
    plt.figure()
    plt.bar(["cpu", platform], [sec_cpu, sec_gpu])
    plt.ylabel("seconds (lower is better)")
    plt.title("DS-lite evaluation time: CPU vs platform")
    p7 = out_dir/"ds_cpu_vs_platform.png"
    plt.savefig(p7, dpi=160, bbox_inches="tight")
    plt.close()

    # Write short markdown summary
    md = out_dir/"ds_dynamic_report.md"
    md.write_text(f"""# Dynamic 10D DS Optimizer Demo (DS-lite)

Platform selected: **{platform}**

## What this demonstrates
- **DE (Dimensional Expansion):** lanes increase/decrease over cycles.
- **DR (Dimensional Reduction / Dim-plosion):** Top-K keep changes over cycles.
- **Dynamic parameters:** 10D parameter vector adapts each cycle to reduce objective.
- **GPU readiness:** evaluation can run on CUDA via CuPy when installed.

## Outputs
- {p1.as_posix()}
- {p2.as_posix()}
- {p3.as_posix()}
- {p4.as_posix()}  (polygon/radar snapshots)
- {p5.as_posix()}
- {p6.as_posix()}
- {p7.as_posix()}
- CSV: { (out_dir/'ds_dynamic_params.csv').as_posix() }
- Benchmark CSV: { bench_path.as_posix() }

## Final best parameters
{best.as_dict()}

## DS vs baselines (rmse/sec)
- fixed_ds: rmse={b_fixed.rmse:.4f}, sec={b_fixed.sec:.4f}
- randomish_topk: rmse={b_rand.rmse:.4f}, sec={b_rand.sec:.4f}
- fullsort_topk: rmse={b_full.rmse:.4f}, sec={b_full.sec:.4f}
- best_ds: rmse={rows[-1]['rmse']:.4f}, sec={rows[-1]['sec']:.4f}

## CPU vs {platform}
- rmse cpu={rmse_cpu:.4f} vs platform={rmse_gpu:.4f}
- sec  cpu={sec_cpu:.4f} vs platform={sec_gpu:.4f}

""", encoding="utf-8")

    print("Wrote DS dynamic demo artifacts to runs/:")
    for p in [p1,p2,p3,p4,p5,p6,p7, md, out_dir/'ds_dynamic_params.csv', bench_path]:
        print(" -", p.as_posix())

if __name__ == "__main__":
    main()
