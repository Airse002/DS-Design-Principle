from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Tuple, Optional
import numpy as np

def xp_backend():
    """Return array backend (cupy if available and requested), else numpy."""
    import os
    mode = os.getenv("DSHIFT_ACCEL_BACKEND", "cpu").strip().lower()
    if mode == "cuda":
        try:
            import cupy as cp  # type: ignore
            _ = cp.cuda.runtime.getDeviceCount()
            return cp
        except Exception:
            return np
    return np

@dataclass
class DSLiteParams:
    # 10D parameter vector (some affect compute/quality directly; others are demo knobs)
    lanes: int = 256            # DE: number of lanes (dimensions)
    k_keep: int = 64            # DR: Top-K lanes kept
    kernel_L: int = 16          # kernel length (history window)
    threshold: float = 0.0      # bit threshold on projection
    noise_std: float = 0.0      # kernel noise
    stride: int = 1             # sampling stride (heartbeat effect proxy)
    calib_frac: float = 0.2     # fraction used to fit a,b
    te: int = 600               # breath expand (display only in this DS-lite)
    tc: int = 400               # breath collision (display only)
    alpha_time: float = 0.2     # objective weight on time cost

    def as_dict(self) -> Dict[str, Any]:
        return {
            "lanes": int(self.lanes),
            "k_keep": int(self.k_keep),
            "kernel_L": int(self.kernel_L),
            "threshold": float(self.threshold),
            "noise_std": float(self.noise_std),
            "stride": int(self.stride),
            "calib_frac": float(self.calib_frac),
            "te": int(self.te),
            "tc": int(self.tc),
            "alpha_time": float(self.alpha_time),
        }

def _build_kernels(xp, lanes: int, L: int, seed: int, noise_std: float):
    rs = np.random.default_rng(seed)
    W = rs.normal(0.0, 1.0, size=(lanes, L)).astype(np.float32)
    if noise_std > 0:
        W = W + rs.normal(0.0, noise_std, size=W.shape).astype(np.float32)
    # Normalize rows a bit for stability
    W /= (np.linalg.norm(W, axis=1, keepdims=True) + 1e-6)
    if xp.__name__ == "cupy":
        import cupy as cp  # type: ignore
        return cp.asarray(W)
    return W

def _sliding_hist(x: np.ndarray, L: int, stride: int):
    # Return matrix H of shape (T, L), where H[t] is history ending at time t*stride
    N = x.shape[0]
    idx = np.arange(0, N, stride, dtype=int)
    # ensure enough history
    idx = idx[idx >= L-1]
    T = idx.shape[0]
    H = np.zeros((T, L), dtype=np.float32)
    for i, n in enumerate(idx):
        H[i, :] = x[n-L+1:n+1].astype(np.float32)
    y = x[idx].astype(np.float32)
    return H, y, idx

def evaluate_ds_lite(x: np.ndarray, params: DSLiteParams, seed: int = 0, topk_mode: str = "partial") -> Tuple[float, float, Dict[str, Any]]:
    """Evaluate DS-lite objective.

    Returns: (rmse, seconds, details)

    DS-lite definition (demo-friendly):
    - Random kernels W (lanes x L)
    - Projections z = H @ W^T, bits b = (z > threshold)
    - Feature f_t = mean(b) over lanes
    - Fit x ~ a*f + c on calibration segment, then predict and compute rmse
    - DR: keep only top-k lanes by correlation with x on calibration (optional)
    """
    xp = xp_backend()
    t0 = __import__("time").perf_counter()
    H, y, idx = _sliding_hist(x, params.kernel_L, max(1, params.stride))
    if H.shape[0] < 10:
        return float("inf"), 0.0, {"reason": "too_short"}

    # Move to xp
    if xp.__name__ == "cupy":
        import cupy as cp  # type: ignore
        Hx = cp.asarray(H)
        yx = cp.asarray(y)
    else:
        Hx = H
        yx = y

    W = _build_kernels(xp, int(params.lanes), int(params.kernel_L), seed=seed, noise_std=float(params.noise_std))
    # z: (T, lanes)
    z = Hx @ (W.T)
    b = (z > float(params.threshold)).astype(xp.float32)

    # calibration split
    T = int(b.shape[0])
    t_cal = max(8, int(T * float(params.calib_frac)))
    b_cal = b[:t_cal, :]
    y_cal = yx[:t_cal]

    # optional DR (top-k selection)
    keep_idx = None
    if int(params.k_keep) < int(params.lanes):
        # compute correlation proxy: corr ~ cov(b_i, y)
        # cov(b_i, y) = mean((b_i - mean(b_i))*(y-mean(y)))
        bi = b_cal
        ym = xp.mean(y_cal)
        yc = y_cal - ym
        bi_m = xp.mean(bi, axis=0)
        bi_c = bi - bi_m
        score = xp.mean(bi_c * yc.reshape(-1, 1), axis=0)  # (lanes,)
        K = max(2, min(int(params.k_keep), int(params.lanes)))
        if xp.__name__ == "cupy":
            import cupy as cp  # type: ignore
            if topk_mode == "fullsort":
                keep_idx = cp.argsort(score)[-K:]
            else:
                keep_idx = cp.argpartition(score, -K)[-K:]
        else:
            if topk_mode == "fullsort":
                keep_idx = np.argsort(score)[-K:]
            else:
                keep_idx = np.argpartition(score, -K)[-K:]
        b = b[:, keep_idx]

    # feature: mean bits
    f = xp.mean(b, axis=1)  # (T,)
    # Fit y ~ a*f + c on calibration (least squares 2x2)
    f_cal = f[:t_cal]
    # solve for a,c in normal equations:
    # [sum(f^2) sum(f); sum(f) n] [a c]^T = [sum(f*y), sum(y)]
    n = xp.float32(f_cal.shape[0])
    sff = xp.sum(f_cal * f_cal)
    sf = xp.sum(f_cal)
    sfy = xp.sum(f_cal * y_cal)
    sy = xp.sum(y_cal)
    det = sff * n - sf * sf + 1e-9
    a = (sfy * n - sy * sf) / det
    c = (sff * sy - sfy * sf) / det

    yhat = a * f + c
    err = yhat - yx
    rmse = xp.sqrt(xp.mean(err * err))

    # bring back
    if xp.__name__ == "cupy":
        import cupy as cp  # type: ignore
        rmse_f = float(cp.asnumpy(rmse))
        keep = keep_idx
        if keep is not None:
            keep = cp.asnumpy(keep).astype(int).tolist()
    else:
        rmse_f = float(rmse)
        keep = keep_idx.tolist() if keep_idx is not None else None

    t1 = __import__("time").perf_counter()
    sec = float(t1 - t0)
    details = {
        "T": int(T),
        "t_cal": int(t_cal),
        "idx0": int(idx[0]),
        "idx_last": int(idx[-1]),
        "kept_idx": keep,
        "topk_mode": topk_mode,
        "backend": xp.__name__,
    }
    return rmse_f, sec, details

def objective(rmse: float, sec: float, alpha_time: float) -> float:
    return float(rmse + alpha_time * sec)
