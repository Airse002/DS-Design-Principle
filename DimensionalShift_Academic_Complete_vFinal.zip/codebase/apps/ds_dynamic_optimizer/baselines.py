from __future__ import annotations
from dataclasses import dataclass
from typing import Tuple, Dict, Any
import numpy as np

from .ds_lite import DSLiteParams, evaluate_ds_lite, objective

@dataclass
class BaselineResult:
    name: str
    rmse: float
    sec: float
    obj: float
    details: Dict[str, Any]

def run_baseline_fixed(x: np.ndarray, p: DSLiteParams, seed: int = 0) -> BaselineResult:
    rmse, sec, det = evaluate_ds_lite(x, p, seed=seed, topk_mode="partial")
    return BaselineResult("fixed_ds", rmse, sec, objective(rmse, sec, p.alpha_time), det)

def run_baseline_random_topk(x: np.ndarray, p: DSLiteParams, seed: int = 0) -> BaselineResult:
    # emulate random keep by forcing full lanes but random subset indices; implement by shuffling and using k_keep
    # We'll use ds_lite eval but by setting k_keep and then corrupting "score" selection with random perm
    # Simplified: just run with k_keep but with topk_mode="fullsort" and then permute kernels by seed => behaves random-ish.
    p2 = DSLiteParams(**p.as_dict())
    # Increase noise so selection becomes less correlated -> approximates random selection
    p2.noise_std = max(p2.noise_std, 1.0)
    rmse, sec, det = evaluate_ds_lite(x, p2, seed=seed+1337, topk_mode="fullsort")
    return BaselineResult("randomish_topk", rmse, sec, objective(rmse, sec, p.alpha_time), det)

def run_baseline_fullsort_topk(x: np.ndarray, p: DSLiteParams, seed: int = 0) -> BaselineResult:
    rmse, sec, det = evaluate_ds_lite(x, p, seed=seed, topk_mode="fullsort")
    return BaselineResult("fullsort_topk", rmse, sec, objective(rmse, sec, p.alpha_time), det)
