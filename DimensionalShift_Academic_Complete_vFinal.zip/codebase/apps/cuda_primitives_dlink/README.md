# D-Link CUDA Primitives (UTB-style) — DS-driven demo pack

This folder provides a **C/C++ CUDA** app that demonstrates "primitive" tasks required in UTB exercises,
but wrapped in a **D-Link / Dimensional Shift (DS) pulse** concept:

- **EXPAND phase**: explore candidate launch parameters (block sizes) and measure time (objective)
- **COLLAPSE phase**: choose best candidate and run the operation

## Implements
1) **Vector Add** (1D)
2) **Matrix Multiply** (2D) — *global memory baseline* (trivial, no shared memory tiling)
3) **2D Convolution on RGB image** — uses **shared memory** tile (optimized global loads)

> Image I/O uses a small embedded codec under `include/lodepng.*`.
> For strict PNG compliance you can replace it with full `lodepng.cpp` or `libpng++`.

## Build (on GPU server)
```bash
cd apps/cuda_primitives_dlink
bash scripts/build.sh
```

## Run examples
```bash
bash scripts/run_examples.sh
```

Outputs:
- `runs/primitives_timing.csv` (timings per op / cfg)
- `runs/out_blur.png`, `runs/out_edge.png` (conv output)

## CLI usage
```bash
build/dlink_cuda_primitives --op vecadd|matmul|conv2d --mode expand|collapse [args]
```

## DS mapping (for explanation)
- **DE** (Dimensional Expansion) ≈ exploration: try multiple configs (block sizes)
- **DR** (Dimensional Reduction / Dim-plosion) ≈ selection: keep best config, discard others
- **Pulse** ≈ repeating EXPAND/COLLAPSE cycles

This is a *demonstration* of DS-control ideas applied to classic CUDA workloads.

## Real PNG workflow (recommended for UTB submission)
The CUDA binary reads/writes **DSRAW RGBA** for simplicity and reproducibility. For UTB you still use PNG as source/target
by converting PNG<->DSRAW with the included scripts (Pillow).

```bash
python scripts/png_to_dsraw.py --in your.png --out runs/in.dsraw
build/dlink_cuda_primitives --op conv2d --mode expand --in runs/in.dsraw --out runs/out.dsraw --kernel edge3 --impl shared --iters 20
python scripts/dsraw_to_png.py --in runs/out.dsraw --out out.png
```
