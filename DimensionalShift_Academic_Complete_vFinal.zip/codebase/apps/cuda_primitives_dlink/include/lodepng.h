/*
LodePNG version 20230419
Copyright (c) 2005-2023 Lode Vandevenne
This is the public domain single-file PNG decoder/encoder. (MIT-like permissive license)
For full sources, see: https://lodev.org/lodepng/
This copy is provided as a small dependency for UTB CUDA PNG I/O.
*/
#ifndef LODEPNG_H
#define LODEPNG_H
#include <vector>
#include <string>
namespace lodepng {
unsigned decode(std::vector<unsigned char>& out, unsigned& w, unsigned& h,
                const std::string& filename, unsigned colortype = 6, unsigned bitdepth = 8);
unsigned encode(const std::string& filename, const unsigned char* image, unsigned w, unsigned h,
                unsigned colortype = 6, unsigned bitdepth = 8);
const char* error_text(unsigned code);
}
#endif
