#include "dlink_common.cuh"
#include <cstring>
#include <string>
#include <fstream>

extern "C" float run_vec_add(int n, int block, int iters);
extern "C" float run_matmul_global(int N, dim3 block, int iters);
extern "C" float run_conv2d_rgb_dsraw(const char* in_path, const char* out_path, const char* kernel_name,
                                     dim3 block, int iters, int impl);

static void usage(){
  printf("dlink_cuda_primitives --op vecadd|matmul|conv2d --mode expand|collapse\n");
  printf("  vecadd  : --n 10000000 --iters 50\n");
  printf("  matmul  : --N 1024 --iters 5\n");
  printf("  conv2d  : --in data/sample.dsraw --out runs/out.dsraw --kernel blur3|edge3|sharpen3 --impl global|shared --iters 20\n");
  printf("Optional:\n");
  printf("  --block1d 256           (vecadd)\n");
  printf("  --block2d 16x16         (matmul/conv2d)\n");
  printf("  --csv runs/timing.csv   (append timing row)\n");
  printf("DS pulse:\n");
  printf("  mode=expand explores candidates and records best; mode=collapse runs best candidate.\n");
}

static bool parse_dim2(const char* s, int& x, int& y){
  return std::sscanf(s, "%dx%d", &x, &y) == 2;
}

int main(int argc, char** argv){
  std::string op="vecadd";
  std::string mode="expand";
  int n=1<<20;
  int N=512;
  int iters=10;
  std::string in="apps/cuda_primitives_dlink/data/sample.dsraw";
  std::string out="runs/out.dsraw";
  std::string kernel="blur3";
  std::string impl="shared";
  int block1d=256;
  int bx=16, by=16;
  std::string csvPath="";

  for(int i=1;i<argc;i++){
    if(!std::strcmp(argv[i],"--op") && i+1<argc) op=argv[++i];
    else if(!std::strcmp(argv[i],"--mode") && i+1<argc) mode=argv[++i];
    else if(!std::strcmp(argv[i],"--n") && i+1<argc) n=std::atoi(argv[++i]);
    else if(!std::strcmp(argv[i],"--N") && i+1<argc) N=std::atoi(argv[++i]);
    else if(!std::strcmp(argv[i],"--iters") && i+1<argc) iters=std::atoi(argv[++i]);
    else if(!std::strcmp(argv[i],"--in") && i+1<argc) in=argv[++i];
    else if(!std::strcmp(argv[i],"--out") && i+1<argc) out=argv[++i];
    else if(!std::strcmp(argv[i],"--kernel") && i+1<argc) kernel=argv[++i];
    else if(!std::strcmp(argv[i],"--impl") && i+1<argc) impl=argv[++i];
    else if(!std::strcmp(argv[i],"--block1d") && i+1<argc) block1d=std::atoi(argv[++i]);
    else if(!std::strcmp(argv[i],"--block2d") && i+1<argc){ parse_dim2(argv[++i], bx, by); }
    else if(!std::strcmp(argv[i],"--csv") && i+1<argc) csvPath=argv[++i];
    else if(!std::strcmp(argv[i],"--help")){ usage(); return 0; }
  }

  CUDA_CHECK(cudaFree(0)); // init

  float best_ms = 1e30f;
  std::string best_cfg = "";
  auto append_csv = [&](const std::string& cfg, float ms){
    if(csvPath.empty()) return;
    bool exists = std::ifstream(csvPath).good();
    std::ofstream f(csvPath, std::ios::app);
    if(!exists) f << "op,mode,cfg,ms\n";
    f << op << "," << mode << "," << cfg << "," << ms << "\n";
  };

  if(op=="vecadd"){
    if(mode=="expand"){
      for(int b : candidate_blocks_1d()){
        float ms = run_vec_add(n, b, iters);
        std::string cfg = "block="+std::to_string(b);
        append_csv(cfg, ms);
        if(ms < best_ms){ best_ms = ms; best_cfg = cfg; block1d = b; }
      }
      printf("[DS-EXPAND] best %s ms=%.3f\n", best_cfg.c_str(), best_ms);
    }
    float ms = run_vec_add(n, block1d, iters);
    printf("[DS-%s] vecadd n=%d block=%d iters=%d ms=%.3f\n", mode.c_str(), n, block1d, iters, ms);
    append_csv("block="+std::to_string(block1d), ms);
    return 0;
  }

  if(op=="matmul"){
    if(mode=="expand"){
      for(dim3 b : candidate_blocks_2d()){
        float ms = run_matmul_global(N, b, iters);
        char cfg[64]; std::snprintf(cfg, sizeof(cfg), "block=%ux%u", b.x, b.y);
        append_csv(cfg, ms);
        if(ms < best_ms){ best_ms = ms; best_cfg = cfg; bx=b.x; by=b.y; }
      }
      printf("[DS-EXPAND] best %s ms=%.3f\n", best_cfg.c_str(), best_ms);
    }
    float ms = run_matmul_global(N, dim3(bx,by,1), iters);
    printf("[DS-%s] matmul N=%d block=%dx%d iters=%d ms=%.3f\n", mode.c_str(), N, bx, by, iters, ms);
    append_csv("block="+std::to_string(bx)+"x"+std::to_string(by), ms);
    return 0;
  }

  if(op=="conv2d"){
    if(mode=="expand"){
      for(dim3 b : candidate_blocks_2d()){
        float ms = run_conv2d_rgb_dsraw(in.c_str(), out.c_str(), kernel.c_str(), b, iters, impl=="global"?0:1);
        char cfg[96]; std::snprintf(cfg, sizeof(cfg), "block=%ux%u,kernel=%s", b.x, b.y, kernel.c_str());
        append_csv(cfg, ms);
        if(ms < best_ms){ best_ms = ms; best_cfg = cfg; bx=b.x; by=b.y; }
      }
      printf("[DS-EXPAND] best %s ms=%.3f\n", best_cfg.c_str(), best_ms);
    }
    float ms = run_conv2d_rgb_dsraw(in.c_str(), out.c_str(), kernel.c_str(), dim3(bx,by,1), iters, impl=="global"?0:1);
    printf("[DS-%s] conv2d(%s) in=%s out=%s block=%dx%d iters=%d ms=%.3f\n", mode.c_str(), impl.c_str(), in.c_str(), out.c_str(), bx, by, iters, ms);
    append_csv("block="+std::to_string(bx)+"x"+std::to_string(by)+",kernel="+kernel+",impl="+impl, ms);
    return 0;
  }

  usage();
  return 1;
}
