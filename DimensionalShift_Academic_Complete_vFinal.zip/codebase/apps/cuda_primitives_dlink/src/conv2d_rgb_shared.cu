#include "dlink_common.cuh"
#include <algorithm>
#include <vector>
#include <string>
#include <fstream>
#include <cstring>

__constant__ float dKernel[49]; // up to 7x7

// --- DSRAW I/O (RGBA8): "DSRAW" + w(uint32) + h(uint32) + bytes ---
static bool read_dsraw(const std::string& path, std::vector<unsigned char>& img, unsigned& w, unsigned& h){
  std::ifstream f(path, std::ios::binary);
  if(!f) return false;
  std::vector<unsigned char> b((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
  if(b.size() < 13) return false;
  if(std::memcmp(b.data(),"DSRAW",5)!=0) return false;
  auto rd32=[&](size_t off)->unsigned{
    return (unsigned)b[off] | ((unsigned)b[off+1]<<8) | ((unsigned)b[off+2]<<16) | ((unsigned)b[off+3]<<24);
  };
  w = rd32(5); h = rd32(9);
  size_t need = 13ull + 4ull*w*h;
  if(b.size() < need) return false;
  img.assign(b.begin()+13, b.begin()+need);
  return true;
}
static bool write_dsraw(const std::string& path, const std::vector<unsigned char>& img, unsigned w, unsigned h){
  std::ofstream f(path, std::ios::binary);
  if(!f) return false;
  f.write("DSRAW", 5);
  auto wr32=[&](unsigned v){
    unsigned char t[4] = { (unsigned char)(v & 255u), (unsigned char)((v>>8)&255u), (unsigned char)((v>>16)&255u), (unsigned char)((v>>24)&255u) };
    f.write((char*)t, 4);
  };
  wr32(w); wr32(h);
  f.write((const char*)img.data(), (std::streamsize)img.size());
  return true;
}

__global__ void conv2d_rgb_global(const unsigned char* in, unsigned char* out, int w, int h, int k, int pitch){
  const int R = k/2;
  int x = blockIdx.x * blockDim.x + threadIdx.x;
  int y = blockIdx.y * blockDim.y + threadIdx.y;
  if(x>=w || y>=h) return;

  float acc[3] = {0.f,0.f,0.f};
  for(int ky=0;ky<k;ky++){
    int yy = min(max(y + ky - R, 0), h-1);
    for(int kx=0;kx<k;kx++){
      int xx = min(max(x + kx - R, 0), w-1);
      float kv = dKernel[ky*k + kx];
      int gi = (yy*pitch + xx)*4;
      acc[0] += kv * float(in[gi+0]);
      acc[1] += kv * float(in[gi+1]);
      acc[2] += kv * float(in[gi+2]);
    }
  }
  int oi = (y*pitch + x)*4;
  out[oi+0] = (unsigned char)min(max(int(acc[0]+0.5f), 0), 255);
  out[oi+1] = (unsigned char)min(max(int(acc[1]+0.5f), 0), 255);
  out[oi+2] = (unsigned char)min(max(int(acc[2]+0.5f), 0), 255);
  out[oi+3] = in[oi+3];
}

__global__ void conv2d_rgb_shared(const unsigned char* in, unsigned char* out, int w, int h, int k, int pitch){
  const int R = k/2;
  extern __shared__ unsigned char tile[]; // (blockDim.x+2R)*(blockDim.y+2R)*4
  int tx = threadIdx.x, ty = threadIdx.y;
  int bx = blockIdx.x * blockDim.x;
  int by = blockIdx.y * blockDim.y;
  int x = bx + tx;
  int y = by + ty;

  int tileW = blockDim.x + 2*R;
  int tileH = blockDim.y + 2*R;

  for(int dy = ty; dy < tileH; dy += blockDim.y){
    int gy = min(max(by + dy - R, 0), h-1);
    for(int dx = tx; dx < tileW; dx += blockDim.x){
      int gx = min(max(bx + dx - R, 0), w-1);
      int gi = (gy*pitch + gx)*4;
      int ti = (dy*tileW + dx)*4;
      tile[ti+0]=in[gi+0];
      tile[ti+1]=in[gi+1];
      tile[ti+2]=in[gi+2];
      tile[ti+3]=in[gi+3];
    }
  }
  __syncthreads();

  if(x < w && y < h){
    float acc[3] = {0.f,0.f,0.f};
    for(int ky=0;ky<k;ky++){
      for(int kx=0;kx<k;kx++){
        float kv = dKernel[ky*k + kx];
        int ti = ((ty+ky)*tileW + (tx+kx))*4;
        acc[0] += kv * float(tile[ti+0]);
        acc[1] += kv * float(tile[ti+1]);
        acc[2] += kv * float(tile[ti+2]);
      }
    }
    int oi = (y*pitch + x)*4;
    out[oi+0] = (unsigned char)min(max(int(acc[0]+0.5f), 0), 255);
    out[oi+1] = (unsigned char)min(max(int(acc[1]+0.5f), 0), 255);
    out[oi+2] = (unsigned char)min(max(int(acc[2]+0.5f), 0), 255);
    out[oi+3] = in[oi+3];
  }
}

static void make_kernel(const std::string& name, std::vector<float>& K, int& k){
  if(name=="blur3"){
    k=3; K.assign(9, 1.f/9.f);
  } else if(name=="edge3"){
    k=3; K = { -1,-1,-1, -1, 8,-1, -1,-1,-1 };
  } else if(name=="sharpen3"){
    k=3; K = { 0,-1,0, -1,5,-1, 0,-1,0 };
  } else {
    k=3; K.assign(9, 1.f/9.f);
  }
}

extern "C" float run_conv2d_rgb_dsraw(const char* in_path, const char* out_path, const char* kernel_name,
                                     dim3 block, int iters, int impl){
  // impl: 0=global, 1=shared
  std::vector<unsigned char> img;
  unsigned w=0,h=0;
  if(!read_dsraw(std::string(in_path), img, w, h)){
    fprintf(stderr,"Failed to read DSRAW image: %s\n", in_path);
    return 1e30f;
  }
  if(img.size() != (size_t)w*h*4){
    fprintf(stderr,"unexpected image size\n");
    return 1e30f;
  }

  int k=3; std::vector<float> K;
  make_kernel(std::string(kernel_name), K, k);
  CUDA_CHECK(cudaMemcpyToSymbol(dKernel, K.data(), (size_t)k*k*sizeof(float)));

  unsigned char *din=nullptr, *dout=nullptr;
  size_t bytes = (size_t)w*h*4;
  CUDA_CHECK(cudaMalloc(&din, bytes));
  CUDA_CHECK(cudaMalloc(&dout, bytes));
  CUDA_CHECK(cudaMemcpy(din, img.data(), bytes, cudaMemcpyHostToDevice));

  dim3 B(block.x, block.y, 1);
  dim3 G((int(w)+B.x-1)/B.x, (int(h)+B.y-1)/B.y, 1);

  int R = k/2;
  size_t shmem = (size_t)(B.x + 2*R) * (size_t)(B.y + 2*R) * 4;

  Timer t;
  float ms = t.ms([&](){
    for(int i=0;i<iters;i++){
      if(impl==0) conv2d_rgb_global<<<G,B>>>(din, dout, (int)w, (int)h, k, (int)w);
      else conv2d_rgb_shared<<<G,B,shmem>>>(din, dout, (int)w, (int)h, k, (int)w);
    }
    CUDA_CHECK(cudaGetLastError());
  });

  std::vector<unsigned char> out(img.size());
  CUDA_CHECK(cudaMemcpy(out.data(), dout, bytes, cudaMemcpyDeviceToHost));
  if(!write_dsraw(std::string(out_path), out, w, h)){
    fprintf(stderr,"Failed to write DSRAW image: %s\n", out_path);
  }

  CUDA_CHECK(cudaFree(din)); CUDA_CHECK(cudaFree(dout));
  return ms;
}
