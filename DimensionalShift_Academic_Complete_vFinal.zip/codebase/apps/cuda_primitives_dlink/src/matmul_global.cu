#include "dlink_common.cuh"

__global__ void matMulGlobal(const float* A, const float* B, float* C, int N){
  int row = blockIdx.y * blockDim.y + threadIdx.y;
  int col = blockIdx.x * blockDim.x + threadIdx.x;
  if(row < N && col < N){
    float sum = 0.f;
    for(int k=0;k<N;k++){
      sum += A[row*N + k] * B[k*N + col];
    }
    C[row*N + col] = sum;
  }
}

extern "C" float run_matmul_global(int N, dim3 block, int iters){
  size_t bytes = (size_t)N*N*sizeof(float);
  std::vector<float> hA(N*N), hB(N*N), hC(N*N);
  // lexicographic init 1..n
  for(int i=0;i<N*N;i++){ hA[i]=float(i+1); hB[i]=float(i+1); }

  float *dA=nullptr,*dB=nullptr,*dC=nullptr;
  CUDA_CHECK(cudaMalloc(&dA, bytes));
  CUDA_CHECK(cudaMalloc(&dB, bytes));
  CUDA_CHECK(cudaMalloc(&dC, bytes));
  CUDA_CHECK(cudaMemcpy(dA, hA.data(), bytes, cudaMemcpyHostToDevice));
  CUDA_CHECK(cudaMemcpy(dB, hB.data(), bytes, cudaMemcpyHostToDevice));

  dim3 B(block.x, block.y, 1);
  dim3 G((N + B.x - 1)/B.x, (N + B.y - 1)/B.y, 1);

  Timer t;
  float ms = t.ms([&](){
    for(int k=0;k<iters;k++) matMulGlobal<<<G,B>>>(dA,dB,dC,N);
    CUDA_CHECK(cudaGetLastError());
  });
  CUDA_CHECK(cudaMemcpy(hC.data(), dC, bytes, cudaMemcpyDeviceToHost));

  // light sanity: C[0,0] = sum_{k} A[0,k]*B[k,0]
  float ref=0.f;
  for(int k=0;k<N;k++) ref += hA[k]*hB[k*N];
  if(std::abs(hC[0]-ref) > 1e-2f){
    fprintf(stderr,"matMul mismatch: %f vs %f\n", hC[0], ref);
  }

  CUDA_CHECK(cudaFree(dA)); CUDA_CHECK(cudaFree(dB)); CUDA_CHECK(cudaFree(dC));
  return ms;
}
