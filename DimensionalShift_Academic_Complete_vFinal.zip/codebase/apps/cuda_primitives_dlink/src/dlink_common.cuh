#pragma once
#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <vector>
#include <string>
#include <chrono>

#define CUDA_CHECK(call) do { \
  cudaError_t _e = (call); \
  if (_e != cudaSuccess) { \
    fprintf(stderr, "CUDA error %s:%d: %s\n", __FILE__, __LINE__, cudaGetErrorString(_e)); \
    std::exit(1); \
  } \
} while(0)

struct Timer {
  cudaEvent_t a{}, b{};
  Timer(){ CUDA_CHECK(cudaEventCreate(&a)); CUDA_CHECK(cudaEventCreate(&b)); }
  ~Timer(){ cudaEventDestroy(a); cudaEventDestroy(b); }
  float ms(std::function<void()> fn){
    CUDA_CHECK(cudaEventRecord(a));
    fn();
    CUDA_CHECK(cudaEventRecord(b));
    CUDA_CHECK(cudaEventSynchronize(b));
    float m=0.f; CUDA_CHECK(cudaEventElapsedTime(&m, a, b));
    return m;
  }
};

// DS-style pulse: EXPAND explores candidate launch params, COLLAPSE selects best
struct DSPulseChoice {
  dim3 block{16,16,1};
  dim3 grid{1,1,1};
  float ms = 1e30f;
};

inline std::vector<dim3> candidate_blocks_2d(){
  return { dim3(8,8,1), dim3(16,16,1), dim3(32,8,1), dim3(8,32,1), dim3(32,16,1) };
}
inline std::vector<int> candidate_blocks_1d(){
  return { 64, 128, 256, 512 };
}
