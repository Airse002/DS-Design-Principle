#include "dlink_common.cuh"

__global__ void vecAdd(const float* a, const float* b, float* c, int n){
  int i = blockIdx.x * blockDim.x + threadIdx.x;
  if(i < n) c[i] = a[i] + b[i];
}

extern "C" float run_vec_add(int n, int block, int iters){
  std::vector<float> ha(n), hb(n), hc(n);
  for(int i=0;i<n;i++){ ha[i]=float(i+1); hb[i]=float(n-i); }
  float *da=nullptr,*db=nullptr,*dc=nullptr;
  CUDA_CHECK(cudaMalloc(&da, n*sizeof(float)));
  CUDA_CHECK(cudaMalloc(&db, n*sizeof(float)));
  CUDA_CHECK(cudaMalloc(&dc, n*sizeof(float)));
  CUDA_CHECK(cudaMemcpy(da, ha.data(), n*sizeof(float), cudaMemcpyHostToDevice));
  CUDA_CHECK(cudaMemcpy(db, hb.data(), n*sizeof(float), cudaMemcpyHostToDevice));

  dim3 B(block,1,1);
  dim3 G((n + block - 1)/block,1,1);

  Timer t;
  float ms = t.ms([&](){
    for(int k=0;k<iters;k++) vecAdd<<<G,B>>>(da,db,dc,n);
    CUDA_CHECK(cudaGetLastError());
  });
  CUDA_CHECK(cudaMemcpy(hc.data(), dc, n*sizeof(float), cudaMemcpyDeviceToHost));

  // quick correctness check
  for(int i=0;i<5 && i<n;i++){
    float ref = ha[i]+hb[i];
    if(std::abs(hc[i]-ref) > 1e-3f){
      fprintf(stderr,"vecAdd mismatch at %d: %f vs %f\n", i, hc[i], ref);
      break;
    }
  }

  CUDA_CHECK(cudaFree(da)); CUDA_CHECK(cudaFree(db)); CUDA_CHECK(cudaFree(dc));
  return ms;
}
