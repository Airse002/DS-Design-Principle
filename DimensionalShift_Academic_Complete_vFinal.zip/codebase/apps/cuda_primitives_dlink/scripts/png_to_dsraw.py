#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import argparse

def main():
    ap = argparse.ArgumentParser(description="Convert PNG to DSRAW container (RGBA8) used by CUDA primitives demo.")
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    args = ap.parse_args()

    img = Image.open(args.inp).convert("RGBA")
    w, h = img.size
    px = img.tobytes()

    outp = Path(args.out)
    outp.parent.mkdir(parents=True, exist_ok=True)
    with outp.open("wb") as f:
        f.write(b"DSRAW")
        f.write(int(w).to_bytes(4, "little"))
        f.write(int(h).to_bytes(4, "little"))
        f.write(px)
    print(f"Wrote DSRAW: {outp} ({w}x{h})")

if __name__ == "__main__":
    main()
