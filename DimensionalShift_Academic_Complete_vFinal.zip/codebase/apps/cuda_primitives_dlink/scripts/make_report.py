#!/usr/bin/env python3
import argparse, csv
from pathlib import Path
import matplotlib.pyplot as plt

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--csv", required=True)
    ap.add_argument("--out", required=True)
    args = ap.parse_args()

    rows = []
    with open(args.csv, "r", encoding="utf-8") as f:
        r = csv.DictReader(f)
        for row in r:
            rows.append(row)

    ms = [float(r["ms"]) for r in rows]
    labels = [f'{r["op"]}:{r["mode"]}' for r in rows]

    out_md = Path(args.out)
    out_md.parent.mkdir(parents=True, exist_ok=True)

    plt.figure(figsize=(8,3.5))
    plt.plot(range(len(ms)), ms, marker="o")
    plt.xticks(range(len(ms)), labels, rotation=60, ha="right", fontsize=8)
    plt.ylabel("ms")
    plt.title("UTB primitives — DS pulse timings (EXPAND vs COLLAPSE)")
    p1 = out_md.parent/"utb_bench_plot_ms.png"
    plt.savefig(p1, dpi=160, bbox_inches="tight")
    plt.close()

    def best_collapse(op, contains):
        best = None
        for r in rows:
            if r["op"]==op and r["mode"]=="collapse" and contains in r["cfg"]:
                v = float(r["ms"])
                if best is None or v < best:
                    best = v
        return best

    conv_shared = best_collapse("conv2d", "impl=shared")
    conv_global = best_collapse("conv2d", "impl=global")
    speedup = (conv_global/conv_shared) if (conv_shared and conv_global) else None

    if conv_shared and conv_global:
        plt.figure()
        plt.bar(["global","shared"], [conv_global, conv_shared])
        plt.ylabel("ms")
        plt.title("Conv2D: global vs shared (collapse best)")
        p2 = out_md.parent/"utb_conv_speedup.png"
        plt.savefig(p2, dpi=160, bbox_inches="tight")
        plt.close()
    else:
        p2 = None

    lines = []
    lines += ["# UTB CUDA primitives — D-Link / Dimensional Shift report", ""]
    lines += ["## DS usage across benchmarking/computing", 
              "- Every operation runs in a DS **pulse**:", 
              "  - **EXPAND (DE)** explores candidate launch configs (block sizes) and measures time.", 
              "  - **COLLAPSE (DR)** selects the best config and executes it as the chosen policy.", 
              "  This is the same D-Link 'measure → select → apply' loop used elsewhere in the repo.", ""]
    lines += ["## Why shared memory wins in conv2D", 
              "- Global baseline re-reads overlapping neighborhoods from global memory for each output pixel.", 
              "- Shared-memory tiling loads a block+halo once and reuses it for many output pixels.", 
              "- Fewer redundant global loads → better effective bandwidth.", ""]
    if speedup is not None:
        lines += [f"Measured speedup (global/shared): **{speedup:.2f}×** (collapse best).", ""]
    lines += ["## Artifacts", 
              f"- CSV: `{Path(args.csv).name}`", 
              f"- Plot: `{p1.name}`", 
              (f"- Conv plot: `{p2.name}`" if p2 else "- Conv plot: (missing)"), 
              "- Images: `out_blur_shared.png`, `out_blur_global.png`", ""]
    out_md.write_text("\n".join(lines), encoding="utf-8")
    print("Wrote", out_md)

if __name__ == "__main__":
    main()
