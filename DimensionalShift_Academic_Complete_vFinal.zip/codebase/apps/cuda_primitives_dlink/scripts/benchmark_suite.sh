#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$ROOT/../runs"
BIN="$ROOT/build/dlink_cuda_primitives"
CSV="$ROOT/../runs/utb_bench.csv"

echo "== DS-BENCH SUITE (button) =="
python "$ROOT/scripts/png_to_dsraw.py" --in "$ROOT/data/sample_real.png" --out "$ROOT/../runs/in.dsraw"

"$BIN" --op vecadd --mode expand --n 8000000 --iters 80 --csv "$CSV"
"$BIN" --op vecadd --mode collapse --n 8000000 --iters 80 --csv "$CSV"

"$BIN" --op matmul --mode expand --N 512 --iters 6 --csv "$CSV"
"$BIN" --op matmul --mode collapse --N 512 --iters 6 --csv "$CSV"

"$BIN" --op conv2d --mode expand --in "$ROOT/../runs/in.dsraw" --out "$ROOT/../runs/out_blur_shared.dsraw" --kernel blur3 --impl shared --iters 25 --csv "$CSV"
"$BIN" --op conv2d --mode collapse --in "$ROOT/../runs/in.dsraw" --out "$ROOT/../runs/out_blur_shared.dsraw" --kernel blur3 --impl shared --iters 25 --csv "$CSV"

"$BIN" --op conv2d --mode expand --in "$ROOT/../runs/in.dsraw" --out "$ROOT/../runs/out_blur_global.dsraw" --kernel blur3 --impl global --iters 25 --csv "$CSV"
"$BIN" --op conv2d --mode collapse --in "$ROOT/../runs/in.dsraw" --out "$ROOT/../runs/out_blur_global.dsraw" --kernel blur3 --impl global --iters 25 --csv "$CSV"

python "$ROOT/scripts/dsraw_to_png.py" --in "$ROOT/../runs/out_blur_shared.dsraw" --out "$ROOT/../runs/out_blur_shared.png"
python "$ROOT/scripts/dsraw_to_png.py" --in "$ROOT/../runs/out_blur_global.dsraw" --out "$ROOT/../runs/out_blur_global.png"

python "$ROOT/scripts/make_report.py" --csv "$CSV" --out "$ROOT/../runs/utb_bench_report.md"
echo "Done. See runs/utb_bench_report.md"
