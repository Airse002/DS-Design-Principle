#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
mkdir -p "$ROOT/../runs"
BIN="$ROOT/build/dlink_cuda_primitives"

echo "== Prepare: PNG -> DSRAW ==" 
python "$ROOT/scripts/png_to_dsraw.py" --in "$ROOT/data/sample_real.png" --out "$ROOT/../runs/in.dsraw"


echo "== VecAdd (DS expand -> choose best block) =="
"$BIN" --op vecadd --mode expand --n 8000000 --iters 50 --csv "$ROOT/../runs/primitives_timing.csv"
"$BIN" --op vecadd --mode collapse --n 8000000 --iters 50 --csv "$ROOT/../runs/primitives_timing.csv"

echo "== MatMul (global mem baseline) =="
"$BIN" --op matmul --mode expand --N 512 --iters 5 --csv "$ROOT/../runs/primitives_timing.csv"
"$BIN" --op matmul --mode collapse --N 512 --iters 5 --csv "$ROOT/../runs/primitives_timing.csv"

echo "== Conv2D RGB (shared mem) =="
"$BIN" --op conv2d --mode expand --in "$ROOT/../runs/in.dsraw" --out "$ROOT/../runs/out_blur_shared.dsraw" --impl shared --kernel blur3 --iters 20 --csv "$ROOT/../runs/primitives_timing.csv"
"$BIN" --op conv2d --mode collapse --in "$ROOT/../runs/in.dsraw" --out "$ROOT/../runs/out_edge_global.dsraw" --impl global --kernel edge3 --iters 20 --csv "$ROOT/../runs/primitives_timing.csv"

echo "Wrote timing CSV: runs/primitives_timing.csv"
echo "Wrote images: runs/out_blur.png runs/out_edge.png"


echo "== Convert outputs back to PNG ==" 
python "$ROOT/scripts/dsraw_to_png.py" --in "$ROOT/../runs/out_blur_shared.dsraw" --out "$ROOT/../runs/out_blur_shared.png"
python "$ROOT/scripts/dsraw_to_png.py" --in "$ROOT/../runs/out_edge_global.dsraw" --out "$ROOT/../runs/out_edge_global.png"
