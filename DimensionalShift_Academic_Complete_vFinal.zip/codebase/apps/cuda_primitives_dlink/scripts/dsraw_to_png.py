#!/usr/bin/env python3
from pathlib import Path
from PIL import Image
import argparse

def main():
    ap = argparse.ArgumentParser(description="Convert DSRAW container back to PNG (RGBA8).")
    ap.add_argument("--in", dest="inp", required=True)
    ap.add_argument("--out", dest="out", required=True)
    args = ap.parse_args()

    p = Path(args.inp)
    b = p.read_bytes()
    if len(b) < 13 or b[:5] != b"DSRAW":
        raise SystemExit("Not a DSRAW file")
    w = int.from_bytes(b[5:9], "little")
    h = int.from_bytes(b[9:13], "little")
    px = b[13:13+4*w*h]
    if len(px) != 4*w*h:
        raise SystemExit("Corrupt DSRAW payload")
    img = Image.frombytes("RGBA", (w,h), px)
    outp = Path(args.out)
    outp.parent.mkdir(parents=True, exist_ok=True)
    img.save(outp)
    print(f"Wrote PNG: {outp} ({w}x{h})")

if __name__ == "__main__":
    main()
