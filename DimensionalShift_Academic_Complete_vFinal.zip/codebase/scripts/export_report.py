import os
from pathlib import Path
import datetime

RUNS = Path("runs")
RUNS.mkdir(parents=True, exist_ok=True)

artifacts = [
    "utb_bench.csv",
    "utb_bench_report.md",
    "utb_bench_plot_ms.png",
    "utb_conv_speedup.png",
    "out_blur_shared.png",
    "out_blur_global.png",
    "ds_dynamic_polygon.png",
    "ds_vs_baselines_rmse.png",
    "ds_vs_baselines_time.png",
    "ds_cpu_vs_platform.png",
    "dlink_scaling.csv",
    "dlink_scaling_insight_s.png",
    "dlink_scaling_topk_s.png",
]

lines = []
lines.append("# Project D-Link — EXPORT REPORT")
lines.append("")
lines.append(f"Generated: {datetime.datetime.now().isoformat(timespec='seconds')}")
lines.append("")
lines.append("## Environment")
lines.append(f"- DLINK_PLATFORM={os.getenv('DLINK_PLATFORM','')}")
lines.append(f"- DSHIFT_ACCEL_BACKEND={os.getenv('DSHIFT_ACCEL_BACKEND','')}")
lines.append("")
lines.append("## Artifacts found in runs/")
found = 0
for a in artifacts:
    p = RUNS / a
    if p.exists():
        found += 1
        lines.append(f"- ✅ `{a}` ({p.stat().st_size} bytes)")
    else:
        lines.append(f"- ⛔ `{a}` (missing)")
lines.append("")
lines.append("## Interpretation guide")
lines.append("- `utb_conv_speedup.png`: compare conv2d global vs shared; shared should typically be faster.")
lines.append("- `utb_bench_report.md`: explains DS pulse (expand/collapse) and why shared memory helps.")
lines.append("- `ds_dynamic_polygon.png`: shows 10D parameter state evolving across cycles (DS as organism).")
lines.append("- `dlink_scaling_*`: shows role scaling with dimensions; CUDA should help if CuPy is active.")
lines.append("")
lines.append("## Notes on 'DS is faster'")
lines.append("- DS is an architecture: it can be faster *by selecting faster configurations* and pruning dimensions.")
lines.append("- EXPAND adds overhead, but COLLAPSE uses the best policy/config afterward.")
lines.append("- For conv2d specifically, shared-memory tiling is a known performance improvement over global baseline.")
lines.append("")

out = RUNS/"EXPORT_REPORT.md"
out.write_text("\n".join(lines), encoding="utf-8")
print("Wrote", out)
