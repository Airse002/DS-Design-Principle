#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RUNS="$ROOT/runs"
mkdir -p "$RUNS"

echo "=== Project D-Link EXPORT (Tesla-ready) ==="
echo "Repo: $ROOT"
echo "Runs: $RUNS"

# Detect tools
has_nvcc=0
if command -v nvcc >/dev/null 2>&1; then has_nvcc=1; fi

has_cupy=0
python - <<'PY' >/dev/null 2>&1 && has_cupy=1 || has_cupy=0
import os
try:
    import cupy as cp
    _ = cp.cuda.runtime.getDeviceCount()
    print("cupy-ok")
except Exception as e:
    raise SystemExit(1)
PY

# Detect platform preference
PLAT="${DLINK_PLATFORM:-cpu}"
ACC="${DSHIFT_ACCEL_BACKEND:-cpu}"

echo "Detected: nvcc=$has_nvcc cupy=$has_cupy"
echo "Env: DLINK_PLATFORM=${PLAT} DSHIFT_ACCEL_BACKEND=${ACC}"

# 1) UTB CUDA primitives (build+bench)
if [[ $has_nvcc -eq 1 ]]; then
  echo ""
  echo "=== [1/3] UTB CUDA primitives benchmark suite ==="
  pushd "$ROOT/apps/cuda_primitives_dlink" >/dev/null
  bash scripts/build.sh
  bash scripts/benchmark_suite.sh
  popd >/dev/null
else
  echo ""
  echo "=== [1/3] UTB CUDA primitives benchmark suite ==="
  echo "SKIP: nvcc not found on this system."
fi

# 2) DS dynamic 10D optimizer demo (polygon/radar)
echo ""
echo "=== [2/3] DS dynamic 10D demo (polygon/radar) ==="
export PYTHONPATH="$ROOT"
python "$ROOT/examples/demo_ds_dynamic_10d_gpu_vs_baselines.py" || true

# 3) D-Link scaling benchmark (10k..1M dims)
echo ""
echo "=== [3/3] D-Link scaling benchmark (dimensions) ==="
# If cupy exists and user wants cuda, encourage cuda
if [[ $has_cupy -eq 1 ]]; then
  export DLINK_PLATFORM="${DLINK_PLATFORM:-cuda}"
  export DSHIFT_ACCEL_BACKEND="${DSHIFT_ACCEL_BACKEND:-cuda}"
fi
python "$ROOT/examples/benchmark_dlink_scaling.py" || true

# Summarize outputs
echo ""
echo "=== EXPORT COMPLETE ==="
python "$ROOT/scripts/export_report.py"
echo ""
echo "Key entrypoint:"
echo " - Project D-Link/00_INDEX.md"
