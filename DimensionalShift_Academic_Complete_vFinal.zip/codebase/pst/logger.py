from __future__ import annotations
from pathlib import Path
from typing import Iterator
from .dimension_bus import BusPacket

class PacketLogger:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, pkt: BusPacket):
        with self.path.open('a', encoding='utf-8') as f:
            f.write(pkt.to_json() + '\n')

    def replay(self) -> Iterator[BusPacket]:
        with self.path.open('r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if line:
                    yield BusPacket.from_json(line)
