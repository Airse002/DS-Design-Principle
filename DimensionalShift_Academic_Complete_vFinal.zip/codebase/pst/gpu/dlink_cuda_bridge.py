from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Optional, Dict, Any
import numpy as np

from ..dimension_bus import BusPacket
from ..kinds import K_INSIGHT, K_CFG
from ..qpu.dlink_qpu import QPUContext

# Prefer importing the standalone CUDA app package if present on PYTHONPATH.
# The project examples insert dlink_cuda_app/ into sys.path so this resolves as `dlink_cuda`.
try:
    from dlink_cuda.cuda_sampler import CudaRoleSampler  # type: ignore
except Exception:
    # Minimal CPU fallback that matches the expected interface.
    @dataclass
    class CudaRoleSampler:
        def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]:
            rng = np.random.default_rng(seed)
            kind = problem.get("kind", "unknown")
            if kind == "insight_eval":
                dim_ids = list(problem.get("dim_ids", []))
                base = np.array(problem.get("base_scores", [0.0]*len(dim_ids)), dtype=float)
                noise_std = float(problem.get("noise_std", 0.05))
                noise = rng.normal(0.0, noise_std, size=len(dim_ids))
                return {"dim_ids": dim_ids, "scores": (base + noise).tolist(), "kind": "insight_eval"}
            if kind == "topk_subset":
                dim_ids = list(problem.get("dim_ids", []))
                weights = np.array(problem.get("weights", [1.0]*len(dim_ids)), dtype=float)
                K = int(problem.get("K", 8))
                if len(dim_ids) == 0:
                    return {"selected": [], "kind": "topk_subset"}
                K = max(1, min(K, len(dim_ids)))
                idx = np.argpartition(weights, -K)[-K:]
                idx = idx[np.argsort(weights[idx])][::-1]
                return {"selected": idx.astype(int).tolist(), "kind": "topk_subset"}
            if kind == "gate_opt":
                Te0 = int(problem.get("Te", 600))
                Tc0 = int(problem.get("Tc", 400))
                C = int(problem.get("candidates", max(64, shots)))
                dTe = rng.integers(-120, 121, size=C)
                dTc = rng.integers(-120, 121, size=C)
                Te = np.clip(Te0 + dTe, 50, 1200).astype(float)
                Tc = np.clip(Tc0 + dTc, 50, 1200).astype(float)
                progress = float(problem.get("progress", 0.0))
                pain = float(problem.get("pain", 0.0))
                alpha = float(problem.get("alpha", 1.0))
                ratio = Te / (Te + Tc + 1e-12)
                J = progress*ratio - alpha*pain*(1.0-ratio) - 0.02*np.abs(ratio-0.6)
                best = int(np.argmax(J)) if J.size else 0
                return {"Te": int(Te[best]), "Tc": int(Tc[best]), "objective": float(J[best]) if J.size else 0.0, "kind": "gate_opt"}
            return {"error": "unknown kind", "kind": kind}

@dataclass
class DLinkCudaBridge:
    """GPU co-processor bridge for Dimensional Shift roles.

    Produces standard bus packets:
    - insight (K_INSIGHT)
    - cfg intents (K_CFG) with trace.source='cuda_policy'
    """
    sampler: CudaRoleSampler = field(default_factory=CudaRoleSampler)
    K: int = 8

    def insight_packets(self, ctx: QPUContext, dim_ids: List[int], base_scores: Optional[List[float]] = None) -> List[BusPacket]:
        base = base_scores if base_scores is not None else [0.0]*len(dim_ids)
        res = self.sampler.sample({"kind":"insight_eval","dim_ids":dim_ids,"base_scores":base,"noise_std":0.05},
                                  shots=256, seed=ctx.seed)
        out: List[BusPacket] = []
        for d, s in zip(res.get("dim_ids", []), res.get("scores", [])):
            out.append(BusPacket(time_ns=ctx.time_ns, clock_domain=ctx.clock_domain, dim_id=int(d),
                                 kind=K_INSIGHT, phase=ctx.phase, cfg_id=ctx.cfg_id,
                                 payload=float(s)))
        return out

    def topk_kill_cfg(self, ctx: QPUContext, dim_ids: List[int], weights: List[float], min_lanes: int = 4) -> List[BusPacket]:
        res = self.sampler.sample({"kind":"topk_subset","dim_ids":dim_ids,"weights":weights,"K":int(self.K)},
                                  shots=256, seed=ctx.seed)
        selected_idx = [int(i) for i in res.get("selected", [])]
        keep = [dim_ids[i] for i in selected_idx if 0 <= i < len(dim_ids)]
        keep_set = set(keep)
        kill = [d for d in dim_ids if d not in keep_set]
        # enforce min lanes
        if len(dim_ids) - len(kill) < min_lanes:
            kill = kill[:max(0, len(dim_ids) - min_lanes)]
        out: List[BusPacket] = []
        for d in kill:
            out.append(BusPacket(time_ns=ctx.time_ns, clock_domain=ctx.clock_domain, dim_id=900000020,
                                 kind=K_CFG, phase=ctx.phase, cfg_id=ctx.cfg_id,
                                 payload={"cmd":"KILL_DIM","dim_id":int(d),
                                          "trace":{"source":"cuda_policy","action":"KILL_DIM"}}))
        return out

    def breath_cfg(self, ctx: QPUContext, Te: int, Tc: int, progress: float, pain: float) -> BusPacket:
        res = self.sampler.sample({"kind":"gate_opt","Te":Te,"Tc":Tc,"progress":progress,"pain":pain,"alpha":1.0,"candidates":256},
                                  shots=256, seed=ctx.seed)
        return BusPacket(time_ns=ctx.time_ns, clock_domain=ctx.clock_domain, dim_id=900000021,
                         kind=K_CFG, phase=ctx.phase, cfg_id=ctx.cfg_id,
                         payload={"cmd":"SET_BREATH","Te":int(res.get("Te", Te)),"Tc":int(res.get("Tc", Tc)),
                                  "trace":{"source":"cuda_policy","action":"SET_BREATH"}})
