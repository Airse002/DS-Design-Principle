"""GPU acceleration backends (optional)."""
