from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from typing import List, Tuple
import re

@dataclass
class TeacherDemoArtifacts:
    root: Path = Path("runs")
    error_vs_lanes_png: Path = Path("runs/teacher_demo_error_vs_lanes.png")
    dr_topk_png: Path = Path("runs/teacher_demo_dr_topk.png")
    benchmark_png: Path = Path("runs/teacher_demo_benchmark.png")
    report_md: Path = Path("runs/teacher_demo_report.md")
    report_pdf: Path = Path("runs/teacher_demo_report.pdf")

def _read_md_numbers(md_text: str) -> Tuple[List[int], List[float], List[float], List[float], int, int, str]:
    lanes: List[int] = []
    rmse: List[float] = []
    cpu: List[float] = []
    plat: List[float] = []
    K = 0
    total = 0
    platform = "cpu"

    m = re.search(r"Platform selected:\s*\*\*(.+?)\*\*", md_text)
    if m:
        platform = m.group(1).strip()

    m = re.search(r"DE lanes list:\s*\[(.*?)\]", md_text, re.S)
    if m:
        lanes = [int(x.strip()) for x in m.group(1).split(",") if x.strip()]

    m = re.search(r"DE RMSE:\s*\[(.*?)\]", md_text, re.S)
    if m:
        rmse = [float(x.strip()) for x in m.group(1).split(",") if x.strip()]

    ms = re.findall(r"Benchmark (.+?) \(s\):\s*\[(.*?)\]", md_text, re.S)
    if ms:
        cpu = [float(x.strip()) for x in ms[0][1].split(",") if x.strip()]
        platform = ms[-1][0].strip()
        plat = [float(x.strip()) for x in ms[-1][1].split(",") if x.strip()]

    m = re.search(r"Top-K kept:\s*(\d+)\s*/\s*(\d+)", md_text)
    if m:
        K = int(m.group(1)); total = int(m.group(2))

    return lanes, rmse, cpu, plat, K, total, platform

def export_teacher_demo_pdf(art: TeacherDemoArtifacts, title: str = "Dimensional Shift (DS) — Teacher Demo") -> Path:
    from reportlab.lib.pagesizes import letter
    from reportlab.pdfgen import canvas
    from reportlab.lib.units import inch

    art.root.mkdir(parents=True, exist_ok=True)
    md_text = art.report_md.read_text(encoding="utf-8") if art.report_md.exists() else ""
    lanes, rmse, cpu_t, plat_t, K, total, platform = _read_md_numbers(md_text)

    c = canvas.Canvas(str(art.report_pdf), pagesize=letter)
    W, H = letter

    def header(page_title: str):
        c.setFont("Helvetica-Bold", 16)
        c.drawString(0.75*inch, H-0.9*inch, page_title)
        c.setFont("Helvetica", 10)
        c.drawString(0.75*inch, H-1.15*inch, f"Platform: {platform}")

    header(title)
    y = H - 1.6*inch
    c.setFont("Helvetica", 12)
    lines = [
        "What you are seeing:",
        "• DE (Dimensional Expansion): increase number of lanes (dimensions) to represent a signal with more projections.",
        "• DR (Dimensional Reduction / Dim-plosion): select Top-K lanes and drop the rest (policy-driven compression).",
        "• Breath (Te/Tc): heartbeat-like cycle controlling expand vs collision phases.",
        "",
        "Why GPU/CUDA matters:",
        "• The role computations (insight/top-k/breath-opt) are parallel-friendly → run on Tesla now.",
        "• Same interface stays compatible with future QPU backends (qpu-sim/qpu-engine).",
    ]
    for ln in lines:
        c.drawString(0.85*inch, y, ln)
        y -= 0.23*inch

    y -= 0.1*inch
    c.setFont("Helvetica-Bold", 11)
    c.drawString(0.85*inch, y, "Key numbers:")
    y -= 0.22*inch
    c.setFont("Helvetica", 11)
    if lanes and rmse:
        c.drawString(0.85*inch, y, f"DE lanes tested: {lanes}")
        y -= 0.2*inch
        c.drawString(0.85*inch, y, f"DE RMSE: {['{:.3f}'.format(v) for v in rmse]}")
        y -= 0.2*inch
    if total:
        c.drawString(0.85*inch, y, f"DR Top-K kept: {K}/{total}")
        y -= 0.2*inch
    c.showPage()

    header("DE: Error vs number of lanes")
    if art.error_vs_lanes_png.exists():
        c.drawImage(str(art.error_vs_lanes_png), 0.75*inch, 1.2*inch, width=W-1.5*inch, height=H-2.6*inch, preserveAspectRatio=True, anchor='c')
    else:
        c.setFont("Helvetica", 12); c.drawString(0.75*inch, H-2.0*inch, "Missing plot: teacher_demo_error_vs_lanes.png")
    c.showPage()

    header("DR: Top-K selection (Dim-plosion)")
    if art.dr_topk_png.exists():
        c.drawImage(str(art.dr_topk_png), 0.75*inch, 1.2*inch, width=W-1.5*inch, height=H-2.6*inch, preserveAspectRatio=True, anchor='c')
    else:
        c.setFont("Helvetica", 12); c.drawString(0.75*inch, H-2.0*inch, "Missing plot: teacher_demo_dr_topk.png")
    c.showPage()

    header("Compute: CPU vs selected platform")
    if art.benchmark_png.exists():
        c.drawImage(str(art.benchmark_png), 0.75*inch, 3.0*inch, width=W-1.5*inch, height=H-4.2*inch, preserveAspectRatio=True, anchor='c')
    else:
        c.setFont("Helvetica", 12); c.drawString(0.75*inch, H-2.0*inch, "Missing plot: teacher_demo_benchmark.png")

    c.setFont("Helvetica-Bold", 11)
    c.drawString(0.85*inch, 2.55*inch, "Role timing (seconds):")
    c.setFont("Helvetica", 10)
    roles = ["insight", "topk", "gateopt"]
    y0 = 2.35*inch
    c.drawString(0.85*inch, y0, "role")
    c.drawString(2.2*inch, y0, "cpu")
    c.drawString(3.4*inch, y0, platform)
    y0 -= 0.18*inch
    for i, r in enumerate(roles):
        c.drawString(0.85*inch, y0, r)
        if len(cpu_t) == 3:
            c.drawString(2.2*inch, y0, f"{cpu_t[i]:.6f}")
        if len(plat_t) == 3:
            c.drawString(3.4*inch, y0, f"{plat_t[i]:.6f}")
        y0 -= 0.18*inch

    c.showPage()
    c.save()
    return art.report_pdf
