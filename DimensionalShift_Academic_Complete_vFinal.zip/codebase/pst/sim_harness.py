from __future__ import annotations
import numpy as np
from pathlib import Path
from .dimension_bus import BusPacket
from .logger import PacketLogger
from .controller import ReflexController, BreathPolicy
from .organism_runtime import VoltageSpec, VoltageFeatureExtractor, ChainOrganismNetwork

def simulate_voltage(spec: VoltageSpec, seconds: float = 4.0, mains_hz: float = 60.0, seed: int = 0) -> np.ndarray:
    rng = np.random.default_rng(seed)
    N = int(seconds * spec.fs_hz)
    t = np.arange(N) / spec.fs_hz
    base = 170.0 + 40.0*np.sin(2*np.pi*mains_hz*t)
    v = base + rng.normal(0.0, 1.5, size=N)
    for _ in range(12):
        idx = int(rng.integers(0, max(1, N-200)))
        if rng.random() < 0.5:
            v[idx:idx+80] -= rng.uniform(30, 80)
        else:
            v[idx:idx+40] += rng.uniform(20, 60)
    return np.clip(v, spec.v_min, spec.v_max)

def run_end_to_end(out_log: str = "runs/pst_bus.log", seconds: float = 4.0, fs_hz: float = 10_000.0):
    spec = VoltageSpec(v_min=0.0, v_max=230.0, v_safe_low=90.0, v_safe_high=240.0, fs_hz=fs_hz)
    extractor = VoltageFeatureExtractor(spec)
    breath = BreathPolicy(Te=60, Tc=40)
    reflex = ReflexController(v_safe_low=spec.v_safe_low, v_safe_high=spec.v_safe_high, v_max=spec.v_max)
    net = ChainOrganismNetwork(n_org=12, base_feat_dim=9, seed=1)
    log = PacketLogger(Path(out_log))

    v = simulate_voltage(spec, seconds=seconds, mains_hz=60.0, seed=2)

    for n in range(spec.w_mid):
        extractor.update(float(v[n]))

    t0_ns = 0
    dt_ns = int(1e9 / spec.fs_hz)

    for n in range(spec.w_mid, len(v)-1):
        V = float(v[n])
        extractor.update(V)
        feats, dbg = extractor.base_features()
        pain = extractor.pain()

        phase = +1 if breath.phase(n) == +1 else -1
        if reflex.safe_mode(V):
            phase = -1

        v_next = float(v[n+1])
        v_norm_next = (v_next - spec.v_min) / (spec.v_max - spec.v_min)
        dv_next = (v_next - dbg["v"]) * spec.fs_hz
        target_next = feats.copy()
        target_next[0] = v_norm_next
        target_next[1] = dv_next / 5000.0
        target_next[2] = abs(dv_next) / 5000.0

        net.step(feats, target_next, breath=breath, pain=pain, extractor=extractor)

        time_ns = t0_ns + (n * dt_ns)
        for i, val in enumerate(feats):
            log.append(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=i, kind="feature", phase=phase, cfg_id="cfg-demo", payload=float(val)))
        log.append(BusPacket(time_ns=time_ns, clock_domain="host0", dim_id=10_000, kind="pain", phase=phase, cfg_id="cfg-demo", payload=float(pain)))

    return out_log

if __name__ == "__main__":
    print("Wrote log:", run_end_to_end())
