from __future__ import annotations
from dataclasses import dataclass
from typing import Optional

@dataclass
class ReflexController:
    v_safe_low: float = 90.0
    v_safe_high: float = 240.0
    v_max: float = 230.0
    pain_hi: float = 0.02

    def pain(self, v: float) -> float:
        below = max(0.0, self.v_safe_low - v)
        above = max(0.0, v - self.v_safe_high)
        return float((below*below + above*above) / (self.v_max**2))

    def safe_mode(self, v: float) -> bool:
        return self.pain(v) > self.pain_hi

@dataclass
class BreathPolicy:
    Te: int = 60
    Tc: int = 40
    Te_min: int = 5
    Tc_min: int = 5
    Te_max: int = 200
    Tc_max: int = 200

    def phase(self, t: int) -> int:
        P = self.Te + self.Tc
        return +1 if (t % P) < self.Te else -1

    def adapt(self, pain: float, learning_progress: float):
        if pain > 0.02:
            self.Tc = min(self.Tc_max, self.Tc + 1)
            self.Te = max(self.Te_min, self.Te - 1)
        else:
            if learning_progress > 0.0:
                self.Te = min(self.Te_max, self.Te + 1)
                self.Tc = max(self.Tc_min, self.Tc - 1)
