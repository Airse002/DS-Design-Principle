from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Dict

from .backends.digital_backend import Dimension, Breath

@dataclass
class WindowSpec:
    fs_hz: float
    dt_ns: int
    win_N: int = 256
    kernel_L: int = 16

def gate_open(dim: Dimension, n: int) -> bool:
    P = max(int(dim.P), 1)
    on_len = int(np.floor(float(dim.d) * P))
    return ((n + int(dim.delta)) % P) < on_len

def build_measurements_for_window(dims: List[Dimension], breath: Breath, bits: Dict[Tuple[int,int], int],
                                  n0: int, spec: WindowSpec):
    N, L = spec.win_N, spec.kernel_L
    rows, signs, ths = [], [], []
    for n in range(n0, n0 + N):
        phi = breath.phase(n)
        for dim in dims:
            if not gate_open(dim, n):
                continue
            key = (n, int(dim.dim_id))
            if key not in bits:
                continue
            b = int(bits[key])
            k = dim.k_plus if phi == +1 else dim.k_minus
            k = np.asarray(k, dtype=float)
            if k.size != L:
                k = k[:L] if k.size > L else np.pad(k, (0, L-k.size))
            a = np.zeros(N, dtype=float)
            for m in range(L):
                j = (n - m) - n0
                if 0 <= j < N:
                    a[j] += float(k[m])
            rows.append(a)
            signs.append(2*b - 1)
            ths.append(float(dim.theta))
    if not rows:
        return np.zeros((0, N)), np.zeros((0,)), np.zeros((0,))
    return np.vstack(rows), np.array(signs, dtype=float), np.array(ths, dtype=float)
