"""CAN-FD Adapter (concept)

Good for:
- config/control packets (small, reliable)
- low-rate telemetry dimensions

Not recommended for high-rate waveform transport.
Interface stub.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from ..dimension_bus import BusPacket
from ..transport import Transport

@dataclass
class CANFDInfo:
    channel: str = "can0"
    bitrate: int = 500000
    data_bitrate: int = 2000000

class CANFDTransport(Transport):
    def __init__(self, info: CANFDInfo):
        self.info = info

    def send(self, pkt: BusPacket) -> None:
        raise NotImplementedError

    def recv(self) -> Iterable[BusPacket]:
        raise NotImplementedError
