"""PCIe DMA Adapter (concept)

Maps BusPackets to/from DMA ring buffers.
Production implementation details:
- fixed-size headers + variable payload blocks
- per-dimension queues for QoS
- hardware timestamping at capture

This file is intentionally an interface stub.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from ..dimension_bus import BusPacket
from ..transport import Transport

@dataclass
class PCIeDMAInfo:
    device_id: str
    bar: int = 0
    rx_rings: int = 4
    tx_rings: int = 2

class PCIeDMATransport(Transport):
    def __init__(self, info: PCIeDMAInfo):
        self.info = info

    def send(self, pkt: BusPacket) -> None:
        raise NotImplementedError

    def recv(self) -> Iterable[BusPacket]:
        raise NotImplementedError
