"""TSN/EtherCAT Adapter (concept)

Maps BusPackets to deterministic Ethernet frames.
Production implementation details:
- scheduled traffic classes
- bounded latency for control plane
- time sync (PTP) mapping clock_domain to global time

Interface stub.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from ..dimension_bus import BusPacket
from ..transport import Transport

@dataclass
class TSNInfo:
    iface: str
    clock_domain: str = "tsn0"
    vlan: int = 0

class TSNTransport(Transport):
    def __init__(self, info: TSNInfo):
        self.info = info

    def send(self, pkt: BusPacket) -> None:
        raise NotImplementedError

    def recv(self) -> Iterable[BusPacket]:
        raise NotImplementedError
