from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, Optional
import json

@dataclass
class BusPacket:
    time_ns: int
    clock_domain: str
    dim_id: int
    kind: str
    phase: int
    cfg_id: str
    payload: Any = None
    seq: Optional[int] = None
    quality: Optional[Dict[str, Any]] = None

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        return {k: v for k, v in d.items() if v is not None}

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(',', ':'))

    @staticmethod
    def from_json(s: str) -> 'BusPacket':
        return BusPacket(**json.loads(s))
