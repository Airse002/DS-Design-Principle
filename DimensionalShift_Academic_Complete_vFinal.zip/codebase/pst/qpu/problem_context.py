from __future__ import annotations
from typing import Dict, Any
from .dlink_qpu import QPUContext

def with_ctx(problem: Dict[str, Any], ctx: QPUContext) -> Dict[str, Any]:
    """Attach bus context to the problem descriptor for logging/replay."""
    p = dict(problem)
    p["cfg_id"] = ctx.cfg_id
    p["phase"] = int(ctx.phase)
    p["time_ns"] = int(ctx.time_ns)
    p["clock_domain"] = str(ctx.clock_domain)
    return p
