from __future__ import annotations
from typing import Dict, Any, Optional
from ..dimension_bus import BusPacket
from ..kinds import K_QPU_JOB_SUB, K_QPU_JOB_RES

def make_job_submitted(*, time_ns: int, clock_domain: str, cfg_id: str, phase: int, job_id: str,
                       backend: str, shots: int, seed: Optional[int], problem: Dict[str, Any],
                       circuit_hash: Optional[str] = None) -> BusPacket:
    return BusPacket(
        time_ns=int(time_ns),
        clock_domain=str(clock_domain),
        dim_id=900000010,
        kind=K_QPU_JOB_SUB,
        phase=int(phase),
        cfg_id=str(cfg_id),
        payload={
            "job_id": str(job_id),
            "backend": str(backend),
            "shots": int(shots),
            "seed": seed,
            "problem": problem,
            "circuit_hash": circuit_hash,
        },
    )

def make_job_result(*, time_ns: int, clock_domain: str, cfg_id: str, phase: int, job_id: str,
                    result: Optional[Dict[str, Any]] = None, error: Optional[str] = None) -> BusPacket:
    return BusPacket(
        time_ns=int(time_ns),
        clock_domain=str(clock_domain),
        dim_id=900000011,
        kind=K_QPU_JOB_RES,
        phase=int(phase),
        cfg_id=str(cfg_id),
        payload={
            "job_id": str(job_id),
            "result": result,
            "error": error,
        },
    )
