from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, List, Optional, Protocol, Tuple
import numpy as np

from ..dimension_bus import BusPacket
from ..kinds import K_INSIGHT

class QPUSampler(Protocol):
    """Abstract sampler that returns bitstrings or samples for a given problem descriptor."""
    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]: ...

@dataclass
class QPUContext:
    time_ns: int
    clock_domain: str
    cfg_id: str
    phase: int  # +1 expand, -1 collision
    seed: int = 0

"""Problem descriptors
We keep descriptors JSON-friendly so they can be logged and replayed.
"""
