from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional, Callable

from .job_schema import QPUJobRecord, QPUJobLogger, utc_now
from .job_packets import make_job_submitted, make_job_result
from .dlink_qpu import QPUSampler

@dataclass
class LoggingSampler:
    """Wraps any sampler and logs QPUJobRecord JSONL for every call."""
    backend_name: str
    inner: QPUSampler
    log_path: str = "runs/qpu_jobs.log"
    emit_fn: Optional[Callable[[Any], None]] = None  # expects BusPacket

    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]:
        job_id = QPUJobRecord.new_id()
        rec = QPUJobRecord(
            job_id=job_id,
            ts_utc=utc_now(),
            backend=str(self.backend_name),
            mode="call",
            cfg_id=str(problem.get("cfg_id", "unknown")),
            phase=int(problem.get("phase", 0) or 0),
            clock_domain=str(problem.get("clock_domain", "host0")),
            time_ns=int(problem.get("time_ns", 0) or 0),
            problem=dict(problem),
            shots=int(shots),
            seed=seed,
            circuit_text=None,
            circuit_hash=problem.get("circuit_hash"),
            result=None,
            error=None,
        )
        logger = QPUJobLogger(self.log_path)
        # submitted
        logger.append(rec)
        if self.emit_fn is not None:
            self.emit_fn(make_job_submitted(time_ns=rec.time_ns, clock_domain=rec.clock_domain, cfg_id=rec.cfg_id,
                                           phase=rec.phase, job_id=rec.job_id, backend=rec.backend,
                                           shots=rec.shots, seed=rec.seed, problem=rec.problem,
                                           circuit_hash=rec.circuit_hash))
        try:
            out = self.inner.sample(problem, shots=shots, seed=seed)
            rec.mode = "result"
            rec.result = out
            logger.append(rec)
            if self.emit_fn is not None:
                self.emit_fn(make_job_result(time_ns=rec.time_ns, clock_domain=rec.clock_domain, cfg_id=rec.cfg_id,
                                            phase=rec.phase, job_id=rec.job_id, result=out, error=None))
            return out
        except Exception as e:
            rec.mode = "error"
            rec.error = str(e)
            logger.append(rec)
            if self.emit_fn is not None:
                self.emit_fn(make_job_result(time_ns=rec.time_ns, clock_domain=rec.clock_domain, cfg_id=rec.cfg_id,
                                            phase=rec.phase, job_id=rec.job_id, result=None, error=str(e)))
            raise
