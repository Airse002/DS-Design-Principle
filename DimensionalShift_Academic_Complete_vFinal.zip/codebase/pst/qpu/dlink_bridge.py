from __future__ import annotations
from dataclasses import dataclass, field
from typing import List, Dict, Any, Optional

from .dlink_qpu import QPUSampler, QPUContext
from .backend_select import select_sampler
from .sim_backend import SimulatorSampler
from .roles.topk_selector import TopKSelector
from .roles.gate_optimizer import GateOptimizer
from .roles.insight_evaluator import InsightEvaluator

from ..dimension_bus import BusPacket
from ..kinds import K_CFG, K_INSIGHT

@dataclass
class DLinkQuantumBridge:
    """Unified Quantum Bridge exposing all 3 roles.
    Default backend is SimulatorSampler; swap in CirqSampler if available.
    """
    sampler: QPUSampler = field(default_factory=select_sampler)
    topk: TopKSelector = field(default_factory=lambda: TopKSelector(K=8, shots=256))
    gateopt: GateOptimizer = field(default_factory=lambda: GateOptimizer(shots=256, alpha=1.0))
    insight: InsightEvaluator = field(default_factory=lambda: InsightEvaluator(shots=256, noise_std=0.05))

    def run_insight(self, ctx: QPUContext, dim_ids: List[int], base_scores: Optional[List[float]] = None) -> List[BusPacket]:
        scores = self.insight.evaluate(self.sampler, ctx, dim_ids, base_scores=base_scores)
        return self.insight.as_insight_packets(ctx, dim_ids, scores)

    def run_topk(self, ctx: QPUContext, dim_ids: List[int], weights: Optional[List[float]] = None) -> List[int]:
        return self.topk.select(self.sampler, ctx, dim_ids, weights=weights)

    def run_topk_as_cfg(self, ctx: QPUContext, selected: List[int], all_dim_ids: List[int]) -> List[BusPacket]:
        return self.topk.as_cfg_intents(ctx, selected, all_dim_ids)

    def run_gateopt(self, ctx: QPUContext, Te: int, Tc: int, progress: float, pain: float) -> BusPacket:
        Te2, Tc2, _ = self.gateopt.optimize_breath(self.sampler, ctx, Te, Tc, progress=progress, pain=pain)
        return self.gateopt.as_cfg_intent(ctx, Te2, Tc2)
