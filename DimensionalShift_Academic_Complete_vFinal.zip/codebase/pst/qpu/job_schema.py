from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Dict, Any, Optional
from pathlib import Path
import json, time, hashlib, uuid

def utc_now() -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8')).hexdigest()

@dataclass
class QPUJobRecord:
    """Standardized job record for logging + replay.

    This record is backend-agnostic; it can represent:
    - simulator runs
    - cirq simulator runs
    - engine runs (when available)

    All fields are JSON-serializable.
    """
    job_id: str
    ts_utc: str
    backend: str                    # sim|cirq|engine
    mode: str                       # simulator|engine|engine_attempted|...
    cfg_id: str
    phase: int
    clock_domain: str
    time_ns: int
    problem: Dict[str, Any]
    shots: int
    seed: Optional[int]
    circuit_text: Optional[str] = None
    circuit_hash: Optional[str] = None
    result: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

    @staticmethod
    def new_id() -> str:
        return str(uuid.uuid4())

    @staticmethod
    def from_dict(d: Dict[str, Any]) -> "QPUJobRecord":
        return QPUJobRecord(**d)

class QPUJobLogger:
    """JSONL logger for QPUJobRecord."""
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def append(self, rec: QPUJobRecord) -> None:
        with self.path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec.to_dict()) + "\n")

    def replay(self):
        if not self.path.exists():
            return
        with self.path.open("r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                yield QPUJobRecord.from_dict(json.loads(line))
