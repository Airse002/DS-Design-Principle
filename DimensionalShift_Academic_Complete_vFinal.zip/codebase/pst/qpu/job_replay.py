from __future__ import annotations
from dataclasses import dataclass
from typing import Iterator, Optional
from pathlib import Path

from ..dimension_bus import BusPacket
from ..kinds import K_QPU_JOB_SUB, K_QPU_JOB_RES
from .job_schema import QPUJobLogger, QPUJobRecord

@dataclass
class QPUJobReplayer:
    log_path: Path

    def packets(self) -> Iterator[BusPacket]:
        logger = QPUJobLogger(self.log_path)
        for rec in logger.replay():
            # submitted packet
            yield BusPacket(
                time_ns=int(rec.time_ns),
                clock_domain=str(rec.clock_domain),
                dim_id=900000010,
                kind=K_QPU_JOB_SUB,
                phase=int(rec.phase),
                cfg_id=str(rec.cfg_id),
                payload={
                    "job_id": rec.job_id,
                    "backend": rec.backend,
                    "mode": rec.mode,
                    "shots": rec.shots,
                    "seed": rec.seed,
                    "problem": rec.problem,
                    "circuit_hash": rec.circuit_hash,
                },
            )
            # result packet
            yield BusPacket(
                time_ns=int(rec.time_ns),
                clock_domain=str(rec.clock_domain),
                dim_id=900000011,
                kind=K_QPU_JOB_RES,
                phase=int(rec.phase),
                cfg_id=str(rec.cfg_id),
                payload={
                    "job_id": rec.job_id,
                    "result": rec.result,
                    "error": rec.error,
                },
            )
