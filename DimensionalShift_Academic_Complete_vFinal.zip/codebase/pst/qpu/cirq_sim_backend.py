from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional
import numpy as np

@dataclass
class CirqSimSampler:
    """Cirq-based sampler for the three D-Link roles (SIMULATOR ONLY).

    Uses state preparation to sample from a desired distribution.
    This is practical for prototyping but NOT directly hardware-realistic
    without more complex amplitude-preparation techniques.

    Requires: `pip install cirq` (or cirq-core).
    """

    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]:
        try:
            import cirq  # type: ignore
        except Exception as e:
            # Fall back to pure python sampler if cirq isn't installed
            from .sim_backend import SimulatorSampler
            return SimulatorSampler().sample(problem, shots=shots, seed=seed)


        rng = np.random.default_rng(seed)
        kind = problem.get("kind", "unknown")

        if kind == "topk_subset":
            dim_ids = problem.get("dim_ids", [])
            weights = np.array(problem.get("weights", []), dtype=float)
            K = int(problem.get("K", 8))
            if weights.size == 0 or len(dim_ids) == 0:
                return {"selected": []}

            # Convert weights to a probability distribution over indices
            w = weights - weights.max()
            p = np.exp(w)
            p = p / (p.sum() + 1e-12)

            n = len(dim_ids)
            # Need qubits for index register size 2^q >= n
            q = int(np.ceil(np.log2(max(1, n))))
            qubits = cirq.LineQubit.range(q)

            # Build state vector of length 2^q with probabilities p on first n states
            vec = np.zeros(2**q, dtype=np.complex128)
            vec[:n] = np.sqrt(p)
            # Random global phase irrelevant; ensure normalized
            vec = vec / (np.linalg.norm(vec) + 1e-12)

            circuit = cirq.Circuit()
            circuit.append(cirq.StatePreparationChannel(vec)(*qubits))
            circuit.append(cirq.measure(*qubits, key="idx"))

            sim = cirq.Simulator(seed=seed)
            result = sim.run(circuit, repetitions=max(1, shots))
            # decode measured integers
            meas = result.data["idx"].to_numpy()
            # each row is bitstring? In cirq, for multiple qubits, column per qubit if key per qubit.
            # With a single key on multiple qubits, cirq returns an array of integers in some versions,
            # else an ndarray of bits. Handle both.
            idxs = []
            try:
                # If it's a scalar int per repetition:
                if meas.ndim == 1:
                    idxs = [int(x) for x in meas.tolist()]
                else:
                    # bits: little-endian by default for LineQubits in measurement ordering
                    for row in meas:
                        val = 0
                        for i, b in enumerate(row[::-1]):
                            val = (val << 1) | int(b)
                        idxs.append(val)
            except Exception:
                # fallback: sample classically
                idxs = rng.choice(n, size=max(1, shots), replace=True, p=p).tolist()

            # Select K unique indices by frequency
            freq = {}
            for i in idxs:
                if 0 <= i < n:
                    freq[i] = freq.get(i, 0) + 1
            # sort by count then weight tie-breaker
            chosen = sorted(freq.items(), key=lambda kv: (kv[1], float(weights[kv[0]])), reverse=True)
            selected = [i for i,_ in chosen[:min(K, len(chosen))]]
            return {"selected": selected}

        if kind == "gate_opt":
            # Sample among candidate (Te,Tc) pairs.
            Te0 = int(problem.get("Te", 600))
            Tc0 = int(problem.get("Tc", 400))
            Te_min, Te_max = int(problem.get("Te_min", 50)), int(problem.get("Te_max", 1200))
            Tc_min, Tc_max = int(problem.get("Tc_min", 50)), int(problem.get("Tc_max", 1200))
            progress = float(problem.get("progress", 0.0))
            pain = float(problem.get("pain", 0.0))
            alpha = float(problem.get("alpha", 1.0))

            # Construct a small candidate set (simulator-friendly)
            C = int(problem.get("candidates", 32))
            cand = []
            scores = []
            for _ in range(C):
                dTe = int(rng.integers(-120, 121))
                dTc = int(rng.integers(-120, 121))
                Te = int(np.clip(Te0 + dTe, Te_min, Te_max))
                Tc = int(np.clip(Tc0 + dTc, Tc_min, Tc_max))
                ratio = Te / max(1, Te+Tc)
                J = progress * ratio - alpha * pain * (1.0 - ratio)
                J -= 0.02 * abs(ratio - 0.6)
                cand.append((Te, Tc))
                scores.append(J)

            s = np.array(scores, dtype=float)
            s = s - s.max()
            p = np.exp(s)
            p = p / (p.sum() + 1e-12)

            q = int(np.ceil(np.log2(max(1, C))))
            qubits = cirq.LineQubit.range(q)
            vec = np.zeros(2**q, dtype=np.complex128)
            vec[:C] = np.sqrt(p)
            vec = vec / (np.linalg.norm(vec) + 1e-12)

            circuit = cirq.Circuit()
            circuit.append(cirq.StatePreparationChannel(vec)(*qubits))
            circuit.append(cirq.measure(*qubits, key="c"))
            sim = cirq.Simulator(seed=seed)
            result = sim.run(circuit, repetitions=max(1, shots))
            meas = result.data["c"].to_numpy()
            ids = []
            if meas.ndim == 1:
                ids = [int(x) for x in meas.tolist()]
            else:
                for row in meas:
                    val = 0
                    for b in row[::-1]:
                        val = (val << 1) | int(b)
                    ids.append(val)

            freq = {}
            for i in ids:
                if 0 <= i < C:
                    freq[i] = freq.get(i, 0) + 1
            best = max(freq.items(), key=lambda kv: kv[1])[0] if freq else int(np.argmax(scores))
            Te, Tc = cand[best]
            return {"Te": int(Te), "Tc": int(Tc), "objective": float(scores[best])}

        if kind == "insight_eval":
            dim_ids = problem.get("dim_ids", [])
            base_scores = np.array(problem.get("base_scores", [0.0]*len(dim_ids)), dtype=float)
            noise_std = float(problem.get("noise_std", 0.05))
            if len(dim_ids) == 0:
                return {"dim_ids": [], "scores": []}

            # Use quantum-like sampling to perturb scores: sample +/- noise signs via qubits
            n = len(dim_ids)
            qubits = cirq.LineQubit.range(n)
            circuit = cirq.Circuit()
            # put each qubit into |+> then measure => random bits
            circuit.append(cirq.H.on_each(*qubits))
            circuit.append(cirq.measure(*qubits, key="b"))
            sim = cirq.Simulator(seed=seed)
            res = sim.run(circuit, repetitions=1)
            bits = res.measurements["b"][0].astype(int).tolist()
            signs = np.array([1.0 if b == 1 else -1.0 for b in bits], dtype=float)
            noise = signs * noise_std
            scores = (base_scores + noise).tolist()
            return {"dim_ids": dim_ids, "scores": scores}

        return {"error": "unknown problem kind", "kind": kind}
