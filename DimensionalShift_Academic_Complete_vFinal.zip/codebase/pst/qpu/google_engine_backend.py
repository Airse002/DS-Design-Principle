from __future__ import annotations
"""Google Quantum Engine backend (SKELETON).

This module is intentionally safe and optional:
- If cirq/cirq_google (cirq-google) isn't installed, it falls back to the pure-python sampler.
- If you do not have Engine access/credentials, it falls back to simulator behavior.

Purpose:
- Provide a *realistic* bridge boundary for a Linux host to submit QPU jobs and receive samples,
  while keeping Dimensional Shift's bus protocol stable.

Env vars:
- DSHIFT_QPU_BACKEND=engine
- DSHIFT_GOOGLE_PROJECT_ID=<your-project>
- DSHIFT_GOOGLE_PROCESSOR_ID=<processor-id>   (e.g., 'rainbow' style name)
- DSHIFT_GOOGLE_GATESET=<optional>
- DSHIFT_GOOGLE_USE_ENGINE=1|0   (default 0 = do not try engine submit; simulator-only)
- DSHIFT_QPU_LOG_PATH=runs/qpu_jobs.log

Design note:
This backend does NOT implement hardware-realistic amplitude preparation for our role problems.
Instead it demonstrates:
- circuit creation
- submission (optional)
- logging of job/circuit metadata
and returns samples using simulator fallback unless you extend it.

You can later implement role-specific circuits that are hardware-compatible.
"""

from dataclasses import dataclass
from typing import Dict, Any, Optional
from pathlib import Path
import json, time, hashlib

from .job_schema import QPUJobRecord, QPUJobLogger, utc_now, sha256_text

def _utc():
    # deprecated: kept for backward compatibility
    return utc_now()

#
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

def _sha256(b: bytes) -> str:
    # deprecated: kept for backward compatibility
    return hashlib.sha256(b).hexdigest()

#
    return hashlib.sha256(b).hexdigest()

@dataclass
class EngineSampler:
    project_id: Optional[str] = None
    processor_id: Optional[str] = None
    use_engine: bool = False
    log_path: Path = Path("runs/qpu_jobs.log")

    @classmethod
    def from_env(cls) -> "EngineSampler":
        import os
        project = os.getenv("DSHIFT_GOOGLE_PROJECT_ID")
        proc = os.getenv("DSHIFT_GOOGLE_PROCESSOR_ID")
        use_engine = os.getenv("DSHIFT_GOOGLE_USE_ENGINE", "0").strip() in ("1","true","TRUE","yes","YES")
        log_path = Path(os.getenv("DSHIFT_QPU_LOG_PATH", "runs/qpu_jobs.log"))
        return cls(project_id=project, processor_id=proc, use_engine=use_engine, log_path=log_path)

    def _log(self, rec: Dict[str, Any]) -> None:
        # legacy log writer

        self.log_path.parent.mkdir(parents=True, exist_ok=True)
        with self.log_path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec) + "\n")

    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]:
        # Lazy optional imports; fall back if missing
        try:
            import cirq  # type: ignore
        except Exception:
            from .sim_backend import SimulatorSampler
            return SimulatorSampler().sample(problem, shots=shots, seed=seed)

        # Build a simple circuit placeholder per kind.
        # (Role-specific circuits should be implemented later for real hardware.)
        kind = problem.get("kind", "unknown")
        q = 4  # small placeholder register
        qubits = cirq.LineQubit.range(q)
        circuit = cirq.Circuit()
        circuit.append(cirq.H.on_each(*qubits))
        circuit.append(cirq.measure(*qubits, key="m"))

        # Serialize for hashing/logging
        circ_txt = str(circuit).encode("utf-8")
        circ_hash = _sha256(circ_txt)

        job_logger = QPUJobLogger(self.log_path)

        rec = {
            "ts_utc": _utc(),
            "backend": "engine",
            "project_id": self.project_id,
            "processor_id": self.processor_id,
            "use_engine": self.use_engine,
            "problem": problem,
            "shots": int(shots),
            "seed": seed,
            "circuit_hash": circ_hash,
        }

        # Default: simulator execution (safe + reproducible)
        try:
            sim = cirq.Simulator(seed=seed)
            result = sim.run(circuit, repetitions=max(1, shots))
            bits = result.measurements["m"]
            # Convert each repetition to integer
            vals = []
            for row in bits:
                v = 0
                for b in row:
                    v = (v << 1) | int(b)
                vals.append(v)
            rec["mode"] = "simulator"
            rec["job_id"] = None
            rec["result_preview"] = vals[:8]

        # Optional: attempt engine submission if user explicitly enables it and has cirq_google installed.
        if self.use_engine:
            try:
                import cirq_google  # type: ignore
                # NOTE: Real engine usage requires auth + correct processor ids.
                # This skeleton demonstrates how it would be wired.
                engine = cirq_google.Engine(project_id=self.project_id) if self.project_id else cirq_google.Engine()
                # The processor_id requirement differs by environment; leave as placeholder.
                # proc = engine.get_processor(self.processor_id) if self.processor_id else None
                # job = engine.run(program=circuit, processor_id=self.processor_id, repetitions=max(1, shots))
                # In a real implementation, parse job results here.
                rec2 = {
                    "ts_utc": _utc(),
                    "backend": "engine",
                    "mode": "engine_submit_attempted",
                    "note": "Skeleton only: fill in engine.run(...) if you have access",
                    "project_id": self.project_id,
                    "processor_id": self.processor_id,
                    "circuit_hash": circ_hash,
                }
                self._log(rec2)
            except Exception as e:
                rec2 = {
                    "ts_utc": _utc(),
                    "backend": "engine",
                    "mode": "engine_submit_failed",
                    "error": str(e),
                    "project_id": self.project_id,
                    "processor_id": self.processor_id,
                    "circuit_hash": circ_hash,
                }
                self._log(rec2)

        # Return role-compatible results via the established simulator-first logic
        from .sim_backend import SimulatorSampler
        return SimulatorSampler().sample(problem, shots=shots, seed=seed)
