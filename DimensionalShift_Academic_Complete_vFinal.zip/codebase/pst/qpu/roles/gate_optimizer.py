from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional, Tuple

from ..dlink_qpu import QPUSampler, QPUContext
from ..problem_context import with_ctx
from ...dimension_bus import BusPacket
from ...kinds import K_CFG

@dataclass
class GateOptimizer:
    """Role 2: optimize breath (Te/Tc) and/or gate parameters."""
    shots: int = 256
    alpha: float = 1.0

    def optimize_breath(self, sampler: QPUSampler, ctx: QPUContext, Te: int, Tc: int, progress: float, pain: float,
                        Te_min: int = 50, Te_max: int = 1200, Tc_min: int = 50, Tc_max: int = 1200) -> Tuple[int,int, float]:
        problem = with_ctx({
            "kind": "gate_opt",
            "Te": int(Te), "Tc": int(Tc),
            "Te_min": int(Te_min), "Te_max": int(Te_max),
            "Tc_min": int(Tc_min), "Tc_max": int(Tc_max),
            "progress": float(progress), "pain": float(pain),
            "alpha": float(self.alpha),
        }, ctx)
        res = sampler.sample(problem, shots=self.shots, seed=ctx.seed)
        return int(res.get("Te", Te)), int(res.get("Tc", Tc)), float(res.get("objective", 0.0))

    def as_cfg_intent(self, ctx: QPUContext, Te: int, Tc: int) -> BusPacket:
        return BusPacket(
            time_ns=ctx.time_ns,
            clock_domain=ctx.clock_domain,
            dim_id=900000006,
            kind=K_CFG,
            phase=ctx.phase,
            cfg_id=ctx.cfg_id,
            payload={"cmd": "SET_BREATH", "Te": int(Te), "Tc": int(Tc)},
        )
