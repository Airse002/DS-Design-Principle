"""QPU roles: top-k, gate optimizer, insight evaluator."""
