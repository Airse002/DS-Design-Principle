from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional

from ..dlink_qpu import QPUSampler, QPUContext
from ..problem_context import with_ctx
from ...dimension_bus import BusPacket
from ...kinds import K_INSIGHT

@dataclass
class InsightEvaluator:
    """Role 3: stochastic insight scoring per dimension."""
    shots: int = 256
    noise_std: float = 0.05

    def evaluate(self, sampler: QPUSampler, ctx: QPUContext, dim_ids: List[int], base_scores: Optional[List[float]] = None) -> List[float]:
        base = base_scores if base_scores is not None else [0.0]*len(dim_ids)
        problem = with_ctx({"kind": "insight_eval", "dim_ids": dim_ids, "base_scores": base, "noise_std": float(self.noise_std)}, ctx)
        res = sampler.sample(problem, shots=self.shots, seed=ctx.seed)
        return [float(x) for x in res.get("scores", [0.0]*len(dim_ids))]

    def as_insight_packets(self, ctx: QPUContext, dim_ids: List[int], scores: List[float]) -> List[BusPacket]:
        out: List[BusPacket] = []
        for d, s in zip(dim_ids, scores):
            out.append(BusPacket(
                time_ns=ctx.time_ns,
                clock_domain=ctx.clock_domain,
                dim_id=int(d),
                kind=K_INSIGHT,
                phase=ctx.phase,
                cfg_id=ctx.cfg_id,
                payload=float(s)
            ))
        return out
