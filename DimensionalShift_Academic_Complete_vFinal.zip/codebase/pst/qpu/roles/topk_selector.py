from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
import numpy as np

from ..dlink_qpu import QPUSampler, QPUContext
from ..problem_context import with_ctx
from ...dimension_bus import BusPacket
from ...kinds import K_CFG

@dataclass
class TopKSelector:
    """Role 1: choose which dimensions survive collision (subset selection)."""
    K: int = 8
    shots: int = 256

    def select(self, sampler: QPUSampler, ctx: QPUContext, dim_ids: List[int], weights: Optional[List[float]] = None) -> List[int]:
        if not dim_ids:
            return []
        w = np.array(weights if weights is not None else [1.0]*len(dim_ids), dtype=float)
        problem = with_ctx({"kind": "topk_subset", "K": int(self.K), "dim_ids": dim_ids, "weights": w.tolist()}, ctx)
        res = sampler.sample(problem, shots=self.shots, seed=ctx.seed)
        idxs = res.get("selected", [])
        idxs = [int(i) for i in idxs if 0 <= int(i) < len(dim_ids)]
        return [int(dim_ids[i]) for i in idxs]

    def as_cfg_intents(self, ctx: QPUContext, selected: List[int], all_dim_ids: List[int]) -> List[BusPacket]:
        """Emit KILL_DIM intents for dims not selected (Dim-plosion in collision)."""
        keep = set(int(x) for x in selected)
        intents: List[BusPacket] = []
        for d in all_dim_ids:
            if int(d) not in keep:
                intents.append(BusPacket(
                    time_ns=ctx.time_ns,
                    clock_domain=ctx.clock_domain,
                    dim_id=900000005,
                    kind=K_CFG,
                    phase=ctx.phase,
                    cfg_id=ctx.cfg_id,
                    payload={"cmd": "KILL_DIM", "dim_id": int(d)},
                ))
        return intents
