"""Quantum co-processor bridge (sim + optional Cirq/Engine)."""

from .job_schema import QPUJobRecord, QPUJobLogger
