"""Optional Cirq / Google Quantum Engine sampler (hook).

This file is written so the repo still runs without cirq installed.
If you have cirq and access credentials, you can implement `CirqSampler.sample` properly.

References (conceptual):
- Use cirq to build circuits
- Use cirq.Simulator or cirq_google.Engine for execution

We intentionally avoid hard dependencies here.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional

@dataclass
class CirqSampler:
    project_id: Optional[str] = None
    processor_id: Optional[str] = None

    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]:
        try:
            import cirq  # type: ignore
        except Exception as e:
            return {"error": "cirq not installed", "detail": str(e), "problem_kind": problem.get("kind")}

        # NOTE: This is a stub. Real implementation depends on your access (simulator vs engine).
        # For now, return an error prompting to use SimulatorSampler unless you extend this.
        return {"error": "CirqSampler not fully implemented in this open-source prototype. Use SimulatorSampler."}
