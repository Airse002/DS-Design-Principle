from __future__ import annotations
import os
from typing import Any

from .sim_backend import SimulatorSampler
from .logging_sampler import LoggingSampler
import os

def select_sampler() -> Any:
    """Select QPU sampler backend and wrap it with always-on job logging.

    Env:
    - DSHIFT_QPU_BACKEND=sim|cirq|engine
    - DSHIFT_QPU_LOG_PATH=runs/qpu_jobs.log
    """
    mode = os.getenv("DSHIFT_QPU_BACKEND", "sim").strip().lower()
    log_path = os.getenv("DSHIFT_QPU_LOG_PATH", "runs/qpu_jobs.log")
    if mode == "engine":
        try:
            from .google_engine_backend import EngineSampler
            inner = EngineSampler.from_env()
            return LoggingSampler(backend_name="engine", inner=inner, log_path=log_path)
        except Exception:
            return LoggingSampler(backend_name="sim", inner=SimulatorSampler(), log_path=log_path)
    if mode == "cirq":
        try:
            from .cirq_sim_backend import CirqSimSampler
            return LoggingSampler(backend_name="cirq", inner=CirqSimSampler(), log_path=log_path)
        except Exception:
            return LoggingSampler(backend_name="sim", inner=SimulatorSampler(), log_path=log_path)
    return LoggingSampler(backend_name="sim", inner=SimulatorSampler(), log_path=log_path)
    if mode == "cirq":
        try:
            from .cirq_sim_backend import CirqSimSampler  # optional
            return CirqSimSampler()
        except Exception:
            return SimulatorSampler()
    return SimulatorSampler()
