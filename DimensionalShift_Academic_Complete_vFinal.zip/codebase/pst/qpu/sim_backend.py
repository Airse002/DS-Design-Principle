from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Any, Optional
import numpy as np

@dataclass
class SimulatorSampler:
    """Fallback 'quantum-like' sampler using stochastic classical sampling.

    This is NOT quantum, but it matches the *interface* and enables development.
    If Cirq/Engine is available, you can swap the sampler.
    """
    def sample(self, problem: Dict[str, Any], shots: int = 256, seed: Optional[int] = None) -> Dict[str, Any]:
        rng = np.random.default_rng(seed)
        kind = problem.get("kind", "unknown")

        if kind == "topk_subset":
            # Sample subset via softmax over weights
            weights = np.array(problem.get("weights", []), dtype=float)
            K = int(problem.get("K", 8))
            if weights.size == 0:
                return {"selected": []}
            # convert to probabilities
            w = weights - weights.max()
            p = np.exp(w)
            p = p / (p.sum() + 1e-12)
            # sample many subsets and pick best by total weight (proxy)
            best = None
            best_score = -1e18
            n = weights.size
            for _ in range(max(8, shots // 8)):
                sel = rng.choice(n, size=min(K, n), replace=False, p=p)
                score = float(weights[sel].sum())
                if score > best_score:
                    best_score, best = score, sel
            return {"selected": best.tolist() if best is not None else []}

        if kind == "gate_opt":
            # Random search over Te/Tc around current
            Te0 = int(problem.get("Te", 600))
            Tc0 = int(problem.get("Tc", 400))
            Te_min, Te_max = int(problem.get("Te_min", 50)), int(problem.get("Te_max", 1200))
            Tc_min, Tc_max = int(problem.get("Tc_min", 50)), int(problem.get("Tc_max", 1200))
            # objective proxy: maximize (progress - alpha*pain) provided as scalars
            progress = float(problem.get("progress", 0.0))
            pain = float(problem.get("pain", 0.0))
            alpha = float(problem.get("alpha", 1.0))
            # We treat lower pain as needing more collision; higher progress allows more expand
            best = (Te0, Tc0)
            bestJ = -1e18
            for _ in range(max(32, shots)):
                dTe = int(rng.integers(-80, 81))
                dTc = int(rng.integers(-80, 81))
                Te = int(np.clip(Te0 + dTe, Te_min, Te_max))
                Tc = int(np.clip(Tc0 + dTc, Tc_min, Tc_max))
                # heuristic objective: progress prefers higher Te, pain prefers higher Tc
                J = progress * (Te / (Te+Tc)) - alpha * pain * (Tc / (Te+Tc))
                # mild regularizer to avoid extreme ratios unless justified
                J -= 0.02 * abs((Te/(Te+Tc)) - 0.6)
                if J > bestJ:
                    bestJ = J
                    best = (Te, Tc)
            return {"Te": best[0], "Tc": best[1], "objective": bestJ}

        if kind == "insight_eval":
            # Produce noisy insight scores from summary stats
            dim_ids = problem.get("dim_ids", [])
            base_scores = np.array(problem.get("base_scores", [0.0]*len(dim_ids)), dtype=float)
            if base_scores.size == 0:
                base_scores = np.zeros(len(dim_ids), dtype=float)
            noise = rng.normal(0.0, float(problem.get("noise_std", 0.05)), size=len(dim_ids))
            scores = (base_scores + noise).tolist()
            return {"dim_ids": dim_ids, "scores": scores}

        return {"error": "unknown problem kind", "kind": kind}
