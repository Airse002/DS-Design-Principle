"""Canonical packet kind strings."""

K_BIT = "projection_1bit"
K_INSIGHT = "insight"
K_EST_WAVE = "estimate_waveform_chunk"
K_ANOMALY = "anomaly"
K_CONTROL = "control"
K_CFG = "cfg"              # cfg intent (SET_BREATH / BIRTH_DIM / KILL_DIM)
K_CFG_APPLIED = "cfg_applied"
K_DIM_BIRTH = "dim_birth"
K_DIM_KILL = "dim_kill"

K_QPU_JOB_SUB = "qpu_job_submitted"
K_QPU_JOB_RES = "qpu_job_result"
