from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional
import numpy as np
from .dimension_bus import BusPacket

@dataclass
class InsightScoreBridge:
    ema_alpha: float = 0.02
    scores: Dict[int, float] = field(default_factory=dict)
    activity_ema: Dict[int, float] = field(default_factory=dict)
    ones_ema: Dict[int, float] = field(default_factory=dict)

    def _ema(self, m: Dict[int,float], dim_id: int, x: float) -> float:
        prev = m.get(dim_id, x)
        val = (1.0 - self.ema_alpha) * prev + self.ema_alpha * x
        m[dim_id] = val
        return val

    def ingest(self, pkt: BusPacket) -> Optional[BusPacket]:
        dim = int(pkt.dim_id)
        if pkt.kind in ("insight", "score") and pkt.payload is not None:
            try:
                s = float(pkt.payload)
                self.scores[dim] = s
            except Exception:
                pass
            return None

        if pkt.kind.endswith("_summary") and isinstance(pkt.payload, dict):
            pl = pkt.payload
            if "ones" in pl and "count" in pl:
                count = float(pl.get("count", 0.0))
                ones = float(pl.get("ones", 0.0))
                rate = ones / max(1.0, count)
                act_e = self._ema(self.activity_ema, dim, count)
                one_e = self._ema(self.ones_ema, dim, rate)
                entropy_proxy = 4.0 * one_e * (1.0 - one_e)
                score = float(np.log1p(act_e) * (0.2 + entropy_proxy))
                self.scores[dim] = score
                return BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain,
                                 dim_id=dim, kind="insight", phase=pkt.phase, cfg_id=pkt.cfg_id, payload=score)

            if "std" in pl and "n" in pl:
                std = float(pl.get("std", 0.0))
                n = float(pl.get("n", 0.0))
                util = std * np.log1p(n)
                util_e = self._ema(self.activity_ema, dim, util)
                score = float(util_e)
                self.scores[dim] = score
                return BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain,
                                 dim_id=dim, kind="insight", phase=pkt.phase, cfg_id=pkt.cfg_id, payload=score)

        if pkt.kind in ("projection_1bit", "bit") and isinstance(pkt.payload, (int, float)):
            b = 1.0 if float(pkt.payload) > 0.5 else 0.0
            act_e = self._ema(self.activity_ema, dim, 1.0)
            one_e = self._ema(self.ones_ema, dim, b)
            entropy_proxy = 4.0 * one_e * (1.0 - one_e)
            score = float(np.log1p(act_e) * (0.2 + entropy_proxy))
            self.scores[dim] = score
            return BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain,
                             dim_id=dim, kind="insight", phase=pkt.phase, cfg_id=pkt.cfg_id, payload=score)
        return None
