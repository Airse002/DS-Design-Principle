from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional

from ..dimension_bus import BusPacket
from ..kinds import K_QPU_JOB_RES, K_CFG, K_INSIGHT

@dataclass
class QPUPolicyColony:
    """Consumes QPU job results and emits actions with explicit trace.

    Interprets `problem.kind` and the corresponding result:
    - insight_eval: emits `insight` packets
    - topk_subset: emits `cfg` KILL_DIM intents for dims not selected (Dim-plosion)
    - gate_opt: emits `cfg` SET_BREATH intent

    Trace format is included in every emitted action:
      payload['trace'] = {job_id, problem, backend(optional), source='qpu_policy'}
    """
    min_lanes: int = 4

    # cache last known dim_ids for topk actions
    last_dim_ids: List[int] = field(default_factory=list)

    def ingest(self, pkt: BusPacket) -> List[BusPacket]:
        if pkt.kind != K_QPU_JOB_RES or not isinstance(pkt.payload, dict):
            return []
        job_id = str(pkt.payload.get("job_id", ""))
        result = pkt.payload.get("result", None)
        error = pkt.payload.get("error", None)
        if error or not isinstance(result, dict):
            return []

        # attempt to recover problem kind if present (LoggingSampler includes it in the submitted packet only),
        # but many backends echo it back in result; if not, treat by keys.
        kind = result.get("kind", None) or result.get("problem_kind", None)

        outs: List[BusPacket] = []
        trace = {"job_id": job_id, "source": "qpu_policy"}

        # Insight evaluator result
        if "dim_ids" in result and "scores" in result:
            dim_ids = [int(x) for x in result.get("dim_ids", [])]
            scores = [float(x) for x in result.get("scores", [])]
            for d, s in zip(dim_ids, scores):
                outs.append(BusPacket(
                    time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=int(d),
                    kind=K_INSIGHT, phase=pkt.phase, cfg_id=pkt.cfg_id,
                    payload={"score": float(s), "trace": {**trace, "action": "INSIGHT"}},
                ))
            self.last_dim_ids = dim_ids
            return outs

        # Top-K subset result: selected indices or selected dim_ids
        if "selected" in result:
            selected = result.get("selected", [])
            # If selected are indices, map to last_dim_ids; else treat as ids if large
            sel_ids: List[int] = []
            if self.last_dim_ids and all(isinstance(x, int) and x < len(self.last_dim_ids) for x in selected):
                sel_ids = [int(self.last_dim_ids[int(i)]) for i in selected]
            else:
                sel_ids = [int(x) for x in selected]
            keep = set(sel_ids)
            # kill dims not in keep, but respect min_lanes if possible (leave at least min_lanes)
            if self.last_dim_ids:
                all_ids = list(self.last_dim_ids)
            else:
                all_ids = list(keep)
            kill_ids = [d for d in all_ids if d not in keep]
            # Enforce min_lanes by trimming kills if needed
            if len(all_ids) - len(kill_ids) < self.min_lanes:
                kill_ids = kill_ids[:max(0, len(all_ids) - self.min_lanes)]
            for d in kill_ids:
                outs.append(BusPacket(
                    time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000012,
                    kind=K_CFG, phase=pkt.phase, cfg_id=pkt.cfg_id,
                    payload={"cmd": "KILL_DIM", "dim_id": int(d), "trace": {**trace, "action": "KILL_DIM"}},
                ))
            return outs

        # Gate/breath optimizer result
        if "Te" in result and "Tc" in result:
            outs.append(BusPacket(
                time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000013,
                kind=K_CFG, phase=pkt.phase, cfg_id=pkt.cfg_id,
                payload={"cmd": "SET_BREATH", "Te": int(result["Te"]), "Tc": int(result["Tc"]),
                         "trace": {**trace, "action": "SET_BREATH"}},
            ))
            return outs

        return []
