from __future__ import annotations
from dataclasses import dataclass
from typing import List, Optional

from ..dimension_bus import BusPacket
from ..kinds import K_CONTROL, K_CFG
from ..pq_apply import BundleEnvelope, apply_bundle, load_bundle_from_envelope

@dataclass
class MetaColony:
    active_cfg_id: Optional[str] = None

    def ingest(self, pkt: BusPacket) -> List[BusPacket]:
        if pkt.kind != K_CONTROL or not isinstance(pkt.payload, dict):
            return []
        mode = str(pkt.payload.get("mode", "NORMAL"))
        score = float(pkt.payload.get("score", 0.0))

        outs: List[BusPacket] = []

        # Breath control (yin/yang)
        if mode == "SAFE_MODE":
            # more collision (yin): compress and stabilize
            outs.append(BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000003,
                                  kind=K_CFG, phase=pkt.phase, cfg_id=pkt.cfg_id,
                                  payload={"cmd": "SET_BREATH", "Te": 100, "Tc": 900}))
            # dimensional reduction (dim-plosion): kill a dim (lowest score)
            outs.append(BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000003,
                                  kind=K_CFG, phase=pkt.phase, cfg_id=pkt.cfg_id,
                                  payload={"cmd": "KILL_DIM"}))
        else:
            # more expand (yang): explore
            outs.append(BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000003,
                                  kind=K_CFG, phase=pkt.phase, cfg_id=pkt.cfg_id,
                                  payload={"cmd": "SET_BREATH", "Te": 600, "Tc": 400}))
            # occasionally birth a new dimension (exploration); keep conservative by score gate
            if score < 0.3:
                outs.append(BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000003,
                                      kind=K_CFG, phase=pkt.phase, cfg_id=pkt.cfg_id,
                                      payload={"cmd": "BIRTH_DIM"}))
        return outs

    def apply_signed_bundle(self, env: BundleEnvelope) -> bool:
        bundle = load_bundle_from_envelope(env)
        res = apply_bundle(bundle)
        if res.ok:
            self.active_cfg_id = res.cfg_id
            return True
        return False
