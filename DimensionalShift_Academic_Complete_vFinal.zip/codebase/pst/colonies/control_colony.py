from __future__ import annotations
from dataclasses import dataclass
from typing import List

from ..dimension_bus import BusPacket
from ..kinds import K_ANOMALY, K_CONTROL

@dataclass
class ControlColony:
    anomaly_hi: float = 0.6
    last_mode: str = "NORMAL"

    def ingest(self, pkt: BusPacket) -> List[BusPacket]:
        if pkt.kind != K_ANOMALY or not isinstance(pkt.payload, dict):
            return []
        score = float(pkt.payload.get("score", 0.0))
        mode = "SAFE_MODE" if score > self.anomaly_hi else "NORMAL"
        if mode == self.last_mode:
            return []
        self.last_mode = mode
        return [BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000002,
                          kind=K_CONTROL, phase=pkt.phase, cfg_id=pkt.cfg_id,
                          payload={"mode": mode, "score": score, "reason": "anomaly"})]
