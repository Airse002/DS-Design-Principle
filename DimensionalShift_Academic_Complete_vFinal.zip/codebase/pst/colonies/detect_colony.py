from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, List
import numpy as np

from ..dimension_bus import BusPacket
from ..kinds import K_EST_WAVE, K_ANOMALY
from ..detector import power_quality_features

@dataclass
class DetectionColony:
    baseline_feat: Optional[dict] = None

    def ingest(self, pkt: BusPacket) -> List[BusPacket]:
        if pkt.kind != K_EST_WAVE or not isinstance(pkt.payload, dict):
            return []
        xhat = np.array(pkt.payload.get("xhat", []), dtype=float)
        fs_hz = float(pkt.payload.get("fs_hz", 10_000.0))
        if xhat.size < 32:
            return []
        feat = power_quality_features(xhat, fs_hz=fs_hz)
        if self.baseline_feat is None:
            self.baseline_feat = feat
        rms, rms0 = feat.get("rms", 0.0), self.baseline_feat.get("rms", feat.get("rms", 0.0))
        thd, thd0 = feat.get("thd_proxy", 0.0), self.baseline_feat.get("thd_proxy", feat.get("thd_proxy", 0.0))
        score = float(abs(rms-rms0)/(rms0+1e-9) + abs(thd-thd0)/(thd0+1e-9))
        return [BusPacket(time_ns=pkt.time_ns, clock_domain=pkt.clock_domain, dim_id=900000001,
                          kind=K_ANOMALY, phase=pkt.phase, cfg_id=pkt.cfg_id,
                          payload={"score": score, "feat": feat})]
