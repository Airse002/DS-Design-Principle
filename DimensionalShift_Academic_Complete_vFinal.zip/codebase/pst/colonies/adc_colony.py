from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Tuple, List, Optional
import numpy as np

from ..dimension_bus import BusPacket
from ..kinds import K_BIT, K_EST_WAVE, K_INSIGHT
from ..decoder_waveform import decode_logistic
from ..adc_window import WindowSpec, build_measurements_for_window
from ..config_loader import bundle_breath, bundle_projection_dims

@dataclass
class ADCColony:
    fs_hz: float = 10_000.0
    win_N: int = 128
    decode_steps: int = 60
    decode_lr: float = 0.06
    decode_lam: float = 1e-3

    dims: List = field(default_factory=list)
    breath: Optional = None
    cfg_id: Optional[str] = None

    bits: Dict[Tuple[int,int], int] = field(default_factory=dict)
    last_emit_n0: int = 0

    def configure_from_bundle(self, bundle: dict):
        self.cfg_id = str(bundle.get("cfg_id", ""))
        self.breath = bundle_breath(bundle)
        self.dims = bundle_projection_dims(bundle)

    def ingest(self, pkt: BusPacket):
        if pkt.kind != K_BIT:
            return
        n = int(round(pkt.time_ns / int(1e9 / self.fs_hz)))
        self.bits[(n, int(pkt.dim_id))] = int(pkt.payload) if pkt.payload is not None else 0

    def maybe_emit(self, now_n: int) -> List[BusPacket]:
        if self.breath is None or not self.dims or not self.cfg_id:
            return []
        if now_n - self.last_emit_n0 < self.win_N:
            return []
        n0 = now_n - self.win_N
        spec = WindowSpec(fs_hz=self.fs_hz, dt_ns=int(1e9/self.fs_hz), win_N=self.win_N, kernel_L=len(self.dims[0].k_plus))
        A, s, th = build_measurements_for_window(self.dims, self.breath, self.bits, n0=n0, spec=spec)
        if A.shape[0] < max(16, self.win_N // 4):
            return []
        xhat = decode_logistic(A, s, th, lam=self.decode_lam, steps=self.decode_steps, lr=self.decode_lr)
        self.last_emit_n0 = n0

        out = BusPacket(time_ns=int(now_n * spec.dt_ns), clock_domain="host0", dim_id=900000000,
                        kind=K_EST_WAVE, phase=int(self.breath.phase(now_n)), cfg_id=self.cfg_id,
                        payload={"n0": int(n0), "fs_hz": float(self.fs_hz), "xhat": xhat.tolist()})
        # Per-dimension insight proxy
        counts, ones = {}, {}
        for (n, dim_id), b in self.bits.items():
            if n0 <= n < n0 + self.win_N:
                counts[dim_id] = counts.get(dim_id, 0) + 1
                ones[dim_id] = ones.get(dim_id, 0) + (1 if b else 0)
        insight = []
        for dim_id, c in counts.items():
            r = ones.get(dim_id, 0) / max(1, c)
            entropy_proxy = 4.0 * r * (1.0 - r)
            score = float(np.log1p(c) * (0.2 + entropy_proxy))
            insight.append(BusPacket(time_ns=int(now_n * spec.dt_ns), clock_domain="host0",
                                     dim_id=int(dim_id), kind=K_INSIGHT, phase=int(self.breath.phase(now_n)),
                                     cfg_id=self.cfg_id, payload=score))
        return [out] + insight
