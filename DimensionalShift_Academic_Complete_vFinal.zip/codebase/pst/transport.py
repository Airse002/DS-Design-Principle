from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable, Optional, Deque, List
from collections import deque
from .dimension_bus import BusPacket

class Transport:
    """Abstract transport for the Dimension Bus."""
    def send(self, pkt: BusPacket) -> None:
        raise NotImplementedError

    def recv(self) -> Iterable[BusPacket]:
        raise NotImplementedError

@dataclass
class InProcessTransport(Transport):
    """Reference transport for simulations: a FIFO queue."""
    maxlen: int = 1_000_000

    def __post_init__(self):
        self.q: Deque[BusPacket] = deque(maxlen=self.maxlen)

    def send(self, pkt: BusPacket) -> None:
        self.q.append(pkt)

    def recv(self) -> Iterable[BusPacket]:
        while self.q:
            yield self.q.popleft()
