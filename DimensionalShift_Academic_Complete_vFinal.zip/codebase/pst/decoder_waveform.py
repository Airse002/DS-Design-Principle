from __future__ import annotations
import numpy as np

def decode_logistic(A: np.ndarray, s: np.ndarray, th: np.ndarray, lam: float = 1e-3, steps: int = 2000, lr: float = 0.05) -> np.ndarray:
    M, N = A.shape
    x = np.zeros(N, dtype=float)
    if M == 0:
        return x
    for _ in range(steps):
        z = (A @ x) - th
        t = -s * z
        sig = 1.0 / (1.0 + np.exp(-t))
        grad = -(A.T @ (s * sig)) + 2 * lam * x
        x -= lr * grad / M
    return x

def detect_events(x: np.ndarray, thresh: float = 3.0) -> np.ndarray:
    if x.size < 8:
        return np.array([], dtype=int)
    dx = np.diff(x, prepend=x[0])
    z = (dx - dx.mean()) / (dx.std() + 1e-9)
    return np.where(np.abs(z) > thresh)[0]
