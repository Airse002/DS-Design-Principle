from __future__ import annotations
import numpy as np

def power_quality_features(v: np.ndarray, fs_hz: float) -> dict:
    if v.size < 32:
        return {'rms': float(np.sqrt(np.mean(v*v))) if v.size else 0.0}
    v0 = v - v.mean()
    rms = float(np.sqrt(np.mean(v*v)))
    fft = np.fft.rfft(v0)
    psd = (fft.real**2 + fft.imag**2) / max(1, v0.size)
    freqs = np.fft.rfftfreq(v0.size, d=1.0/fs_hz)
    fund_band = (freqs > 45) & (freqs < 75)
    harm_band = (freqs > 75) & (freqs < min(0.45*fs_hz, fs_hz/2))
    fund = float(psd[fund_band].sum()) + 1e-9
    harm = float(psd[harm_band].sum())
    return {'rms': rms, 'thd_proxy': harm/fund}

def anomaly_score(feat: dict, baseline: dict) -> float:
    rms, rms0 = feat.get('rms', 0.0), baseline.get('rms', feat.get('rms', 0.0))
    thd, thd0 = feat.get('thd_proxy', 0.0), baseline.get('thd_proxy', feat.get('thd_proxy', 0.0))
    return float(abs(rms-rms0)/(rms0+1e-9) + abs(thd-thd0)/(thd0+1e-9))
