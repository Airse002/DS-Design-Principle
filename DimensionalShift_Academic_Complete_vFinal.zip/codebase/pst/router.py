from __future__ import annotations
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple
import math
from .dimension_bus import BusPacket

from typing import Any
try:
    from .router_policies import TopKFilter
except Exception:
    TopKFilter = None


Predicate = Callable[[BusPacket], bool]
Handler = Callable[[BusPacket], None]

@dataclass
class Subscription:
    name: str
    predicate: Predicate
    handler: Handler
    overload_policy: str = "drop"   # 'drop' or 'coalesce'
    max_rate_hz: Optional[float] = None
    _last_time_ns: int = 0
    _coalesced: Optional[BusPacket] = None

class Router:
    """In-process Dimension Bus router: pub/sub + collision compression."""
    def __init__(self, window_ns: int = 5_000_000, filter_policy: Any = None):
        self.subs: List[Subscription] = []
        self.filter_policy = filter_policy
        self.window_ns = window_ns
        self._agg: Dict[Tuple[int,str,str], dict] = {}
        self._agg_start_ns: Dict[Tuple[int,str,str], int] = {}

    def subscribe(self, sub: Subscription):
        self.subs.append(sub)

    def publish(self, pkt: BusPacket):
        if self.filter_policy is not None:
            # allow score updates through
            if pkt.kind in ('insight','score') and pkt.payload is not None:
                try:
                    self.filter_policy.update_score(pkt.dim_id, float(pkt.payload))
                except Exception:
                    pass
            if not self.filter_policy.allow(pkt):
                return
        out = self._maybe_summarize(pkt)
        for op in out:
            for sub in self.subs:
                if not sub.predicate(op):
                    continue
                if sub.max_rate_hz is not None and sub._last_time_ns:
                    if (op.time_ns - sub._last_time_ns) < int(1e9 / sub.max_rate_hz):
                        continue
                sub._last_time_ns = op.time_ns
                try:
                    sub.handler(op)
                except Exception:
                    if sub.overload_policy == "coalesce":
                        sub._coalesced = op

    def flush(self):
        for sub in self.subs:
            if sub._coalesced is not None:
                try:
                    sub.handler(sub._coalesced)
                finally:
                    sub._coalesced = None

    def _maybe_summarize(self, pkt: BusPacket):
        if pkt.phase == 1:
            return [pkt]
        if pkt.kind in ("feature", "feature_voltage_sense"):
            return self._agg_feature(pkt)
        if pkt.kind in ("bit", "spike", "projection_1bit"):
            return self._agg_events(pkt)
        return [pkt]

    def _key(self, pkt: BusPacket):
        return (pkt.dim_id, pkt.kind, pkt.cfg_id)

    def _window_ready(self, key, t):
        start = self._agg_start_ns.get(key, t)
        return (t - start) >= self.window_ns

    def _reset(self, key, t):
        self._agg_start_ns[key] = t
        self._agg[key] = {}

    def _agg_feature(self, pkt: BusPacket):
        key = self._key(pkt)
        if key not in self._agg:
            self._reset(key, pkt.time_ns)
        a = self._agg[key]
        x = float(pkt.payload) if pkt.payload is not None else 0.0

        # Welford mean/var
        n = a.get("n", 0) + 1
        mean = a.get("mean", 0.0)
        M2 = a.get("M2", 0.0)
        delta = x - mean
        mean += delta / n
        M2 += delta * (x - mean)

        a["n"] = n
        a["mean"] = mean
        a["M2"] = M2
        a["min"] = x if "min" not in a else min(a["min"], x)
        a["max"] = x if "max" not in a else max(a["max"], x)

        if not self._window_ready(key, pkt.time_ns):
            return []

        var = (M2 / max(1, n-1)) if n > 1 else 0.0
        std = math.sqrt(max(0.0, var))
        summary = BusPacket(
            time_ns=pkt.time_ns,
            clock_domain=pkt.clock_domain,
            dim_id=pkt.dim_id,
            kind=pkt.kind + "_summary",
            phase=pkt.phase,
            cfg_id=pkt.cfg_id,
            payload={"mean": mean, "std": std, "min": a["min"], "max": a["max"], "n": n},
        )
        self._reset(key, pkt.time_ns)
        return [summary]

    def _agg_events(self, pkt: BusPacket):
        key = self._key(pkt)
        if key not in self._agg:
            self._reset(key, pkt.time_ns)
        a = self._agg[key]
        a["count"] = a.get("count", 0) + 1
        try:
            v = pkt.payload
            if isinstance(v, (int, float)):
                a["ones"] = a.get("ones", 0) + (1 if float(v) > 0.5 else 0)
        except Exception:
            pass

        if not self._window_ready(key, pkt.time_ns):
            return []

        summary = BusPacket(
            time_ns=pkt.time_ns,
            clock_domain=pkt.clock_domain,
            dim_id=pkt.dim_id,
            kind=pkt.kind + "_summary",
            phase=pkt.phase,
            cfg_id=pkt.cfg_id,
            payload={"count": a.get("count", 0), "ones": a.get("ones", 0)},
        )
        self._reset(key, pkt.time_ns)
        return [summary]
