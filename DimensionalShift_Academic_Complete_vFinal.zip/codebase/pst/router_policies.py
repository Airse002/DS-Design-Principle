from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Set, Iterable, Tuple, Optional, List
import heapq
from .dimension_bus import BusPacket

@dataclass
class TopKFilter:
    """Keeps only top-k dimension ids (by score) during collision.
    Scores are updated by packets of kind 'insight' or 'score' with payload float.
    """
    k: int = 64
    default_score: float = 0.0
    scores: Dict[int, float] = field(default_factory=dict)

    def update_score(self, dim_id: int, score: float):
        self.scores[dim_id] = float(score)

    def topk_set(self) -> Set[int]:
        if not self.scores:
            return set()
        # get k largest scores
        items = heapq.nlargest(self.k, self.scores.items(), key=lambda kv: kv[1])
        return {dim for dim, _ in items}

    def allow(self, pkt: BusPacket) -> bool:
        # Expand always allowed (filter is collision-only)
        if pkt.phase == 1:
            return True
        # If we have no scores yet, allow everything (bootstraps)
        if not self.scores:
            return True
        return pkt.dim_id in self.topk_set()
