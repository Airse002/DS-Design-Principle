from __future__ import annotations
from typing import Dict, Any, List
import json
from pathlib import Path
import numpy as np

from .config import Gate, DimDef, make_bundle
from .backends.digital_backend import Dimension, Breath

def load_bundle(path: str | Path) -> Dict[str, Any]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)

def bundle_cfg_id(bundle: Dict[str, Any]) -> str:
    cfg_id = bundle.get("cfg_id")
    if not cfg_id:
        raise ValueError("bundle missing cfg_id")
    return str(cfg_id)

def bundle_breath(bundle: Dict[str, Any]) -> Breath:
    b = bundle.get("breath", {})
    Te = int(b.get("Te", 60))
    Tc = int(b.get("Tc", 40))
    return Breath(Te=Te, Tc=Tc)

def bundle_projection_dims(bundle: Dict[str, Any]) -> List[Dimension]:
    dims: List[Dimension] = []
    for d in bundle.get("dimensions", []):
        kind = d.get("kind")
        if kind not in ("projection_1bit", "bit", "spike"):
            continue
        dim_id = int(d["dim_id"])
        k_plus = np.array(d.get("kernel_plus", []), dtype=float)
        k_minus = np.array(d.get("kernel_minus", []), dtype=float)
        gate = d.get("gate", {})
        P = int(gate.get("P", 25))
        duty = float(gate.get("d", 0.2))
        delta = int(gate.get("delta", 0))
        theta = float(d.get("threshold", 0.0))
        dims.append(Dimension(
            dim_id=dim_id,
            kind=kind,
            k_plus=k_plus,
            k_minus=k_minus,
            P=P,
            d=duty,
            delta=delta,
            theta=theta,
            dither_std=float(d.get("dither_std", 0.02)),
        ))
    if not dims:
        raise ValueError("bundle has no projection dimensions (projection_1bit)")
    L = len(dims[0].k_plus)
    for dim in dims:
        if len(dim.k_plus) != L or len(dim.k_minus) != L:
            raise ValueError("inconsistent kernel lengths in bundle")
    return dims

def ensure_example_bundle(out_path: str | Path, fs_hz: float = 10_000.0, lanes: int = 8, L: int = 16) -> Dict[str, Any]:
    out_path = Path(out_path)
    if out_path.exists():
        return load_bundle(out_path)
    from .config import random_kernel
    dims: List[DimDef] = []
    for i in range(lanes):
        dims.append(DimDef(
            dim_id=1_000_000 + i,
            kind="projection_1bit",
            rate_hz=float(fs_hz),
            kernel_plus=random_kernel(L, seed=100+i),
            kernel_minus=random_kernel(L, seed=200+i),
            gate=Gate(P=25+(i%5), d=0.20+0.02*(i%3), delta=i),
            threshold=0.0,
            calibration={"unit":"arb","notes":"auto-generated example lane"},
        ))
    bundle = make_bundle(Te=600, Tc=400, dims=dims)  # Te/Tc in samples for ref demo
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(bundle, indent=2), encoding="utf-8")
    return bundle
