"""
Pulse-Space Transduction Nervous System (PST-NS)
==============================================

This module implements your architecture:

- Voltage is the machine's primary "body sense" (0..230V).
- At each timestep, we derive 9+ interoceptive senses (dimensions) from voltage:
    [level, dV/dt, |dV/dt|, volatility, energy, texture_low, texture_mid, texture_high, pain_sign]
- A chained graph of organisms (agents) communicates via PWM-gated connections (0/1).
- Global breathing alternates:
    Expand (Yang/intuition): open gates + try birthing new senses (new dimensions)
    Collision (Yin/insight): compress (top-k connections) + prune latent dimensions
- Each organism performs predictive coding: predict next interoceptive state.
- A reflex override forces collision if voltage pain is high.

Quick start
-----------
1) Create VoltageSpec(fs_hz=YOUR_RATE).
2) Feed real voltage samples into VoltageFeatureExtractor.update(V).
3) Each step: feats, dbg = extractor.base_features(); pain = extractor.pain()
4) Provide target_next (next-step features) or a prediction target you care about.
5) Call ChainOrganismNetwork.step(...)

Artifacts in this sandbox:
- Demo plot: pst_voltage_nervous_system_demo.png
"""

from __future__ import annotations
import numpy as np
from dataclasses import dataclass, field
from typing import List, Dict, Callable, Optional, Tuple
import math

def clamp(x: float, lo: float, hi: float) -> float:
    return lo if x < lo else hi if x > hi else x

@dataclass
class VoltageSpec:
    v_min: float = 0.0
    v_max: float = 230.0
    v_safe_low: float = 90.0
    v_safe_high: float = 240.0
    fs_hz: float = 1000.0
    w_short_s: float = 0.050
    w_mid_s: float = 0.200
    @property
    def w_short(self) -> int:
        return max(4, int(self.w_short_s * self.fs_hz))
    @property
    def w_mid(self) -> int:
        return max(self.w_short + 2, int(self.w_mid_s * self.fs_hz))

class VoltageFeatureExtractor:
    def __init__(self, spec: VoltageSpec):
        self.spec = spec
        self.buf = np.zeros(spec.w_mid, dtype=float)
        self.idx = 0
        self.n_seen = 0
        self.prev_v = None

    def update(self, v: float):
        v = float(clamp(v, self.spec.v_min, self.spec.v_max))
        self.buf[self.idx] = v
        self.idx = (self.idx + 1) % self.spec.w_mid
        self.n_seen += 1

    def _window(self, w: int) -> np.ndarray:
        w = min(w, self.n_seen, self.spec.w_mid)
        if w <= 0:
            return np.zeros(0, dtype=float)
        end = self.idx
        start = (end - w) % self.spec.w_mid
        if start < end:
            return self.buf[start:end].copy()
        return np.concatenate([self.buf[start:], self.buf[:end]]).copy()

    def _bandpower(self, x: np.ndarray, f_lo: float, f_hi: float) -> float:
        if x.size < 8:
            return 0.0
        x = x - x.mean()
        fft = np.fft.rfft(x)
        psd = (fft.real**2 + fft.imag**2) / max(1, x.size)
        freqs = np.fft.rfftfreq(x.size, d=1.0/self.spec.fs_hz)
        mask = (freqs >= f_lo) & (freqs < f_hi)
        return float(psd[mask].sum())

    def pain(self) -> float:
        v = float(self._window(1)[-1]) if self.n_seen else 0.0
        below = max(0.0, self.spec.v_safe_low - v)
        above = max(0.0, v - self.spec.v_safe_high)
        return float((below*below + above*above) / (self.spec.v_max**2))

    def base_features(self) -> Tuple[np.ndarray, Dict[str, float]]:
        spec = self.spec
        xs = self._window(spec.w_short)
        xm = self._window(spec.w_mid)
        v = float(xs[-1]) if xs.size else 0.0
        dv = 0.0 if self.prev_v is None else (v - self.prev_v) * spec.fs_hz
        self.prev_v = v

        v_norm = (v - spec.v_min) / max(1e-9, (spec.v_max - spec.v_min))
        var_s = float(xs.var()) if xs.size else 0.0
        rms_s = float(np.sqrt((xs*xs).mean())) if xs.size else 0.0

        nyq = 0.5 * spec.fs_hz
        bp_low = self._bandpower(xm, 0.0, min(10.0, nyq))
        bp_mid = self._bandpower(xm, min(10.0, nyq), min(80.0, nyq))
        bp_hi  = self._bandpower(xm, min(80.0, nyq), min(0.45*spec.fs_hz, nyq))

        spike = 1.0 if v > spec.v_safe_high else 0.0
        drop  = 1.0 if v < spec.v_safe_low else 0.0

        feats = np.array([
            v_norm,
            dv / 5000.0,
            abs(dv) / 5000.0,
            var_s / (spec.v_max**2),
            rms_s / spec.v_max,
            bp_low / 1e6,
            bp_mid / 1e6,
            bp_hi / 1e6,
            spike - drop
        ], dtype=float)

        return feats, {"v": v, "dv": dv, "pain": self.pain()}

    def candidate_sense_functions(self) -> Dict[str, Callable[[], float]]:
        spec = self.spec
        def kurtosis_mid():
            x = self._window(spec.w_mid)
            if x.size < 16:
                return 0.0
            x = x - x.mean()
            m2 = np.mean(x*x) + 1e-9
            m4 = np.mean((x*x)*(x*x))
            return float(m4/(m2*m2) - 3.0)
        def trend_mid():
            x = self._window(spec.w_mid)
            if x.size < 16:
                return 0.0
            t = np.arange(x.size)
            t = (t - t.mean())/(t.std()+1e-9)
            slope = float(np.dot(t, x-x.mean())/(np.dot(t,t)+1e-9))
            return slope/spec.v_max
        def ripple_60hz():
            x = self._window(spec.w_mid)
            nyq = 0.5*spec.fs_hz
            if nyq < 70:
                return 0.0
            return self._bandpower(x, 55.0, 65.0)/1e6
        def ripple_120hz():
            x = self._window(spec.w_mid)
            nyq = 0.5*spec.fs_hz
            if nyq < 130:
                return 0.0
            return self._bandpower(x, 110.0, 130.0)/1e6
        return {"kurtosis_mid": kurtosis_mid, "trend_mid": trend_mid, "ripple_60hz": ripple_60hz, "ripple_120hz": ripple_120hz}

@dataclass
class BreathController:
    Te: int = 30
    Tc: int = 50
    Te_min: int = 5
    Tc_min: int = 5
    Te_max: int = 200
    Tc_max: int = 200
    pain_hi: float = 0.02
    def phase(self, t: int) -> int:
        P = self.Te + self.Tc
        return +1 if (t % P) < self.Te else -1
    def reflex_override(self, pain: float) -> Optional[int]:
        return -1 if pain > self.pain_hi else None
    def adapt(self, pain: float, learning_progress: float):
        if pain > self.pain_hi:
            self.Tc = min(self.Tc_max, self.Tc + 1)
            self.Te = max(self.Te_min, self.Te - 1)
        else:
            if learning_progress > 0.0:
                self.Te = min(self.Te_max, self.Te + 1)
                self.Tc = max(self.Tc_min, self.Tc - 1)

@dataclass
class PWMGates:
    n: int
    Pmin: int = 4
    Pmax: int = 200
    dmin: float = 0.02
    dmax: float = 0.95
    P: np.ndarray = field(init=False)
    duty: np.ndarray = field(init=False)
    delta: np.ndarray = field(init=False)
    def __post_init__(self):
        self.P = np.full((self.n, self.n), 20, dtype=int)
        self.duty = np.full((self.n, self.n), 0.2, dtype=float)
        rng = np.random.default_rng(123)
        self.delta = rng.integers(0, 20, size=(self.n, self.n), dtype=int)
        np.fill_diagonal(self.duty, 0.0)
    def gate(self, t: int) -> np.ndarray:
        P = np.maximum(self.P, 1)
        on_len = np.floor(self.duty * P).astype(int)
        phase = (t + self.delta) % P
        return (phase < on_len).astype(np.uint8)
    def compress_topk(self, insight: np.ndarray, k: int = 3):
        for j in range(self.n):
            scores = insight[:, j].copy()
            scores[j] = -np.inf
            top = np.argsort(scores)[-k:]
            mask = np.zeros(self.n, dtype=bool)
            mask[top] = True
            for i in range(self.n):
                if i == j:
                    continue
                self.duty[i, j] = (min(self.dmax, self.duty[i, j]*1.05 + 0.01)
                                  if mask[i] else max(self.dmin, self.duty[i, j]*0.85))
    def expand_open(self, intuition: np.ndarray, scale: float = 0.02):
        self.duty = np.clip(self.duty + scale*intuition, self.dmin, self.dmax)
        np.fill_diagonal(self.duty, 0.0)

class OnlinePredictor:
    def __init__(self, in_dim: int, out_dim: int, lr: float = 2e-3, l2: float = 1e-4, seed: int = 0):
        rng = np.random.default_rng(seed)
        self.W = rng.normal(scale=0.1, size=(out_dim, in_dim))
        self.lr = lr
        self.l2 = l2
        self.prev_mse = None
    def predict(self, x: np.ndarray) -> np.ndarray:
        return self.W @ x
    def update(self, x: np.ndarray, y_true: np.ndarray) -> Tuple[np.ndarray, float, float]:
        y_hat = self.predict(x)
        err = y_true - y_hat
        self.W += self.lr * (err[:, None] @ x[None, :]) - self.lr*self.l2*self.W
        mse = float(np.mean(err*err))
        lp = 0.0 if self.prev_mse is None else float(self.prev_mse - mse)
        self.prev_mse = mse
        return y_hat, mse, lp

@dataclass
class Organism:
    id: int
    in_dim: int
    latent_dim: int = 9
    out_dim: int = 9
    seed: int = 0
    z: np.ndarray = field(init=False)
    E: np.ndarray = field(init=False)
    pred: OnlinePredictor = field(init=False)
    out: np.ndarray = field(init=False)
    def __post_init__(self):
        rng = np.random.default_rng(self.seed + self.id*1000)
        self.z = np.zeros(self.latent_dim)
        self.E = rng.normal(scale=0.2, size=(self.latent_dim, self.in_dim))
        self.pred = OnlinePredictor(self.latent_dim, self.out_dim, seed=self.seed + self.id)
        self.out = np.zeros(self.out_dim)
    def encode(self, x: np.ndarray, phase: int) -> np.ndarray:
        gain = 1.2 if phase == +1 else 0.8
        return np.tanh(gain * (self.E @ x))
    def step(self, x: np.ndarray, phase: int, target_next: np.ndarray) -> Dict[str, float]:
        h = self.encode(x, phase)
        self.z = (0.95*self.z + 0.20*h) if phase == +1 else (0.98*self.z + 0.08*h)
        _, mse, lp = self.pred.update(self.z, target_next)
        self.out = np.tanh(self.z)
        return {"mse": mse, "lp": lp}
    def compress_dimensions(self, k_keep: int):
        if k_keep >= self.latent_dim:
            return
        imp = np.sum(np.abs(self.pred.W), axis=0)
        keep = np.sort(np.argsort(imp)[-k_keep:])
        self.z = self.z[keep]
        self.E = self.E[keep, :]
        self.pred.W = self.pred.W[:, keep]
        self.latent_dim = int(k_keep)

class ChainOrganismNetwork:
    def __init__(self, n_org: int, base_feat_dim: int, seed: int = 0):
        self.n = n_org
        self.base_feat_dim = base_feat_dim
        self.seed = seed
        rng = np.random.default_rng(seed)
        self.orgs = [Organism(i, in_dim=base_feat_dim+1, seed=seed) for i in range(n_org)]
        self.W = rng.normal(scale=0.3, size=(n_org, n_org))
        np.fill_diagonal(self.W, 0.0)
        self.gates = PWMGates(n_org)
        self.t = 0
        self.global_D = base_feat_dim
        self.active_extra_senses: List[str] = []
        self.extra_sense_funcs: Dict[str, Callable[[], float]] = {}
        self.extra_sense_values: Dict[str, float] = {}
        self.insight = np.zeros((n_org, n_org))
        self.intuition = np.zeros((n_org, n_org))

    def _pad_to(self, x: np.ndarray, d: int) -> np.ndarray:
        return np.pad(x, (0, d-x.size)) if x.size < d else x[:d]

    def _messages(self, t: int) -> np.ndarray:
        gate = self.gates.gate(t)
        carrier = np.array([float(o.out[0]) for o in self.orgs], dtype=float)
        return ((gate * self.W) * carrier[:, None]).sum(axis=0)

    def _update_insight_intuition(self, org_metrics: List[Dict[str, float]]):
        mse = np.array([m["mse"] for m in org_metrics]) + 1e-9
        lp = np.array([m["lp"] for m in org_metrics])
        src_use = 1.0 / mse
        src_nov = np.clip(lp, 0.0, None)
        self.insight = src_use[:, None] * np.abs(self.W)
        self.intuition = src_nov[:, None] * np.abs(self.W)
        if self.insight.max() > 0:
            self.insight /= self.insight.max()
        if self.intuition.max() > 0:
            self.intuition /= self.intuition.max()

    def _dimension_birth_try(self, extractor: VoltageFeatureExtractor, base_feats: np.ndarray,
                             target_next: np.ndarray, epsilon: float = 1e-4, lam: float = 0.001):
        if not self.extra_sense_funcs:
            self.extra_sense_funcs = extractor.candidate_sense_functions()
        if len(self.active_extra_senses) >= 24:
            return
        cand = [k for k in self.extra_sense_funcs if k not in self.active_extra_senses]
        if not cand:
            return
        rng = np.random.default_rng(self.seed + 999 + self.t)
        rng.shuffle(cand)
        cand = cand[:3]
        msg = self._messages(self.t)

        ext0 = np.concatenate([base_feats, np.array([float(v) for v in self.extra_sense_values.values()])])

        # baseline
        baseline = []
        for j, org in enumerate(self.orgs):
            x_in = self._pad_to(np.concatenate([ext0, [msg[j]]]), org.in_dim)
            h = org.encode(x_in, +1)
            z = 0.95*org.z + 0.20*h
            err = target_next[:org.out_dim] - org.pred.predict(z)
            baseline.append(float(np.mean(err*err)))
        baseline = float(np.mean(baseline))

        best_name, best_gain = None, 0.0
        for name in cand:
            val = float(self.extra_sense_funcs[name]())
            ext = np.concatenate([ext0, [val]])
            mses = []
            for j, org in enumerate(self.orgs):
                x_in = self._pad_to(np.concatenate([ext, [msg[j]]]), org.in_dim)
                h = org.encode(x_in, +1)
                z = 0.95*org.z + 0.20*h
                err = target_next[:org.out_dim] - org.pred.predict(z)
                mses.append(float(np.mean(err*err)))
            trial = float(np.mean(mses))
            gain = (baseline - trial) - lam
            if gain > best_gain:
                best_gain, best_name = gain, name

        if best_name is not None and best_gain > epsilon:
            self.active_extra_senses.append(best_name)
            self.extra_sense_values[best_name] = float(self.extra_sense_funcs[best_name]())
            self.global_D = self.base_feat_dim + len(self.active_extra_senses)

    def step(self, base_feats: np.ndarray, target_next: np.ndarray,
             breath: BreathController, pain: float, extractor: VoltageFeatureExtractor) -> int:
        phase = breath.phase(self.t)
        ov = breath.reflex_override(pain)
        if ov is not None:
            phase = ov

        if self.active_extra_senses and not self.extra_sense_funcs:
            self.extra_sense_funcs = extractor.candidate_sense_functions()
        for name in self.active_extra_senses:
            self.extra_sense_values[name] = float(self.extra_sense_funcs[name]())

        ext = np.concatenate([base_feats, np.array([float(v) for v in self.extra_sense_values.values()])])
        msg = self._messages(self.t)

        org_metrics = []
        for j, org in enumerate(self.orgs):
            x_in = self._pad_to(np.concatenate([ext, [msg[j]]]), org.in_dim)
            org_metrics.append(org.step(x_in, phase, target_next[:org.out_dim]))

        self._update_insight_intuition(org_metrics)

        if phase == +1:
            self.gates.expand_open(self.intuition, scale=0.03)
            if (self.t % 25) == 0 and pain < breath.pain_hi:
                self._dimension_birth_try(extractor, base_feats, target_next)
        else:
            self.gates.compress_topk(self.insight, k=3)
            for org in self.orgs:
                k_keep = max(9, int(math.ceil(org.latent_dim*0.7)))
                if org.latent_dim > k_keep:
                    org.compress_dimensions(k_keep)

        breath.adapt(pain, float(np.mean([max(0.0, m["lp"]) for m in org_metrics])))
        self.t += 1
        return phase
