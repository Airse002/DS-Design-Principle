from __future__ import annotations
from dataclasses import dataclass
from typing import List, Dict, Any, Optional
import json, uuid, time
import numpy as np

@dataclass
class Gate:
    P: int
    d: float
    delta: int

@dataclass
class DimDef:
    dim_id: int
    kind: str
    rate_hz: float
    kernel_plus: List[float]
    kernel_minus: List[float]
    gate: Gate
    threshold: float
    calibration: Optional[Dict[str, Any]] = None

def new_cfg_id() -> str:
    return str(uuid.uuid4())

def now_utc() -> str:
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

def random_kernel(L: int, seed: int) -> List[float]:
    rng = np.random.default_rng(seed)
    k = rng.normal(size=L)
    k = k / (np.linalg.norm(k) + 1e-9)
    return k.tolist()

def make_bundle(Te: int, Tc: int, dims: List[DimDef], cfg_id: Optional[str] = None) -> Dict[str, Any]:
    return {
        "cfg_id": cfg_id or new_cfg_id(),
        "created_utc": now_utc(),
        "breath": {"Te": int(Te), "Tc": int(Tc)},
        "dimensions": [
            {
                "dim_id": d.dim_id,
                "kind": d.kind,
                "rate_hz": float(d.rate_hz),
                "kernel_plus": d.kernel_plus,
                "kernel_minus": d.kernel_minus,
                "gate": {"P": int(d.gate.P), "d": float(d.gate.d), "delta": int(d.gate.delta)},
                "threshold": float(d.threshold),
                "calibration": d.calibration or {},
            }
            for d in dims
        ],
    }

def dump_bundle(bundle: Dict[str, Any], path: str):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(bundle, f, indent=2)
