from __future__ import annotations
from dataclasses import dataclass
from typing import Optional, Protocol, Dict, Any
import json

class Verifier(Protocol):
    def verify(self, data: bytes, sig: bytes) -> bool: ...

@dataclass
class BundleEnvelope:
    cfg_id: str
    bundle_json: bytes
    signature: bytes
    signer_id: str = "unknown"

def verify_envelope(env: BundleEnvelope, verifier: Verifier) -> bool:
    return verifier.verify(env.bundle_json, env.signature)

def load_bundle_from_envelope(env: BundleEnvelope) -> Dict[str, Any]:
    return json.loads(env.bundle_json.decode("utf-8"))

@dataclass
class ApplyResult:
    ok: bool
    reason: str = ""
    cfg_id: Optional[str] = None

def apply_bundle(bundle: Dict[str, Any]) -> ApplyResult:
    if "cfg_id" not in bundle or "dimensions" not in bundle or "breath" not in bundle:
        return ApplyResult(ok=False, reason="bundle missing required keys")
    return ApplyResult(ok=True, cfg_id=str(bundle["cfg_id"]))
