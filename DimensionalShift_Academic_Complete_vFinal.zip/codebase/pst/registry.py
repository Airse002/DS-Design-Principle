from __future__ import annotations
from dataclasses import dataclass
from typing import Dict, Optional
import uuid, time

@dataclass
class DimensionMeta:
    dim_id: int
    kind: str
    rate_hz: float
    clock_domain: str
    latency_us: int = 0
    calibration: Optional[dict] = None
    cfg_id: Optional[str] = None

class DimensionRegistry:
    def __init__(self):
        self._dims: Dict[int, DimensionMeta] = {}
        self._cfg: Dict[str, dict] = {}

    def register_dim(self, meta: DimensionMeta):
        self._dims[meta.dim_id] = meta

    def list_dims(self):
        return list(self._dims.values())

    def put_cfg_bundle(self, bundle: dict):
        cfg_id = bundle.get('cfg_id')
        if not cfg_id:
            raise ValueError('cfg bundle missing cfg_id')
        self._cfg[cfg_id] = bundle

    def get_cfg_bundle(self, cfg_id: str) -> Optional[dict]:
        return self._cfg.get(cfg_id)

    @staticmethod
    def new_cfg_id() -> str:
        return str(uuid.uuid4())

    @staticmethod
    def now_utc() -> str:
        return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())
