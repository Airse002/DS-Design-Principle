"""Post-Quantum control plane wiring (interfaces, not crypto code)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Protocol

class Signer(Protocol):
    def sign(self, data: bytes) -> bytes: ...
    def verify(self, data: bytes, sig: bytes) -> bool: ...

@dataclass
class ControlEnvelope:
    cfg_id: str
    payload: bytes
    signature: bytes

def sign_config_bundle(bundle_json: bytes, cfg_id: str, signer: Signer) -> ControlEnvelope:
    return ControlEnvelope(cfg_id=cfg_id, payload=bundle_json, signature=signer.sign(bundle_json))

def verify_config_bundle(env: ControlEnvelope, signer: Signer) -> bool:
    return signer.verify(env.payload, env.signature)
