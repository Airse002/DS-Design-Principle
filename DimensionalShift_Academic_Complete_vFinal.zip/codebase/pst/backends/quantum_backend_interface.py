"""Quantum backend interface (concept)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from ..dimension_bus import BusPacket

@dataclass
class QuantumDeviceInfo:
    device_id: str
    clock_domain: str = "qdev0"
    shots_per_setting: int = 256

class QuantumBackendInterface:
    def __init__(self, info: QuantumDeviceInfo):
        self.info = info

    def send_control(self, pkt: BusPacket) -> None:
        raise NotImplementedError

    def run_measurements(self) -> Iterable[BusPacket]:
        raise NotImplementedError
