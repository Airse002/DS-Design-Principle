"""FPGA backend interface (concept)."""
from __future__ import annotations
from dataclasses import dataclass
from typing import Iterable
from ..dimension_bus import BusPacket

@dataclass
class FPGADeviceInfo:
    device_id: str
    clock_domain: str = "fpga0"
    max_lane_count: int = 256

class FPGABackendInterface:
    def __init__(self, info: FPGADeviceInfo):
        self.info = info

    def send_control(self, pkt: BusPacket) -> None:
        raise NotImplementedError

    def recv_data(self) -> Iterable[BusPacket]:
        raise NotImplementedError
