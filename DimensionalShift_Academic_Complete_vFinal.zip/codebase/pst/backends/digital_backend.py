from __future__ import annotations
import numpy as np
from dataclasses import dataclass
from typing import List, Tuple, Dict

@dataclass
class Breath:
    Te: int
    Tc: int
    def phase(self, n: int) -> int:
        P = self.Te + self.Tc
        return +1 if (n % P) < self.Te else -1

@dataclass
class Dimension:
    dim_id: int
    kind: str
    k_plus: np.ndarray
    k_minus: np.ndarray
    P: int
    d: float
    delta: int
    theta: float
    dither_std: float = 0.01

class DigitalPSTEncoder:
    def __init__(self, fs_hz: float, dims: List[Dimension], breath: Breath, seed: int = 0):
        self.fs_hz = fs_hz
        self.dims = dims
        self.breath = breath
        self.rng = np.random.default_rng(seed)

    def _gate(self, dim: Dimension, n: int) -> int:
        P = max(dim.P, 1)
        on_len = int(np.floor(dim.d * P))
        return 1 if ((n + dim.delta) % P) < on_len else 0

    def encode(self, x: np.ndarray) -> Tuple[np.ndarray, Dict[str, np.ndarray]]:
        N = len(x)
        D = len(self.dims)
        L = len(self.dims[0].k_plus)
        B = np.zeros((N, D), dtype=np.uint8)
        rows, signs, ths = [], [], []
        for n in range(N):
            phi = self.breath.phase(n)
            for i, dim in enumerate(self.dims):
                if self._gate(dim, n) == 0:
                    continue
                k = dim.k_plus if phi == +1 else dim.k_minus
                a = np.zeros(N, dtype=float)
                for m in range(L):
                    idx = n - m
                    if 0 <= idx < N:
                        a[idx] += float(k[m])
                y = float(a @ x)
                eta = float(self.rng.normal(0.0, dim.dither_std)) if dim.dither_std > 0 else 0.0
                b = 1 if (y + eta) > dim.theta else 0
                B[n, i] = b
                rows.append(a)
                signs.append(2*b - 1)
                ths.append(dim.theta)
        log = {'A': np.vstack(rows) if rows else np.zeros((0, N)),
               's': np.array(signs, dtype=float),
               'th': np.array(ths, dtype=float)}
        return B, log


class StreamingPSTEncoder:
    """Per-sample PST encoder.

    Emits gated 1-bit measurements for the active dimension set and breath.
    This is the 'live heart' version: dimensions and breath can change in-flight.
    """
    def __init__(self, fs_hz: float, dims: List[Dimension], breath: Breath, seed: int = 0):
        self.fs_hz = float(fs_hz)
        self.dims = list(dims)
        self.breath = breath
        self.rng = np.random.default_rng(seed)

    def set_config(self, dims: List[Dimension], breath: Breath):
        self.dims = list(dims)
        self.breath = breath

    def _gate(self, dim: Dimension, n: int) -> int:
        P = max(int(dim.P), 1)
        on_len = int(np.floor(float(dim.d) * P))
        return 1 if ((n + int(dim.delta)) % P) < on_len else 0

    def encode_step(self, x_hist: np.ndarray, n: int) -> Dict[int, int]:
        """Encode at sample n.
        x_hist must contain at least L samples ending at n (inclusive). We use last L.
        Returns dict {dim_id: bit} for dims whose gate is open.
        """
        out: Dict[int, int] = {}
        phi = self.breath.phase(n)
        for dim in self.dims:
            if self._gate(dim, n) == 0:
                continue
            k = dim.k_plus if phi == +1 else dim.k_minus
            L = int(len(k))
            if x_hist.size < L:
                continue
            # y = sum_{m=0..L-1} k[m] * x[n-m]
            y = float(np.dot(k[:L], x_hist[-L:][::-1]))
            eta = float(self.rng.normal(0.0, dim.dither_std)) if dim.dither_std > 0 else 0.0
            b = 1 if (y + eta) > dim.theta else 0
            out[int(dim.dim_id)] = b
        return out
