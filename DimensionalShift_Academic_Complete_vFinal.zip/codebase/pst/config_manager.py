from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Any, List, Optional
import json, uuid, time
import numpy as np
from pathlib import Path

from .dimension_bus import BusPacket
from .kinds import K_CFG, K_CFG_APPLIED, K_DIM_BIRTH, K_DIM_KILL, K_INSIGHT
from .config import Gate, DimDef, make_bundle, random_kernel
from .config_loader import bundle_breath, bundle_projection_dims, bundle_cfg_id

@dataclass
class ConfigManager:
    """Applies cfg intents and regenerates config bundles with cfg_id rollover.

    Intents (packet kind=K_CFG):
    - SET_BREATH: change Te/Tc
    - BIRTH_DIM: add a new projection lane (new dim_id)
    - KILL_DIM: remove an existing lane by dim_id or by lowest score

    It emits K_CFG_APPLIED packets on success.
    """
    fs_hz: float = 10_000.0
    bundle_path: Path = Path("runs/active_cfg_bundle.json")
    min_lanes: int = 4
    max_lanes: int = 64
    kernel_L: int = 16

    # state
    bundle: Dict[str, Any] = field(default_factory=dict)
    scores: Dict[int, float] = field(default_factory=dict)  # dim_id -> insight score

    def load_or_init(self, initial_bundle: Dict[str, Any]):
        self.bundle = dict(initial_bundle)
        self.bundle_path.parent.mkdir(parents=True, exist_ok=True)
        self.bundle_path.write_text(json.dumps(self.bundle, indent=2), encoding="utf-8")

    def active_cfg_id(self) -> str:
        return bundle_cfg_id(self.bundle)

    def dims(self):
        return bundle_projection_dims(self.bundle)

    def breath(self):
        return bundle_breath(self.bundle)

    def ingest_score(self, pkt: BusPacket):
        if pkt.kind == K_INSIGHT and pkt.payload is not None:
            try:
                self.scores[int(pkt.dim_id)] = float(pkt.payload)
            except Exception:
                pass

    def _new_cfg_id(self) -> str:
        return str(uuid.uuid4())

    def _stamp(self) -> str:
        return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

    def _write(self):
        self.bundle_path.write_text(json.dumps(self.bundle, indent=2), encoding="utf-8")

    def apply_intent(self, pkt: BusPacket) -> Optional[BusPacket]:
        if pkt.kind != K_CFG or not isinstance(pkt.payload, dict):
            return None
        cmd = str(pkt.payload.get("cmd", "")).upper()
        changed = False

        if cmd == "SET_BREATH":
            Te = int(pkt.payload.get("Te", self.bundle.get("breath", {}).get("Te", 600)))
            Tc = int(pkt.payload.get("Tc", self.bundle.get("breath", {}).get("Tc", 400)))
            self.bundle["breath"] = {"Te": Te, "Tc": Tc}
            changed = True

        elif cmd == "BIRTH_DIM":
            lanes = [d for d in self.bundle.get("dimensions", []) if d.get("kind") == "projection_1bit"]
            if len(lanes) >= self.max_lanes:
                return None
            # choose new dim_id
            existing = {int(d["dim_id"]) for d in lanes}
            dim_id = int(pkt.payload.get("dim_id", 0)) or (max(existing) + 1 if existing else 1_000_000)
            while dim_id in existing:
                dim_id += 1
            # create lane
            seed = int(pkt.payload.get("seed", dim_id)) & 0xFFFFFFFF
            gateP = int(pkt.payload.get("P", 25 + (dim_id % 5)))
            duty = float(pkt.payload.get("d", 0.20))
            delta = int(pkt.payload.get("delta", dim_id % 31))
            theta = float(pkt.payload.get("threshold", 0.0))
            lane = {
                "dim_id": dim_id,
                "kind": "projection_1bit",
                "rate_hz": float(self.fs_hz),
                "kernel_plus": random_kernel(self.kernel_L, seed=seed),
                "kernel_minus": random_kernel(self.kernel_L, seed=seed + 1000),
                "gate": {"P": gateP, "d": duty, "delta": delta},
                "threshold": theta,
                "calibration": {"unit": "arb", "notes": "born by ConfigManager"}
            }
            self.bundle.setdefault("dimensions", []).append(lane)
            changed = True

        elif cmd == "KILL_DIM":
            lanes = [d for d in self.bundle.get("dimensions", []) if d.get("kind") == "projection_1bit"]
            if len(lanes) <= self.min_lanes:
                return None
            target = pkt.payload.get("dim_id", None)
            kill_id: Optional[int] = None
            if target is not None:
                kill_id = int(target)
            else:
                # kill lowest score among active lanes
                lane_ids = [int(d["dim_id"]) for d in lanes]
                scored = [(self.scores.get(i, 0.0), i) for i in lane_ids]
                scored.sort(key=lambda t: t[0])
                kill_id = scored[0][1] if scored else None

            if kill_id is None:
                return None
            before = len(self.bundle.get("dimensions", []))
            self.bundle["dimensions"] = [d for d in self.bundle.get("dimensions", []) if int(d.get("dim_id", -1)) != kill_id]
            changed = (len(self.bundle.get("dimensions", [])) != before)

        if not changed:
            return None

        # cfg rollover
        self.bundle["cfg_id"] = self._new_cfg_id()
        self.bundle["created_utc"] = self._stamp()
        self._write()
        return BusPacket(
            time_ns=pkt.time_ns,
            clock_domain=pkt.clock_domain,
            dim_id=900000004,
            kind=K_CFG_APPLIED,
            phase=pkt.phase,
            cfg_id=str(self.bundle["cfg_id"]),
            payload={"applied": cmd, "active_cfg_id": str(self.bundle["cfg_id"]), "bundle_path": str(self.bundle_path)},
        )
