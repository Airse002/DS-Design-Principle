# Dimensional Shift — Final Pack (v2.5.0)

This folder is a curated "hand-in / demo" pack.

## What to run (fast)
### A) DS dynamic 10D demo (polygon/radar + baselines)
```bash
export DLINK_PLATFORM=cuda   # or cpu
export DSHIFT_ACCEL_BACKEND=cuda   # or cpu
python examples/demo_ds_dynamic_10d_gpu_vs_baselines.py
```

### B) UTB CUDA primitives + DS pulse benchmark suite ("benchmark button")
```bash
cd apps/cuda_primitives_dlink
bash scripts/build.sh
bash scripts/benchmark_suite.sh
```

### C) D-Link scaling benchmark (10k → 1M dimensions)
```bash
export DLINK_PLATFORM=cuda
export DSHIFT_ACCEL_BACKEND=cuda
python examples/benchmark_dlink_scaling.py
```

## Key concepts
- **DS pulse**: Expand (DE) → Collapse (DR/Dim-plosion) repeating over time.
- **D-Link**: platform bridge for DS roles (CPU/CUDA/QPU-ready).
- **DS-A primitives**: insight_eval, topk_subset, gate_opt, adc encode/decode, bus packets.

## Documents
- `DS_PSEUDOCODE.md`
- `DIMENSIONAL_COMPUTING_PHILOSOPHY.md`
- `BC_JIRI_BURDA_STATEMENT.csv`

Build date: 2026-01-24

## One-command export (recommended on Tesla)
```bash
bash scripts/export_all.sh
```
This detects nvcc/CuPy, runs what is available, and writes `runs/EXPORT_REPORT.md`.
