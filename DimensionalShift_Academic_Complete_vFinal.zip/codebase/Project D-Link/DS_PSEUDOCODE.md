\
# DS-ready Pseudocode (Dimensional Shift, DS-A)

This pseudocode describes a DS system that is **D-Link ready** (CPU/CUDA/QPU backends),
and uses the DS-A building blocks implemented in this project.

## DS-A primitives (conceptual)
- `ADC_ENCODE(x_t, lanes, L, threshold) -> bits_t[lanes]`
- `ADC_DECODE(bits_window, params) -> xhat_t`
- `INSIGHT_EVAL(dim_ids, base_scores, noise_std) -> scores[lanes]`
- `TOPK_SUBSET(scores, K) -> keep_idx[K]`
- `GATE_OPT(Te, Tc, progress, pain, candidates) -> (Te', Tc')`
- `DLINK_CALL(problem) -> result` (routes to CPU/CUDA/QPU)
- `BUS_EMIT(packet)` (telemetry / policy / logs)

In the repo, these correspond to:
- DS-lite: projections + bits + decode (`apps/ds_dynamic_optimizer/ds_lite.py`)
- D-Link roles: `dlink_cuda_app/dlink_cuda/cuda_sampler.py` and platform selector
- UTB DS pulse: `apps/cuda_primitives_dlink` (expand/collapse over launch configs)

---

## DS Pulse Loop (Expand → Collapse)

### State
- `dims` = number of lanes (dimensions)
- `K` = Top-K lanes kept (Dim-plosion / DR)
- `Te` = expand time (heartbeat expand window)
- `Tc` = collision time (heartbeat collapse window)
- `theta` = thresholds / kernel params (ADC/decoder)
- `backend` ∈ {cpu, cuda, qpu-sim, qpu-engine}

### Cost / Objective
A generic DS objective is a weighted sum:
- `error` (reconstruction RMSE, tracking error, anomaly score, etc.)
- `compute_time` (latency / energy proxy)
- `stability` (penalize thrashing parameters)

`J = error + α_time * time + α_stab * ||Δparams||`

---

## Algorithm (streaming)
```text
initialize dims, K, Te, Tc, theta
initialize policy memory M (history of best configs / best lanes)

while stream is alive:
  # ===============
  # PHASE 1: EXPAND (DE)
  # ===============
  window = read_signal_for_duration(Te)          # pulse inhale
  H = build_history_matrix(window, L)
  bits = ADC_ENCODE(H, dims, L, threshold=theta.th)

  # Evaluate "lane usefulness" (insight) using D-Link
  problem1 = { kind: "insight_eval",
               dim_ids: [0..dims-1],
               base_scores: M.base_scores,
               noise_std: theta.noise }
  scores = DLINK_CALL(problem1).scores

  # Expand candidates (multi-hypothesis)
  candidate_dim_sets = {TOPK_SUBSET(scores, K1), TOPK_SUBSET(scores, K2), ...}
  candidate_gate_sets = {(Te_i, Tc_i) for i in 1..C}

  # ===============
  # PHASE 2: COLLAPSE (DR / Dim-plosion)
  # ===============
  keep_idx = DLINK_CALL({ kind: "topk_subset", weights: scores, K: K }).selected
  bits_reduced = bits[:, keep_idx]

  # Decode / compute output and score cost
  xhat = ADC_DECODE(bits_reduced, theta)
  error = compute_error(window, xhat)
  pain  = error

  # Update heartbeat timing using D-Link
  (Te_new, Tc_new) = DLINK_CALL({
        kind: "gate_opt", Te: Te, Tc: Tc,
        progress: progress_metric(), pain: pain,
        candidates: C
      }).best

  # Stabilize update (avoid oscillation)
  (dims, K, Te, Tc, theta) = stabilize_update(dims, K, Te_new, Tc_new, theta, error)

  # Memory update
  M.update(scores, keep_idx, (dims, K, Te, Tc, theta), J=error)

  # Telemetry
  BUS_EMIT({t: now(), dims: dims, K: K, Te: Te, Tc: Tc, error: error, backend: backend})
end while
```

---

## How DS-A is used across the repo
1) **D-Link GPU co-processor roles**: insight/topK/gate executed on CPU or CUDA via a uniform interface.
2) **Dynamic 10D optimizer**: shows evolving DS state (polygon/radar) and DS-vs-baselines metrics.
3) **UTB primitives**: DS pulse autotunes kernel configs; conv2D compares global vs shared memory.

## Bulletproofing checklist
- Log seeds/backends/params for reproducibility.
- Add stability penalties and parameter bounds.
- Validate correctness with CPU references for primitives.
